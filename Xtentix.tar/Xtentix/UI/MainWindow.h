#pragma once
#include "../Core/WindowBase.h"
#include "../Tabs/TabManager.h"
#include "../Bookmark/BookmarkManager.h"
#include "../Settings/SettingsManager.h"
#include "../Rendering/Document.h"
#include "../Rendering/LayoutBox.h"
#include "TabStrip.h"
#include "AddressBar.h"
#include "NewTabPage.h"
#include <unordered_map>
#include <memory>

namespace Xtentix {

// 애플리케이션의 최상위 윈도우. 탭 스트립 / 주소창(+별표 버튼) / 콘텐츠 영역을 세로로 배치한다.
//   +--------------------------------+
//   | TabStrip                       |  <- kHeight
//   +--------------------------------+
//   | [*] AddressBar                 |  <- kHeight
//   +--------------------------------+
//   | Content: about:blank -> NewTabPage, 그 외 -> HttpClient -> HtmlParser ->
//   | CssParser -> StyleResolver -> LayoutEngine -> GdiPainter 로 실제 렌더링    |
//   +--------------------------------+
class MainWindow : public WindowBase {
public:
    bool Create(HINSTANCE instance, int cmdShow);

    // ContentAreaProc(자유 함수 WNDPROC)이 WM_PAINT/WM_VSCROLL/WM_MOUSEWHEEL에서 호출.
    void PaintContentArea(HDC hdc, RECT clientRect);
    void HandleContentVScroll(WPARAM wParam);
    void HandleContentMouseWheel(short wheelDelta);
    void HandleContentClick(int x, int y);
    void UpdateContentCursor(int x, int y);

protected:
    bool HandleMessage(UINT msg, WPARAM wParam, LPARAM lParam, LRESULT& outResult) override;

private:
    struct PageLoadResult {
        TabId tabId;
        std::string requestedUrl;
        bool success = false;
        std::string title;
        std::unique_ptr<Document> document;
        std::unique_ptr<LayoutBox> layout;
    };

    void Layout();
    void NavigateActiveTab(const std::string& url);
    void RefreshTitle();
    void RefreshBookmarkButton();
    void ToggleBookmarkForActiveTab();
    void UpdateContentVisibility();
    void RelayoutActiveTabIfNeeded();
    void OnPageLoadResult(PageLoadResult* result);
    void UpdateScrollbar();
    void SetContentScroll(int pos);

    static constexpr UINT kAddressBarId = 1001;
    static constexpr UINT kBookmarkButtonId = 1002;
    static constexpr int kBookmarkButtonWidth = 32;
    static constexpr UINT kPageReadyMsg = WM_APP + 2;

    HINSTANCE m_instance = nullptr;
    TabManager m_tabManager;
    BookmarkManager m_bookmarkManager;
    SettingsManager m_settingsManager;

    TabStrip m_tabStrip;
    AddressBar m_addressBar;
    HWND m_bookmarkButton = nullptr;
    NewTabPage m_newTabPage;
    HWND m_contentArea = nullptr;

    // 탭별로 로드된 문서/레이아웃 결과. 탭을 닫으면 같이 정리한다.
    std::unordered_map<TabId, std::unique_ptr<Document>> m_documents;
    std::unordered_map<TabId, std::unique_ptr<LayoutBox>> m_layouts;
    std::unordered_map<TabId, int> m_scrollOffsets; // 탭 전환해도 스크롤 위치 유지
};

} // namespace Xtentix
