#include "MainWindow.h"
#include "../Utils/StringUtils.h"
#include "../Resources/resource.h"
#include "../Network/HttpClient.h"
#include "../Rendering/LayoutEngine.h"
#include "../Rendering/GdiPainter.h"
#include <windowsx.h>
#include <algorithm>

namespace Xtentix {

namespace {

// <title>, <style> 내용을 DOM에서 뽑아낸다. 둘 다 RCDATA/RAWTEXT라 자식은
// 텍스트 노드 하나뿐이라고 가정해도 실전에서 충분함.
void CollectStylesAndTitle(const DomNode* node, std::string& title, std::vector<std::string>& styles) {
    if (node->Type() == NodeType::Element) {
        if (node->TagName() == "title") {
            for (auto& c : node->Children()) if (c->Type() == NodeType::Text) title += c->Data();
        } else if (node->TagName() == "style") {
            for (auto& c : node->Children()) if (c->Type() == NodeType::Text) styles.push_back(c->Data());
        }
    }
    for (auto& c : node->Children()) CollectStylesAndTitle(c.get(), title, styles);
}

std::string NormalizeUrl(const std::string& url) {
    if (url.empty() || url == "about:blank") return url;
    if (StringUtils::StartsWith(url, "http://") || StringUtils::StartsWith(url, "https://")) return url;
    // TODO(Phase 5+): 주소처럼 안 생겼으면 검색엔진으로 보내는 처리 (지금은 단순히 http:// 붙임)
    return "http://" + url;
}

// 레이아웃 트리에서 (x,y) 지점(스크롤 보정된 문서 좌표)에 있는 링크 텍스트런을 찾는다.
const LayoutBox* HitTestLink(const LayoutBox* box, int x, int y) {
    if (box->isTextRun) {
        if (box->linkHref.empty()) return nullptr;
        if (x >= box->x && x < box->x + box->contentWidth &&
            y >= box->y && y < box->y + box->contentHeight) return box;
        return nullptr;
    }
    for (auto& c : box->children) {
        if (const LayoutBox* hit = HitTestLink(c.get(), x, y)) return hit;
    }
    return nullptr;
}

// href를 현재 페이지 URL 기준 절대 URL로 해석. 지원: 절대 URL, "//host/...",
// "/root-relative", "relative/path". 미지원(TODO): "../" 상위 경로 정규화, 쿼리/프래그먼트 병합.
std::string ResolveUrl(const std::string& base, const std::string& href) {
    if (href.empty() || href[0] == '#') return ""; // 페이지 내 앵커 이동은 아직 미지원
    if (StringUtils::StartsWith(href, "http://") || StringUtils::StartsWith(href, "https://")) return href;

    size_t schemeEnd = base.find("://");
    if (schemeEnd == std::string::npos) return href;
    std::string scheme = base.substr(0, schemeEnd);

    size_t hostStart = schemeEnd + 3;
    size_t pathStart = base.find('/', hostStart);
    std::string host = (pathStart == std::string::npos) ? base.substr(hostStart) : base.substr(hostStart, pathStart - hostStart);

    if (href.size() >= 2 && href[0] == '/' && href[1] == '/') return scheme + ":" + href;
    if (href[0] == '/') return scheme + "://" + host + href;

    std::string basePath = (pathStart == std::string::npos) ? "/" : base.substr(pathStart);
    size_t lastSlash = basePath.find_last_of('/');
    std::string dir = (lastSlash == std::string::npos) ? "/" : basePath.substr(0, lastSlash + 1);
    return scheme + "://" + host + dir + href;
}

// 콘텐츠 영역(실제 페이지가 그려지는 곳)의 최소 WNDPROC. 실제 그리기는 전부
// MainWindow::PaintContentArea에 위임 - 이 프록시는 GWLP_USERDATA로 저장해둔
// MainWindow*를 꺼내 넘겨주는 역할만 한다.
LRESULT CALLBACK ContentAreaProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (msg == WM_PAINT) {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        RECT rc;
        GetClientRect(hwnd, &rc);
        auto* mainWindow = reinterpret_cast<MainWindow*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
        if (mainWindow) mainWindow->PaintContentArea(hdc, rc);
        EndPaint(hwnd, &ps);
        return 0;
    }
    if (msg == WM_LBUTTONDOWN) {
        auto* mainWindow = reinterpret_cast<MainWindow*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
        if (mainWindow) mainWindow->HandleContentClick(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
        return 0;
    }
    if (msg == WM_SETCURSOR) {
        auto* mainWindow = reinterpret_cast<MainWindow*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
        if (mainWindow) {
            POINT pt; GetCursorPos(&pt); ScreenToClient(hwnd, &pt);
            mainWindow->UpdateContentCursor(pt.x, pt.y);
        }
        return TRUE;
    }
    if (msg == WM_VSCROLL) {
        auto* mainWindow = reinterpret_cast<MainWindow*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
        if (mainWindow) mainWindow->HandleContentVScroll(wParam);
        return 0;
    }
    if (msg == WM_MOUSEWHEEL) {
        auto* mainWindow = reinterpret_cast<MainWindow*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
        if (mainWindow) mainWindow->HandleContentMouseWheel(GET_WHEEL_DELTA_WPARAM(wParam));
        return 0;
    }
    if (msg == WM_ERASEBKGND) return 1;
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

} // namespace

bool MainWindow::Create(HINSTANCE instance, int cmdShow) {
    m_instance = instance;

    CreateWindowInternal(L"XtentixMainWindow", L"Xtentix Browser",
                          WS_OVERLAPPEDWINDOW, 0,
                          CW_USEDEFAULT, CW_USEDEFAULT, 1200, 800,
                          nullptr, nullptr, instance);
    if (!m_hwnd) return false;

    HICON appIcon = LoadIconW(instance, MAKEINTRESOURCEW(IDI_APP_ICON));
    if (appIcon) {
        SendMessageW(m_hwnd, WM_SETICON, ICON_BIG, (LPARAM)appIcon);
        SendMessageW(m_hwnd, WM_SETICON, ICON_SMALL, (LPARAM)appIcon);
    }

    m_bookmarkManager.Load();
    m_settingsManager.Load();

    m_tabStrip.Create(m_hwnd, instance, &m_tabManager);

    m_bookmarkButton = CreateWindowExW(0, L"BUTTON", L"\u2606",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0,
        m_hwnd, (HMENU)(UINT_PTR)kBookmarkButtonId, instance, nullptr);

    m_addressBar.Create(m_hwnd, instance, kAddressBarId);

    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = ContentAreaProc;
    wc.hInstance = instance;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszClassName = L"XtentixContentArea";
    RegisterClassExW(&wc);

    m_contentArea = CreateWindowExW(0, L"XtentixContentArea", L"", WS_CHILD | WS_VSCROLL,
                                     0, 0, 0, 0, m_hwnd, nullptr, instance, nullptr);
    SetWindowLongPtrW(m_contentArea, GWLP_USERDATA, (LONG_PTR)this);

    m_newTabPage.Create(m_hwnd, instance, &m_bookmarkManager, &m_settingsManager);

    m_tabManager.OnChanged([this]() {
        InvalidateRect(m_tabStrip.Handle(), nullptr, TRUE);
        RefreshTitle();
        if (Tab* t = m_tabManager.ActiveTab()) m_addressBar.SetUrl(t->Url());
        RefreshBookmarkButton();
        UpdateContentVisibility();
    });

    m_tabStrip.OnSelect([this](TabId id) { m_tabManager.SetActiveTab(id); });
    m_tabStrip.OnClose([this](TabId id) {
        m_tabManager.CloseTab(id);
        m_documents.erase(id);
        m_layouts.erase(id);
        m_scrollOffsets.erase(id);
        if (m_tabManager.Count() == 0) m_tabManager.CreateTab();
    });
    m_tabStrip.OnNewTab([this]() { m_tabManager.CreateTab(); });
    m_addressBar.OnNavigate([this](const std::string& url) { NavigateActiveTab(url); });
    m_newTabPage.OnNavigate([this](const std::string& url) { NavigateActiveTab(url); });

    m_tabManager.CreateTab("about:blank", "\uc0c8 \ud0ed");

    Layout();
    ShowWindow(m_hwnd, cmdShow);
    UpdateWindow(m_hwnd);
    return true;
}

void MainWindow::NavigateActiveTab(const std::string& urlIn) {
    Tab* tab = m_tabManager.ActiveTab();
    if (!tab) return;

    std::string url = NormalizeUrl(urlIn);
    TabId tabId = tab->Id();

    tab->SetUrl(url);
    m_documents.erase(tabId);
    m_layouts.erase(tabId);
    m_scrollOffsets[tabId] = 0;

    if (url.empty() || url == "about:blank") {
        tab->SetTitle("\uc0c8 \ud0ed");
        tab->SetLoading(false);
        InvalidateRect(m_tabStrip.Handle(), nullptr, TRUE);
        RefreshTitle();
        m_addressBar.SetUrl(url);
        RefreshBookmarkButton();
        UpdateContentVisibility();
        return;
    }

    tab->SetTitle(url);
    tab->SetLoading(true);
    InvalidateRect(m_tabStrip.Handle(), nullptr, TRUE);
    RefreshTitle();
    m_addressBar.SetUrl(url);
    RefreshBookmarkButton();
    UpdateContentVisibility();
    InvalidateRect(m_contentArea, nullptr, TRUE); // "로딩 중..." 표시

    RECT contentRect;
    GetClientRect(m_contentArea, &contentRect);
    int viewportWidth = (std::max)(100L, contentRect.right - contentRect.left);
    HWND self = m_hwnd;

    HttpClient().GetAsync(url, [self, tabId, url, viewportWidth](const HttpResponse& response) {
        // 워커 스레드: 파싱 + 스타일 계산 + 레이아웃까지 전부 여기서 끝내고,
        // 완성된 결과만 UI 스레드로 넘긴다 (PostMessage 마셜링).
        auto* result = new MainWindow::PageLoadResult{};
        result->tabId = tabId;
        result->requestedUrl = url;
        result->success = response.success;

        if (response.success) {
            auto doc = std::make_unique<Document>(url);
            doc->LoadHtml(response.body);

            std::string title;
            std::vector<std::string> styleBlocks;
            if (doc->Root()) CollectStylesAndTitle(doc->Root(), title, styleBlocks);
            for (auto& css : styleBlocks) doc->AddStylesheet(css);
            doc->ComputeStyles();

            HDC measureDC = CreateCompatibleDC(nullptr);
            auto measureFn = [measureDC](const std::wstring& text, int fontSizePx, bool bold, bool italic) {
                return GdiPainter::Measure(measureDC, text, fontSizePx, bold, italic);
            };
            auto layout = LayoutEngine::BuildLayout(doc->Root(), doc->Styles(), viewportWidth, measureFn);
            DeleteDC(measureDC);

            result->title = title.empty() ? url : title;
            result->document = std::move(doc);
            result->layout = std::move(layout);
        }

        PostMessage(self, kPageReadyMsg, 0, reinterpret_cast<LPARAM>(result));
    });
}

void MainWindow::OnPageLoadResult(PageLoadResult* result) {
    Tab* tab = m_tabManager.FindById(result->tabId);
    // 응답이 오는 사이에 탭이 닫혔거나, 그 사이 다른 곳으로 또 이동했으면 결과를 버린다.
    if (tab && tab->Url() == result->requestedUrl) {
        tab->SetLoading(false);
        if (result->success) {
            tab->SetTitle(result->title);
            m_documents[result->tabId] = std::move(result->document);
            m_layouts[result->tabId] = std::move(result->layout);
        } else {
            tab->SetTitle("\uD398\uC774\uC9C0\uB97C \uBD88\uB7EC\uC624\uC9C0 \uBABB\uD568");
        }

        if (m_tabManager.ActiveTab() == tab) {
            InvalidateRect(m_contentArea, nullptr, TRUE);
            RefreshTitle();
            UpdateScrollbar();
        }
        InvalidateRect(m_tabStrip.Handle(), nullptr, TRUE);
    }
    delete result;
}

void MainWindow::PaintContentArea(HDC hdc, RECT clientRect) {
    HBRUSH bg = CreateSolidBrush(RGB(255, 255, 255));
    FillRect(hdc, &clientRect, bg);
    DeleteObject(bg);

    Tab* tab = m_tabManager.ActiveTab();
    if (!tab) return;

    auto it = m_layouts.find(tab->Id());
    if (it != m_layouts.end() && it->second) {
        int scrollY = m_scrollOffsets.count(tab->Id()) ? m_scrollOffsets[tab->Id()] : 0;
        GdiPainter::Paint(hdc, it->second.get(), 0, scrollY);
        return;
    }

    SetBkMode(hdc, TRANSPARENT);
    std::wstring message = tab->IsLoading() ? L"\uBD88\uB7EC\uC624\uB294 \uC911..." : L"";
    if (!message.empty()) {
        DrawTextW(hdc, message.c_str(), -1, &clientRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    }
}

void MainWindow::RelayoutActiveTabIfNeeded() {
    Tab* tab = m_tabManager.ActiveTab();
    if (!tab) return;
    auto docIt = m_documents.find(tab->Id());
    if (docIt == m_documents.end() || !docIt->second || !docIt->second->Root()) return;

    RECT rc;
    GetClientRect(m_contentArea, &rc);
    if (rc.right <= 0) return;

    HDC hdc = GetDC(m_contentArea);
    auto measureFn = [hdc](const std::wstring& text, int fontSizePx, bool bold, bool italic) {
        return GdiPainter::Measure(hdc, text, fontSizePx, bold, italic);
    };
    m_layouts[tab->Id()] = LayoutEngine::BuildLayout(docIt->second->Root(), docIt->second->Styles(), rc.right, measureFn);
    ReleaseDC(m_contentArea, hdc);
    UpdateScrollbar();
    InvalidateRect(m_contentArea, nullptr, TRUE);
}

void MainWindow::UpdateScrollbar() {
    Tab* tab = m_tabManager.ActiveTab();
    int contentHeight = 0;
    if (tab) {
        auto it = m_layouts.find(tab->Id());
        if (it != m_layouts.end() && it->second) contentHeight = it->second->contentHeight;
    }

    RECT rc;
    GetClientRect(m_contentArea, &rc);
    int viewportHeight = (std::max)(1L, rc.bottom - rc.top);
    int maxScroll = (std::max)(0, contentHeight - viewportHeight);

    int pos = 0;
    if (tab) {
        pos = (std::max)(0, (std::min)(m_scrollOffsets[tab->Id()], maxScroll));
        m_scrollOffsets[tab->Id()] = pos;
    }

    SCROLLINFO si{};
    si.cbSize = sizeof(si);
    si.fMask = SIF_RANGE | SIF_PAGE | SIF_POS;
    si.nMin = 0;
    si.nMax = (std::max)(0, contentHeight - 1);
    si.nPage = (UINT)viewportHeight;
    si.nPos = pos;
    SetScrollInfo(m_contentArea, SB_VERT, &si, TRUE);
}

void MainWindow::SetContentScroll(int pos) {
    Tab* tab = m_tabManager.ActiveTab();
    if (!tab) return;

    SCROLLINFO si{};
    si.cbSize = sizeof(si);
    si.fMask = SIF_RANGE | SIF_PAGE;
    GetScrollInfo(m_contentArea, SB_VERT, &si);
    int maxPos = (std::max)(0, si.nMax - (int)si.nPage + 1);
    pos = (std::max)(0, (std::min)(pos, maxPos));

    m_scrollOffsets[tab->Id()] = pos;
    SetScrollPos(m_contentArea, SB_VERT, pos, TRUE);
    InvalidateRect(m_contentArea, nullptr, TRUE);
}

void MainWindow::HandleContentVScroll(WPARAM wParam) {
    SCROLLINFO si{};
    si.cbSize = sizeof(si);
    si.fMask = SIF_ALL;
    GetScrollInfo(m_contentArea, SB_VERT, &si);

    int pos = si.nPos;
    switch (LOWORD(wParam)) {
        case SB_LINEUP: pos -= 40; break;
        case SB_LINEDOWN: pos += 40; break;
        case SB_PAGEUP: pos -= (int)si.nPage; break;
        case SB_PAGEDOWN: pos += (int)si.nPage; break;
        case SB_THUMBTRACK:
        case SB_THUMBPOSITION: pos = si.nTrackPos; break;
        default: return;
    }
    SetContentScroll(pos);
}

void MainWindow::HandleContentMouseWheel(short wheelDelta) {
    int lines = wheelDelta / WHEEL_DELTA; // 보통 한 노치 = WHEEL_DELTA(120)
    Tab* tab = m_tabManager.ActiveTab();
    int current = tab ? m_scrollOffsets[tab->Id()] : 0;
    SetContentScroll(current - lines * 60);
}

void MainWindow::HandleContentClick(int x, int y) {
    Tab* tab = m_tabManager.ActiveTab();
    if (!tab) return;
    auto it = m_layouts.find(tab->Id());
    if (it == m_layouts.end() || !it->second) return;

    int scrollY = m_scrollOffsets.count(tab->Id()) ? m_scrollOffsets[tab->Id()] : 0;
    const LayoutBox* hit = HitTestLink(it->second.get(), x, y + scrollY);
    if (!hit) return;

    std::string resolved = ResolveUrl(tab->Url(), hit->linkHref);
    if (!resolved.empty()) NavigateActiveTab(resolved);
}

void MainWindow::UpdateContentCursor(int x, int y) {
    Tab* tab = m_tabManager.ActiveTab();
    bool overLink = false;
    if (tab) {
        auto it = m_layouts.find(tab->Id());
        if (it != m_layouts.end() && it->second) {
            int scrollY = m_scrollOffsets.count(tab->Id()) ? m_scrollOffsets[tab->Id()] : 0;
            overLink = HitTestLink(it->second.get(), x, y + scrollY) != nullptr;
        }
    }
    SetCursor(LoadCursor(nullptr, overLink ? IDC_HAND : IDC_ARROW));
}

void MainWindow::RefreshTitle() {
    Tab* tab = m_tabManager.ActiveTab();
    std::wstring title = L"Xtentix Browser";
    if (tab) title = StringUtils::Utf8ToWide(tab->Title()) + L" - Xtentix Browser";
    SetWindowTextW(m_hwnd, title.c_str());
}

void MainWindow::RefreshBookmarkButton() {
    Tab* tab = m_tabManager.ActiveTab();
    bool bookmarked = tab && m_bookmarkManager.Contains(tab->Url());
    SetWindowTextW(m_bookmarkButton, bookmarked ? L"\u2605" : L"\u2606"); // 채운 별 / 빈 별
    EnableWindow(m_bookmarkButton, tab && !tab->Url().empty() && tab->Url() != "about:blank");
}

void MainWindow::ToggleBookmarkForActiveTab() {
    Tab* tab = m_tabManager.ActiveTab();
    if (!tab || tab->Url().empty() || tab->Url() == "about:blank") return;

    if (m_bookmarkManager.Contains(tab->Url())) {
        m_bookmarkManager.Remove(tab->Url());
    } else {
        m_bookmarkManager.Add(tab->Title(), tab->Url());
    }
    RefreshBookmarkButton();
    m_newTabPage.RefreshBookmarks();
}

void MainWindow::UpdateContentVisibility() {
    Tab* tab = m_tabManager.ActiveTab();
    bool showNewTab = !tab || tab->Url().empty() || tab->Url() == "about:blank";

    ShowWindow(m_newTabPage.Handle(), showNewTab ? SW_SHOW : SW_HIDE);
    ShowWindow(m_contentArea, showNewTab ? SW_HIDE : SW_SHOW);
    if (showNewTab) {
        m_newTabPage.RefreshBookmarks();
    } else {
        UpdateScrollbar();
        InvalidateRect(m_contentArea, nullptr, TRUE);
    }
}

void MainWindow::Layout() {
    if (!m_hwnd) return;
    RECT rc;
    GetClientRect(m_hwnd, &rc);
    int width = rc.right - rc.left;
    int height = rc.bottom - rc.top;

    SetWindowPos(m_tabStrip.Handle(), nullptr, 0, 0, width, TabStrip::kHeight, SWP_NOZORDER);

    int barY = TabStrip::kHeight + 4;
    SetWindowPos(m_bookmarkButton, nullptr, 4, barY, kBookmarkButtonWidth, AddressBar::kHeight, SWP_NOZORDER);
    SetWindowPos(m_addressBar.Handle(), nullptr, 4 + kBookmarkButtonWidth + 4, barY,
                 width - kBookmarkButtonWidth - 16, AddressBar::kHeight, SWP_NOZORDER);

    int contentY = TabStrip::kHeight + AddressBar::kHeight + 8;
    int contentHeight = (std::max)(0, height - contentY);
    SetWindowPos(m_contentArea, nullptr, 0, contentY, width, contentHeight, SWP_NOZORDER);
    SetWindowPos(m_newTabPage.Handle(), nullptr, 0, contentY, width, contentHeight, SWP_NOZORDER);

    RelayoutActiveTabIfNeeded();
}

bool MainWindow::HandleMessage(UINT msg, WPARAM wParam, LPARAM lParam, LRESULT& outResult) {
    switch (msg) {
        case WM_SIZE:
            Layout();
            outResult = 0;
            return true;
        case WM_COMMAND:
            if (LOWORD(wParam) == kBookmarkButtonId) {
                ToggleBookmarkForActiveTab();
                outResult = 0;
                return true;
            }
            return false;
        case WM_DESTROY:
            PostQuitMessage(0);
            outResult = 0;
            return true;
    }
    if (msg == kPageReadyMsg) {
        OnPageLoadResult(reinterpret_cast<PageLoadResult*>(lParam));
        outResult = 0;
        return true;
    }
    return false;
}

} // namespace Xtentix
