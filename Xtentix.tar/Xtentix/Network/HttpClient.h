#pragma once
#include <string>
#include <functional>

namespace Xtentix {

struct HttpResponse {
    int statusCode = 0;
    std::string body;
    std::string contentType;
    bool success = false;
};

// TODO(Phase 3): WinHTTP(OS 기본 제공, 외부 라이브러리 아님)로 구현.
// HTTPS는 WinHTTP가 Schannel을 통해 처리하므로 별도 TLS 구현 불필요.
class HttpClient {
public:
    using ResponseCallback = std::function<void(const HttpResponse&)>;

    // 비동기 GET. 완료 시 콜백은 UI 스레드가 아닌 워커 스레드에서 호출될 수 있으므로
    // 호출부(MainWindow)에서 PostMessage로 마셜링해야 한다.
    void GetAsync(const std::string& url, ResponseCallback callback);
};

} // namespace Xtentix
