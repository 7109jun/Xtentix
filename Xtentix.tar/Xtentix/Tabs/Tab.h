#pragma once
#include <string>
#include <cstdint>

namespace Xtentix {

using TabId = uint32_t;

// 탭 하나의 상태. 실제 렌더링 결과(DOM/레이아웃 트리)는 Phase 4에서
// Rendering::Document로 연결될 예정 (지금은 포인터 자리만 마련).
class Tab {
public:
    Tab(TabId id, std::string url, std::string title);

    TabId Id() const { return m_id; }

    const std::string& Url() const { return m_url; }
    void SetUrl(std::string url) { m_url = std::move(url); }

    const std::string& Title() const { return m_title; }
    void SetTitle(std::string title) { m_title = std::move(title); }

    bool IsLoading() const { return m_isLoading; }
    void SetLoading(bool loading) { m_isLoading = loading; }

private:
    TabId m_id;
    std::string m_url;
    std::string m_title;
    bool m_isLoading = false;
    // Rendering::Document* m_document = nullptr; // Phase 4에서 연결
};

} // namespace Xtentix
