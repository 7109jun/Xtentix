#pragma once
#include "Tab.h"
#include <vector>
#include <memory>
#include <functional>

namespace Xtentix {

// 탭 생성/종료/전환을 담당. UI(TabStrip)는 이 클래스가 발행하는 콜백을 구독해서
// 화면을 갱신하고, 이 클래스는 UI를 전혀 알지 못한다 (단방향 의존).
class TabManager {
public:
    using ChangeCallback = std::function<void()>;

    Tab* CreateTab(const std::string& url = "about:blank", const std::string& title = "새 탭");
    bool CloseTab(TabId id);

    Tab* ActiveTab() const;
    Tab* FindById(TabId id) const;
    bool SetActiveTab(TabId id);

    const std::vector<std::unique_ptr<Tab>>& Tabs() const { return m_tabs; }
    size_t Count() const { return m_tabs.size(); }

    void OnChanged(ChangeCallback cb) { m_onChanged = std::move(cb); }

private:
    void NotifyChanged();

    std::vector<std::unique_ptr<Tab>> m_tabs;
    size_t m_activeIndex = static_cast<size_t>(-1);
    TabId m_nextId = 1;
    ChangeCallback m_onChanged;
};

} // namespace Xtentix
