#include "GdiPainter.h"
#include <unordered_map>
#include <cstdint>

namespace Xtentix {

namespace {

// 단어(텍스트런) 하나마다 폰트를 새로 만들고 버리면, 페이지 하나 다시 그릴 때마다
// (스크롤할 때마다!) CreateFontW를 수백 번 호출하게 된다. 스레드별 캐시로 재사용.
// (Measure()는 워커 스레드에서, PaintBox()는 UI 스레드에서 호출되므로 thread_local로
// 캐시를 나눠서 락 없이 안전하게 공유 없이 사용)
struct FontCache {
    std::unordered_map<uint32_t, HFONT> cache;
    ~FontCache() { for (auto& kv : cache) DeleteObject(kv.second); }
};
thread_local FontCache g_fontCache;

uint32_t FontKey(int fontSizePx, bool bold, bool italic) {
    return ((uint32_t)(fontSizePx & 0xFFFF) << 2) | (bold ? 2u : 0u) | (italic ? 1u : 0u);
}

HFONT MakeFont(int fontSizePx, bool bold, bool italic) {
    uint32_t key = FontKey(fontSizePx, bold, italic);
    auto it = g_fontCache.cache.find(key);
    if (it != g_fontCache.cache.end()) return it->second;

    HFONT font = CreateFontW(-fontSizePx, 0, 0, 0, bold ? FW_BOLD : FW_NORMAL, italic ? TRUE : FALSE, FALSE, FALSE,
                              DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                              CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
    g_fontCache.cache[key] = font;
    return font;
}

COLORREF ToColorRef(const RgbColor& c) { return RGB(c.r, c.g, c.b); }

} // namespace

TextMetrics GdiPainter::Measure(HDC hdc, const std::wstring& text, int fontSizePx, bool bold, bool italic) {
    HFONT font = MakeFont(fontSizePx, bold, italic);
    HFONT oldFont = (HFONT)SelectObject(hdc, font);

    SIZE size{ 0, 0 };
    if (!text.empty()) GetTextExtentPoint32W(hdc, text.c_str(), (int)text.size(), &size);

    TEXTMETRICW tm{};
    GetTextMetricsW(hdc, &tm);

    SelectObject(hdc, oldFont); // 캐시된 폰트는 재사용해야 하므로 DeleteObject는 하지 않음

    TextMetrics m;
    m.width = size.cx;
    m.lineHeight = tm.tmHeight + tm.tmExternalLeading;
    return m;
}

void GdiPainter::PaintBox(HDC hdc, const LayoutBox* box, int scrollX, int scrollY) {
    if (box->isTextRun) {
        int x = box->x - scrollX;
        int y = box->y - scrollY;

        if (box->isImage) {
            // TODO(Phase 6+): 실제 이미지 디코딩. 지금은 크기가 맞는 회색 박스 + alt 텍스트.
            RECT r{ x, y, x + box->contentWidth, y + box->contentHeight };
            HBRUSH bg = CreateSolidBrush(RGB(235, 235, 235));
            FillRect(hdc, &r, bg);
            DeleteObject(bg);
            HPEN pen = CreatePen(PS_SOLID, 1, RGB(180, 180, 180));
            HPEN oldPen = (HPEN)SelectObject(hdc, pen);
            HBRUSH oldBrush = (HBRUSH)SelectObject(hdc, GetStockObject(NULL_BRUSH));
            Rectangle(hdc, r.left, r.top, r.right, r.bottom);
            SelectObject(hdc, oldBrush);
            SelectObject(hdc, oldPen);
            DeleteObject(pen);

            if (!box->text.empty()) {
                HFONT font = MakeFont(12, false, false);
                HFONT oldFont = (HFONT)SelectObject(hdc, font);
                SetBkMode(hdc, TRANSPARENT);
                SetTextColor(hdc, RGB(120, 120, 120));
                RECT textRect = r;
                DrawTextW(hdc, box->text.c_str(), (int)box->text.size(), &textRect,
                          DT_CENTER | DT_VCENTER | DT_WORDBREAK);
                SelectObject(hdc, oldFont);
            }
            return;
        }

        HFONT font = MakeFont(box->fontSizePx, box->fontBold, box->fontItalic);
        HFONT oldFont = (HFONT)SelectObject(hdc, font);

        SetBkMode(hdc, TRANSPARENT);
        SetTextColor(hdc, ToColorRef(box->color));

        TextOutW(hdc, x, y, box->text.c_str(), (int)box->text.size());

        if (box->textDecorationUnderline) {
            SIZE size{ 0, 0 };
            GetTextExtentPoint32W(hdc, box->text.c_str(), (int)box->text.size(), &size);
            HPEN pen = CreatePen(PS_SOLID, 1, ToColorRef(box->color));
            HPEN oldPen = (HPEN)SelectObject(hdc, pen);
            int underlineY = y + box->contentHeight - 2;
            MoveToEx(hdc, x, underlineY, nullptr);
            LineTo(hdc, x + size.cx, underlineY);
            SelectObject(hdc, oldPen);
            DeleteObject(pen);
        }

        SelectObject(hdc, oldFont);
        return; // 텍스트런은 자식이 없으므로 여기서 끝
    }

    int outerLeft = box->OuterLeft() - scrollX;
    int outerTop = box->OuterTop() - scrollY;
    int borderBoxW = box->BorderBoxWidth();
    int borderBoxH = box->BorderBoxHeight();

    RECT borderRect{ outerLeft + box->margin.left, outerTop + box->margin.top,
                      outerLeft + box->margin.left + borderBoxW, outerTop + box->margin.top + borderBoxH };

    if (box->backgroundColor) {
        HBRUSH brush = CreateSolidBrush(ToColorRef(*box->backgroundColor));
        FillRect(hdc, &borderRect, brush);
        DeleteObject(brush);
    }

    if (box->borderWidthPx > 0 && box->borderColor) {
        HPEN pen = CreatePen(PS_SOLID, box->borderWidthPx, ToColorRef(*box->borderColor));
        HPEN oldPen = (HPEN)SelectObject(hdc, pen);
        HBRUSH oldBrush = (HBRUSH)SelectObject(hdc, GetStockObject(NULL_BRUSH));
        Rectangle(hdc, borderRect.left, borderRect.top, borderRect.right, borderRect.bottom);
        SelectObject(hdc, oldBrush);
        SelectObject(hdc, oldPen);
        DeleteObject(pen);
    }

    for (auto& child : box->children) PaintBox(hdc, child.get(), scrollX, scrollY);
}

void GdiPainter::Paint(HDC hdc, const LayoutBox* box, int scrollX, int scrollY) {
    if (!box) return;
    PaintBox(hdc, box, scrollX, scrollY);
}

} // namespace Xtentix
