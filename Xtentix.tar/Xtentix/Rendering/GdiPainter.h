#pragma once
#include <windows.h>
#include "LayoutBox.h"
#include "LayoutEngine.h"

namespace Xtentix {

// LayoutEngine이 만든 박스 트리를 GDI로 그린다. 레이아웃(좌표 계산)과 페인트(실제
// 그리기)를 분리해두면, 나중에 스크롤/캐싱/부분 다시그리기를 페인터 쪽만 건드려서
// 확장할 수 있다.
//   지원: 배경색, 테두리(단색 실선), 텍스트(굵게/기울임/밑줄, 색상)
//   미지원(TODO): 이미지, 그림자, border-radius, 그라디언트
class GdiPainter {
public:
    static void Paint(HDC hdc, const LayoutBox* box, int scrollX = 0, int scrollY = 0);

    // 실제 GDI 폰트 메트릭을 쓰는 텍스트 측정 함수. LayoutEngine::TextMeasureFn과
    // 시그니처가 맞아서 그대로 주입해서 쓰면 됨.
    static TextMetrics Measure(HDC hdc, const std::wstring& text, int fontSizePx, bool bold, bool italic);

private:
    static void PaintBox(HDC hdc, const LayoutBox* box, int scrollX, int scrollY);
};

} // namespace Xtentix
