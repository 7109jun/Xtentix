#pragma once
#include "Dom.h"
#include "CssValues.h"
#include <string>
#include <vector>
#include <memory>
#include <optional>

namespace Xtentix {

enum class DisplayType { Block, Inline, None };

struct EdgeSizes {
    int top = 0, right = 0, bottom = 0, left = 0;
};

// 레이아웃 트리의 노드 하나. 실제 요소 박스와, 텍스트 한 줄(line box)을 표현하는
// 익명 박스를 함께 다룬다 (isTextRun=true면 후자).
class LayoutBox {
public:
    const DomNode* domNode = nullptr; // 익명 박스(라인/텍스트 조각)면 nullptr일 수 있음
    DisplayType display = DisplayType::Block;

    bool isTextRun = false;
    std::wstring text;           // isTextRun일 때만 사용 (isImage면 alt 텍스트로 재사용)
    std::string linkHref;        // <a> 안의 텍스트런이면 href, 아니면 빈 문자열
    bool isImage = false;        // true면 텍스트런 자리에 이미지 자리표시자 박스를 그림

    // 배치 결과 (LayoutEngine이 채움) - 콘텐츠 박스 기준 좌표/크기
    int x = 0, y = 0, contentWidth = 0, contentHeight = 0;
    EdgeSizes margin, border, padding;

    // 페인트에 필요한 계산된 스타일 값
    std::optional<RgbColor> backgroundColor;
    RgbColor color{ 0, 0, 0 };
    int fontSizePx = 16;
    bool fontBold = false;
    bool fontItalic = false;
    std::string textAlign = "left";
    int borderWidthPx = 0;
    std::optional<RgbColor> borderColor;
    bool textDecorationUnderline = false;

    std::vector<std::unique_ptr<LayoutBox>> children;

    // 콘텐츠 박스 기준 x,y를 마진/보더/패딩까지 포함한 바깥 경계로 확장.
    int OuterLeft() const { return x - padding.left - border.left - margin.left; }
    int OuterTop() const { return y - padding.top - border.top - margin.top; }
    int BorderBoxWidth() const { return contentWidth + padding.left + padding.right + border.left + border.right; }
    int BorderBoxHeight() const { return contentHeight + padding.top + padding.bottom + border.top + border.bottom; }
};

} // namespace Xtentix
