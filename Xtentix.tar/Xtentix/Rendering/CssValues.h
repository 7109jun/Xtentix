#pragma once
#include <string>
#include <optional>

namespace Xtentix {

// Win32에 묶이지 않은 순수 RGB 표현. GdiPainter에서만 COLORREF로 변환한다.
// (LayoutEngine/CssValues를 Windows 헤더에서 분리해두면 리눅스에서도 네이티브로
//  단위 테스트할 수 있어서 — 지금까지 HtmlParser/CssParser도 이 방식으로 검증함)
struct RgbColor {
    unsigned char r = 0, g = 0, b = 0;
};

// LayoutEngine/GdiPainter가 공유하는 CSS 값 파싱.
//   지원: "Npx" 길이, "#rgb"/"#rrggbb"/"rgb(r,g,b)"/기본 색상 이름
//   미지원(TODO): %, em, rem, calc() 등 — 지금 레이아웃 엔진이 px 고정 모델이라 보류.
class CssValues {
public:
    static std::optional<int> ParseLengthPx(const std::string& value);
    static std::optional<double> ParsePercentage(const std::string& value); // "50%" -> 50.0
    static std::optional<RgbColor> ParseColor(const std::string& value);
};

} // namespace Xtentix
