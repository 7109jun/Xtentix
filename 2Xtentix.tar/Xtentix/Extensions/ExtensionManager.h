#pragma once
#include <string>
#include <vector>
#include <mutex>

// Lua 5.4 C API (Extensions/lua/에 vendor된 순정 소스, 외부 라이브러리 아님 -
// exe에 직접 컴파일되어 들어가고 시스템에 설치된 Lua와는 무관).
extern "C" {
#include "lua/lua.h"
#include "lua/lauxlib.h"
#include "lua/lualib.h"
}

namespace Xtentix {

struct ExtensionInfo {
    std::string filePath;
    std::string fileName;
    std::string name;
    std::string version;
    std::string description;
    bool enabled = true;
    bool loadError = false;
    std::string errorMessage;
};

// 크롬 확장 프로그램과 비슷한 개념이지만, manifest.json + 여러 JS 파일 대신
// 단일 .lua 파일 하나가 확장 프로그램 하나. %APPDATA%/Xtentix/Extensions/*.lua를
// 스캔해서 각각 독립된 lua_State에 로드하고, 페이지 로드마다 on_page_load(url, html)
// 훅을 순서대로 호출해서 HTML을 가로채거나 바꿀 수 있게 한다.
//
// 샌드박스: luaL_openlibs()로 전체를 열지 않고 base/string/table/math/utf8만 연다.
// io/os/package(require)/debug는 일부러 안 열어서 확장이 파일시스템이나 프로세스를
// 건드리지 못하게 막는다 - "확장 프로그램이 컴퓨터에 뭔가 하면 안 된다"는 원칙.
class ExtensionManager {
public:
    ~ExtensionManager();

    void LoadAll();
    static std::string ExtensionsDir();

    const std::vector<ExtensionInfo>& Extensions() const { return m_extensions; }
    void SetEnabled(const std::string& filePath, bool enabled);

    // 활성화된 확장들의 on_page_load(url, html)을 순서대로 호출해서 체이닝.
    // 스레드 안전(여러 탭이 동시에 로드될 수 있어서 내부적으로 직렬화됨).
    std::string RunOnPageLoad(const std::string& url, const std::string& html);

    // 확장의 xtentix.log()가 쌓는 로그. DevTools에서 보여줄 수 있게 공개.
    std::vector<std::string> DrainLogs();

private:
    struct LoadedExtension {
        ExtensionInfo info;
        lua_State* L = nullptr;
    };

    void UnloadAll();
    void AppendLog(const std::string& line);
    static int Lua_XtentixLog(lua_State* L);

    std::vector<LoadedExtension> m_loaded;
    std::vector<ExtensionInfo> m_extensions; // UI가 읽는 요약 목록 (m_loaded와 동기화됨)
    std::vector<std::string> m_pendingLogs;
    std::recursive_mutex m_mutex; // RunOnPageLoad가 락을 쥔 채로 xtentix.log()(AppendLog)가
                                   // 같은 락을 다시 잡는 재진입 경로가 있어서 recursive 필요
};

} // namespace Xtentix
