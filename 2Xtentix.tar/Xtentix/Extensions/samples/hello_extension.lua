-- Xtentix 확장 프로그램 예제. 이 파일 하나가 확장 프로그램 하나 (크롬처럼 manifest.json이
-- 따로 없음). %APPDATA%\Xtentix\Extensions\ 폴더에 이 파일을 넣으면 자동으로 로드됨.

EXT_NAME = "Hello Extension"
EXT_VERSION = "1.0"
EXT_DESCRIPTION = "페이지가 로드될 때마다 맨 위에 배너를 하나 삽입하는 예제 확장"

-- 페이지가 로드될 때마다 호출됨. url과 원본 html을 받아서, 문자열을 반환하면
-- 그 문자열이 새 html로 쓰인다 (아무것도 반환 안 하면 원본 그대로 유지).
function on_page_load(url, html)
    xtentix.log("페이지 로드됨: " .. url)

    local banner = "<div style='background:#ffeb3b;padding:8px;text-align:center'>"
                 .. "Hello Extension 적용됨 (" .. url .. ")</div>"

    local bodyStart = string.find(html, "<body[^>]*>")
    if bodyStart then
        local tagEnd = string.find(html, ">", bodyStart)
        return string.sub(html, 1, tagEnd) .. banner .. string.sub(html, tagEnd + 1)
    end
    return html
end
