#include "ExtensionManager.h"
#include <filesystem>
#include <fstream>
#include <cstdlib>
#include <sstream>

namespace Xtentix {

namespace {

// base/string/table/math/utf8만 연다. io/os/package(require)/debug는 일부러 뺌 -
// 확장이 파일시스템/프로세스/DLL 로딩을 건드릴 수 없게 하는 샌드박스 경계.
void OpenSafeLibs(lua_State* L) {
    luaL_requiref(L, LUA_GNAME, luaopen_base, 1); lua_pop(L, 1);
    luaL_requiref(L, LUA_TABLIBNAME, luaopen_table, 1); lua_pop(L, 1);
    luaL_requiref(L, LUA_STRLIBNAME, luaopen_string, 1); lua_pop(L, 1);
    luaL_requiref(L, LUA_MATHLIBNAME, luaopen_math, 1); lua_pop(L, 1);
    luaL_requiref(L, LUA_UTF8LIBNAME, luaopen_utf8, 1); lua_pop(L, 1);
}

std::string ReadFile(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file) return "";
    return std::string((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
}

std::string GetGlobalStringOr(lua_State* L, const char* name, const std::string& fallback) {
    lua_getglobal(L, name);
    std::string result = fallback;
    if (lua_isstring(L, -1)) result = lua_tostring(L, -1);
    lua_pop(L, 1);
    return result;
}

} // namespace

int ExtensionManager::Lua_XtentixLog(lua_State* L) {
    const char* msg = luaL_optstring(L, 1, "");
    auto* self = reinterpret_cast<ExtensionManager*>(lua_touserdata(L, lua_upvalueindex(1)));
    if (self) self->AppendLog(msg);
    return 0;
}

void ExtensionManager::AppendLog(const std::string& line) {
    std::lock_guard<std::recursive_mutex> lock(m_mutex);
    m_pendingLogs.push_back(line);
}

std::vector<std::string> ExtensionManager::DrainLogs() {
    std::lock_guard<std::recursive_mutex> lock(m_mutex);
    std::vector<std::string> logs = std::move(m_pendingLogs);
    m_pendingLogs.clear();
    return logs;
}

std::string ExtensionManager::ExtensionsDir() {
    const char* appdata = std::getenv("APPDATA");
    std::filesystem::path base = appdata ? std::filesystem::path(appdata) : std::filesystem::current_path();
    std::filesystem::path dir = base / "Xtentix" / "Extensions";
    std::error_code ec;
    std::filesystem::create_directories(dir, ec);
    return dir.string();
}

void ExtensionManager::UnloadAll() {
    for (auto& ext : m_loaded) {
        if (ext.L) lua_close(ext.L);
    }
    m_loaded.clear();
    m_extensions.clear();
}

ExtensionManager::~ExtensionManager() {
    UnloadAll();
}

void ExtensionManager::LoadAll() {
    std::lock_guard<std::recursive_mutex> lock(m_mutex);
    UnloadAll();

    std::error_code ec;
    std::string dir = ExtensionsDir();
    if (!std::filesystem::exists(dir, ec)) return;

    for (auto& entry : std::filesystem::directory_iterator(dir, ec)) {
        if (!entry.is_regular_file()) continue;
        if (entry.path().extension() != ".lua") continue;

        LoadedExtension ext;
        ext.info.filePath = entry.path().string();
        ext.info.fileName = entry.path().filename().string();

        std::string source = ReadFile(ext.info.filePath);

        lua_State* L = luaL_newstate();
        OpenSafeLibs(L);

        // xtentix.log(msg) 하나만 노출 (확장이 브라우저 쪽으로 할 수 있는 유일한 일).
        lua_newtable(L);
        lua_pushlightuserdata(L, this);
        lua_pushcclosure(L, &ExtensionManager::Lua_XtentixLog, 1);
        lua_setfield(L, -2, "log");
        lua_setglobal(L, "xtentix");

        if (luaL_loadstring(L, source.c_str()) != LUA_OK || lua_pcall(L, 0, 0, 0) != LUA_OK) {
            ext.info.loadError = true;
            ext.info.errorMessage = lua_isstring(L, -1) ? lua_tostring(L, -1) : "\uC54C \uC218 \uC5C6\uB294 \uC624\uB958";
            ext.info.name = ext.info.fileName;
            lua_close(L);
            L = nullptr;
        } else {
            ext.info.name = GetGlobalStringOr(L, "EXT_NAME", ext.info.fileName);
            ext.info.version = GetGlobalStringOr(L, "EXT_VERSION", "1.0");
            ext.info.description = GetGlobalStringOr(L, "EXT_DESCRIPTION", "");
        }

        ext.L = L;
        m_extensions.push_back(ext.info);
        m_loaded.push_back(std::move(ext));
    }
}

void ExtensionManager::SetEnabled(const std::string& filePath, bool enabled) {
    std::lock_guard<std::recursive_mutex> lock(m_mutex);
    for (auto& ext : m_loaded) {
        if (ext.info.filePath == filePath) ext.info.enabled = enabled;
    }
    for (auto& info : m_extensions) {
        if (info.filePath == filePath) info.enabled = enabled;
    }
}

std::string ExtensionManager::RunOnPageLoad(const std::string& url, const std::string& html) {
    std::lock_guard<std::recursive_mutex> lock(m_mutex); // lua_State는 스레드 안전하지 않으므로 직렬화
    std::string current = html;

    for (auto& ext : m_loaded) {
        if (!ext.info.enabled || !ext.L || ext.info.loadError) continue;

        lua_getglobal(ext.L, "on_page_load");
        if (!lua_isfunction(ext.L, -1)) { lua_pop(ext.L, 1); continue; }

        lua_pushstring(ext.L, url.c_str());
        lua_pushstring(ext.L, current.c_str());

        if (lua_pcall(ext.L, 2, 1, 0) != LUA_OK) {
            std::string err = lua_isstring(ext.L, -1) ? lua_tostring(ext.L, -1) : "on_page_load \uC2E4\uD589 \uC624\uB958";
            m_pendingLogs.push_back("[" + ext.info.name + "] " + err);
            lua_pop(ext.L, 1);
            continue;
        }

        if (lua_isstring(ext.L, -1)) current = lua_tostring(ext.L, -1); // 문자열 반환 시에만 교체
        lua_pop(ext.L, 1);
    }

    return current;
}

} // namespace Xtentix
