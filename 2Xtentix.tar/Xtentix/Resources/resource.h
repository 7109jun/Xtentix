#pragma once

#define IDI_APP_ICON  101
#define IDR_LOGO_PNG  201
