#include "PageLinter.h"
#include <unordered_map>
#include <unordered_set>
#include <algorithm>

namespace Xtentix {

namespace {

struct LintState {
    std::vector<std::string> issues;
    std::unordered_map<std::string, int> idCounts;
    bool sawTitle = false;
    bool titleHasText = false;
};

std::string GetText(const DomNode* node) {
    std::string out;
    for (auto& c : node->Children()) if (c->Type() == NodeType::Text) out += c->Data();
    return out;
}

bool IsBlankOrWhitespace(const std::string& s) {
    return s.find_first_not_of(" \t\r\n") == std::string::npos;
}

void Walk(const DomNode* node, LintState& state) {
    if (node->Type() == NodeType::Element) {
        const std::string& tag = node->TagName();

        if (tag == "title") {
            state.sawTitle = true;
            if (!IsBlankOrWhitespace(GetText(node))) state.titleHasText = true;
        }

        if (tag == "img" && !node->HasAttribute("alt")) {
            state.issues.push_back("<img src=\"" + node->GetAttribute("src") + "\">에 alt 속성이 없습니다 (접근성/SEO 문제)");
        }

        if (tag == "a") {
            std::string href = node->GetAttribute("href");
            if (!node->HasAttribute("href") || href.empty()) {
                state.issues.push_back("<a> 태그에 href가 없거나 비어 있습니다");
            }
        }

        if (node->HasAttribute("id")) {
            std::string id = node->GetAttribute("id");
            if (!id.empty()) {
                int count = ++state.idCounts[id];
                if (count == 2) { // 세 번째 이상 중복은 같은 메시지 반복 안 하게 2일 때만 기록
                    state.issues.push_back("id=\"" + id + "\"가 중복 사용되고 있습니다 (id는 문서 내에서 고유해야 함)");
                }
            }
        }

        static const std::unordered_set<std::string> kDeprecated = { "font", "center", "marquee", "blink" };
        if (kDeprecated.count(tag)) {
            state.issues.push_back("<" + tag + ">는 사용 중단(deprecated)된 태그입니다 - CSS로 대체 권장");
        }

        static const std::vector<std::string> kInlineEventAttrs = {
            "onclick", "onload", "onerror", "onmouseover", "onmouseout", "onchange", "onsubmit"
        };
        for (auto& attr : kInlineEventAttrs) {
            if (node->HasAttribute(attr)) {
                state.issues.push_back("<" + tag + ">에 인라인 이벤트 핸들러(" + attr + ")가 있습니다 - 유지보수성 저하 우려");
            }
        }
    }

    for (auto& c : node->Children()) Walk(c.get(), state);
}

} // namespace

std::vector<std::string> PageLinter::FindIssues(const DomNode* root) {
    if (!root) return { "문서가 비어 있습니다" };

    LintState state;
    Walk(root, state);

    if (!state.sawTitle) state.issues.insert(state.issues.begin(), "<title>이 없습니다");
    else if (!state.titleHasText) state.issues.insert(state.issues.begin(), "<title>이 비어 있습니다");

    if (state.issues.empty()) state.issues.push_back("발견된 문제가 없습니다");
    return state.issues;
}

} // namespace Xtentix
