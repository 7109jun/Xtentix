#pragma once
#include "LayoutBox.h"
#include "StyleResolver.h"
#include <functional>
#include <memory>

namespace Xtentix {

// 텍스트 폭 측정을 외부에서 주입받는다. 실제로는 GDI GetTextExtentPoint32를 쓰지만,
// LayoutEngine 자체는 Windows 헤더에 의존하지 않게 해서 리눅스에서도 네이티브로
// (가짜 측정 함수를 넣어) 검증할 수 있게 한다 — HtmlParser/CssParser와 같은 전략.
struct TextMetrics {
    int width = 0;
    int lineHeight = 0;
};
using TextMeasureFn = std::function<TextMetrics(const std::wstring& text, int fontSizePx, bool bold, bool italic)>;

// 블록/인라인 포매팅 컨텍스트의 실용적 부분집합을 구현.
//   지원: block 스태킹, 자동/명시적 width, margin/padding/border(단일값만),
//         인라인 콘텐츠의 자동 줄바꿈(그리디), text-align(left/center/right)
//   미지원(TODO): float, position, flex/grid, margin collapsing, table 레이아웃,
//         %/em 단위, 이미지 실제 디코딩(자리 표시 박스만).
class LayoutEngine {
public:
    static std::unique_ptr<LayoutBox> BuildLayout(const DomNode* documentRoot,
                                                    const StyleResolver::StyleMap& styles,
                                                    int viewportWidth,
                                                    const TextMeasureFn& measure);
};

} // namespace Xtentix
