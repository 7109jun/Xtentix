#include "LayoutEngine.h"
#include "CssValues.h"
#include <sstream>
#include <algorithm>

namespace Xtentix {

namespace {

using ComputedStyle = StyleResolver::ComputedStyle;

std::string Get(const ComputedStyle& s, const std::string& key) {
    auto it = s.find(key);
    return it != s.end() ? it->second : "";
}

const ComputedStyle& StyleOf(const StyleResolver::StyleMap& styles, const DomNode* node) {
    static const ComputedStyle kEmpty;
    auto it = styles.find(node);
    return it != styles.end() ? it->second : kEmpty;
}

bool IsWhitespaceOnly(const std::string& s) {
    return s.find_first_not_of(" \t\r\n") == std::string::npos;
}

// UTF-8 -> wchar_t. LayoutEngine을 Windows 헤더에 묶고 싶지 않아 직접 구현
// (Windows에서는 BMP 밖 코드포인트에 서로게이트 페어가 필요하지만, 지금 다루는
//  콘텐츠 범위에선 충분 — TODO: 이모지 등 astral 문자 완전 지원).
std::wstring Utf8ToWstring(const std::string& s) {
    std::wstring out;
    out.reserve(s.size());
    size_t i = 0;
    while (i < s.size()) {
        unsigned char c = (unsigned char)s[i];
        unsigned int cp = 0; int extra = 0;
        if (c < 0x80) { cp = c; extra = 0; }
        else if ((c & 0xE0) == 0xC0) { cp = c & 0x1F; extra = 1; }
        else if ((c & 0xF0) == 0xE0) { cp = c & 0x0F; extra = 2; }
        else if ((c & 0xF8) == 0xF0) { cp = c & 0x07; extra = 3; }
        else { i++; continue; } // 잘못된 바이트는 건너뜀
        i++;
        bool valid = true;
        for (int k = 0; k < extra && i < s.size(); ++k, ++i) {
            unsigned char cc = (unsigned char)s[i];
            if ((cc & 0xC0) != 0x80) { valid = false; break; }
            cp = (cp << 6) | (cc & 0x3F);
        }
        if (valid) out += (wchar_t)cp;
    }
    return out;
}

bool IsBoldWeight(const std::string& value) {
    if (value == "bold" || value == "bolder") return true;
    char* end = nullptr;
    long n = std::strtol(value.c_str(), &end, 10);
    return end != value.c_str() && n >= 700;
}

DisplayType ParseDisplay(const std::string& value) {
    if (value == "none") return DisplayType::None;
    if (value == "block") return DisplayType::Block;
    return DisplayType::Inline; // HTML5 기본값과 동일하게 미지정 시 inline
}

EdgeSizes ReadEdgeSizes(const ComputedStyle& style, const std::string& prefix) {
    int shorthand = CssValues::ParseLengthPx(Get(style, prefix)).value_or(0);
    EdgeSizes e{ shorthand, shorthand, shorthand, shorthand };
    auto apply = [&](const char* side, int& target) {
        auto v = CssValues::ParseLengthPx(Get(style, prefix + "-" + side));
        if (v) target = *v;
    };
    apply("top", e.top);
    apply("right", e.right);
    apply("bottom", e.bottom);
    apply("left", e.left);
    return e;
}

int ReadBorderWidth(const ComputedStyle& style) {
    std::istringstream iss(Get(style, "border"));
    std::string token;
    while (iss >> token) {
        auto v = CssValues::ParseLengthPx(token);
        if (v) return *v;
    }
    return 0;
}

std::optional<RgbColor> ReadBorderColor(const ComputedStyle& style) {
    std::istringstream iss(Get(style, "border"));
    std::string token;
    while (iss >> token) {
        auto c = CssValues::ParseColor(token);
        if (c) return c;
    }
    return std::nullopt;
}

// 인라인 콘텐츠를 한 줄씩(line box) 배치할 때 쓰는 최소 단위: 공백으로 분리된 단어 하나.
struct InlineAtom {
    std::wstring word; // isImage면 alt 텍스트로 재사용
    bool isBreak = false; // <br>
    bool isImage = false; // <img>
    int imgWidth = 0, imgHeight = 0;
    int fontSizePx = 16;
    bool bold = false;
    bool italic = false;
    bool underline = false;
    RgbColor color{ 0, 0, 0 };
    std::string href; // 가장 가까운 <a> 조상의 href (없으면 빈 문자열)
};

void CollectInlineAtoms(const DomNode* node, const StyleResolver::StyleMap& styles,
                         std::vector<InlineAtom>& atoms, const std::string& currentHref = "") {
    if (node->Type() == NodeType::Text) {
        const DomNode* parent = node->Parent();
        const ComputedStyle& style = parent ? StyleOf(styles, parent) : ComputedStyle{};

        InlineAtom base;
        base.fontSizePx = CssValues::ParseLengthPx(Get(style, "font-size")).value_or(16);
        base.bold = IsBoldWeight(Get(style, "font-weight"));
        base.italic = Get(style, "font-style") == "italic";
        base.underline = Get(style, "text-decoration").find("underline") != std::string::npos;
        base.color = CssValues::ParseColor(Get(style, "color")).value_or(RgbColor{ 0, 0, 0 });
        base.href = currentHref;

        std::istringstream words(node->Data());
        std::string word;
        while (words >> word) {
            InlineAtom atom = base;
            atom.word = Utf8ToWstring(word);
            atoms.push_back(std::move(atom));
        }
        return;
    }

    if (node->Type() != NodeType::Element) return;

    if (node->TagName() == "br") {
        InlineAtom breakAtom;
        breakAtom.isBreak = true;
        atoms.push_back(breakAtom);
        return;
    }
    // TODO(Phase 6+): 실제 PNG/JPEG 디코딩. 지금은 width/height(속성 또는 스타일)로
    // 크기만 정확히 잡은 자리표시자 박스를 인라인 흐름에 참여시킨다 (레이아웃이
    // 실제 이미지 있는 페이지와 크게 어긋나지 않게 하는 게 목적).
    if (node->TagName() == "img") {
        const ComputedStyle& style = StyleOf(styles, node);
        int w = CssValues::ParseLengthPx(node->GetAttribute("width")).value_or(
                CssValues::ParseLengthPx(Get(style, "width")).value_or(120));
        int h = CssValues::ParseLengthPx(node->GetAttribute("height")).value_or(
                CssValues::ParseLengthPx(Get(style, "height")).value_or(90));
        InlineAtom img;
        img.isImage = true;
        img.imgWidth = (std::max)(1, w);
        img.imgHeight = (std::max)(1, h);
        img.word = Utf8ToWstring(node->GetAttribute("alt"));
        img.href = currentHref;
        atoms.push_back(std::move(img));
        return;
    }

    std::string hrefForChildren = currentHref;
    if (node->TagName() == "a" && node->HasAttribute("href")) hrefForChildren = node->GetAttribute("href");

    for (auto& child : node->Children()) CollectInlineAtoms(child.get(), styles, atoms, hrefForChildren);
}

// pendingInline에 모인 텍스트/인라인 요소들을 줄바꿈해서 anonBox의 자식(줄 단위 박스,
// 그 안에 단어별 텍스트런 박스)으로 채운다. anonBox->contentHeight를 계산해서 채워준다.
void LayoutInlineRun(const std::vector<const DomNode*>& nodes, LayoutBox* anonBox,
                      const StyleResolver::StyleMap& styles, int containingWidth,
                      const TextMeasureFn& measure, const std::string& textAlign) {
    std::vector<InlineAtom> atoms;
    for (auto* n : nodes) CollectInlineAtoms(n, styles, atoms);

    struct PlacedWord { const InlineAtom* atom; int xOffset; int width; int lineHeight; };
    std::vector<std::vector<PlacedWord>> lines;
    std::vector<PlacedWord> currentLine;
    int currentLineWidth = 0;
    int currentLineHeight = 0;

    auto flushLine = [&]() {
        lines.push_back(std::move(currentLine));
        currentLine.clear();
        currentLineWidth = 0;
        currentLineHeight = 0;
    };

    for (auto& atom : atoms) {
        if (atom.isBreak) { flushLine(); continue; }

        TextMetrics m = atom.isImage
            ? TextMetrics{ atom.imgWidth, atom.imgHeight }
            : measure(atom.word, atom.fontSizePx, atom.bold, atom.italic);
        int spaceWidth = currentLine.empty() ? 0 : measure(L" ", atom.fontSizePx, atom.bold, atom.italic).width;
        int candidateWidth = currentLineWidth + spaceWidth + m.width;

        if (!currentLine.empty() && candidateWidth > containingWidth) {
            flushLine();
            spaceWidth = 0;
            candidateWidth = m.width;
        }

        int xOffset = currentLineWidth + spaceWidth;
        currentLine.push_back({ &atom, xOffset, m.width, m.lineHeight });
        currentLineWidth = xOffset + m.width;
        currentLineHeight = (std::max)(currentLineHeight, m.lineHeight);
    }
    if (!currentLine.empty() || lines.empty()) flushLine();

    int cursorY = 0;
    for (auto& line : lines) {
        int lineHeight = 0;
        int usedWidth = 0;
        for (auto& w : line) {
            lineHeight = (std::max)(lineHeight, w.lineHeight);
            usedWidth = (std::max)(usedWidth, w.xOffset + w.width);
        }
        if (lineHeight == 0) lineHeight = 18; // 빈 줄(연속 <br>) 기본 높이

        int alignShift = 0;
        if (textAlign == "center") alignShift = (std::max)(0, (containingWidth - usedWidth) / 2);
        else if (textAlign == "right") alignShift = (std::max)(0, containingWidth - usedWidth);

        auto lineBox = std::make_unique<LayoutBox>();
        lineBox->display = DisplayType::Block;
        lineBox->x = anonBox->x;
        lineBox->y = anonBox->y + cursorY;
        lineBox->contentWidth = containingWidth;
        lineBox->contentHeight = lineHeight;

        for (auto& w : line) {
            auto wordBox = std::make_unique<LayoutBox>();
            wordBox->isTextRun = true;
            wordBox->isImage = w.atom->isImage;
            wordBox->text = w.atom->word;
            wordBox->x = lineBox->x + alignShift + w.xOffset;
            wordBox->y = lineBox->y;
            wordBox->contentWidth = w.width;
            wordBox->contentHeight = w.lineHeight;
            wordBox->fontSizePx = w.atom->fontSizePx;
            wordBox->fontBold = w.atom->bold;
            wordBox->fontItalic = w.atom->italic;
            wordBox->textDecorationUnderline = w.atom->underline;
            wordBox->color = w.atom->color;
            wordBox->linkHref = w.atom->href;
            lineBox->children.push_back(std::move(wordBox));
        }

        cursorY += lineHeight;
        anonBox->children.push_back(std::move(lineBox));
    }

    anonBox->contentHeight = cursorY;
}

std::unique_ptr<LayoutBox> MakeBlockBox(const DomNode* el, const StyleResolver::StyleMap& styles, int containingWidth) {
    const ComputedStyle& style = StyleOf(styles, el);

    auto box = std::make_unique<LayoutBox>();
    box->domNode = el;
    box->display = DisplayType::Block;

    box->margin = ReadEdgeSizes(style, "margin");
    box->padding = ReadEdgeSizes(style, "padding");
    int borderW = ReadBorderWidth(style);
    box->border = EdgeSizes{ borderW, borderW, borderW, borderW }; // TODO: 변 별 border-width 지원
    box->borderWidthPx = borderW;
    box->borderColor = ReadBorderColor(style);
    box->borderRadiusPx = (std::max)(0, CssValues::ParseLengthPx(Get(style, "border-radius")).value_or(0));
    box->boxShadow = CssValues::ParseBoxShadow(Get(style, "box-shadow"));

    int availableForBorderBox = (std::max)(0, containingWidth - box->margin.left - box->margin.right);
    auto explicitWidth = CssValues::ParseLengthPx(Get(style, "width"));
    auto percentWidth = CssValues::ParsePercentage(Get(style, "width"));
    bool hasDefiniteWidth = explicitWidth.has_value() || percentWidth.has_value();

    if (explicitWidth) {
        box->contentWidth = (std::max)(0, *explicitWidth);
    } else if (percentWidth) {
        // 콘텐츠 박스 기준: containing block "content" 너비의 %를 그대로 이 박스의 content 너비로.
        box->contentWidth = (std::max)(0, (int)(containingWidth * (*percentWidth / 100.0)));
    } else {
        box->contentWidth = (std::max)(0, availableForBorderBox
            - box->padding.left - box->padding.right - box->border.left - box->border.right);
    }

    // margin: auto (양쪽 다 auto일 때) -> 명시적 너비가 있는 블록을 가운데 정렬.
    std::string marginShorthand = Get(style, "margin");
    bool marginLeftAuto = Get(style, "margin-left") == "auto" || (marginShorthand == "auto" && !style.count("margin-left"));
    bool marginRightAuto = Get(style, "margin-right") == "auto" || (marginShorthand == "auto" && !style.count("margin-right"));
    if (hasDefiniteWidth && marginLeftAuto && marginRightAuto) {
        int usedSpace = box->contentWidth + box->padding.left + box->padding.right + box->border.left + box->border.right;
        int extra = (std::max)(0, containingWidth - usedSpace);
        box->margin.left = box->margin.right = extra / 2;
    }

    auto explicitHeight = CssValues::ParseLengthPx(Get(style, "height"));
    box->contentHeight = explicitHeight ? (std::max)(0, *explicitHeight) : -1; // -1 = auto(나중에 채움)

    box->backgroundColor = CssValues::ParseColor(Get(style, "background-color"));
    box->color = CssValues::ParseColor(Get(style, "color")).value_or(RgbColor{ 0, 0, 0 });
    box->fontSizePx = CssValues::ParseLengthPx(Get(style, "font-size")).value_or(16);
    box->fontBold = IsBoldWeight(Get(style, "font-weight"));
    box->fontItalic = Get(style, "font-style") == "italic";
    box->textAlign = style.count("text-align") ? Get(style, "text-align") : "left";
    box->textDecorationUnderline = Get(style, "text-decoration").find("underline") != std::string::npos;

    return box;
}

void LayoutBlockChildren(const DomNode* containerNode, LayoutBox* containerBox,
                          const StyleResolver::StyleMap& styles, int containingWidth,
                          const TextMeasureFn& measure, int& cursorY) {
    std::vector<const DomNode*> pendingInline;
    int orderedListCounter = 1; // ol > li 번호 매김. 재귀 호출마다 새 스코프라 중첩 리스트에서도 자연히 리셋됨.

    auto flushPending = [&]() {
        if (pendingInline.empty()) return;

        std::string align = "left";
        if (containerNode->Type() == NodeType::Element) {
            align = StyleOf(styles, containerNode).count("text-align")
                    ? Get(StyleOf(styles, containerNode), "text-align") : "left";
        }

        auto anon = std::make_unique<LayoutBox>();
        anon->display = DisplayType::Block;
        anon->x = containerBox->x;
        anon->y = containerBox->y + cursorY;
        anon->contentWidth = containingWidth;

        LayoutInlineRun(pendingInline, anon.get(), styles, containingWidth, measure, align);

        cursorY += anon->contentHeight;
        containerBox->children.push_back(std::move(anon));
        pendingInline.clear();
    };

    for (auto& childPtr : containerNode->Children()) {
        const DomNode* child = childPtr.get();

        if (child->Type() == NodeType::Text) {
            if (!IsWhitespaceOnly(child->Data())) pendingInline.push_back(child);
            continue;
        }
        if (child->Type() != NodeType::Element) continue; // Comment/Doctype 등은 렌더링 대상 아님

        DisplayType display = ParseDisplay(Get(StyleOf(styles, child), "display"));
        if (display == DisplayType::None) continue;
        if (display == DisplayType::Inline) { pendingInline.push_back(child); continue; }

        flushPending();

        bool isListItem = (child->TagName() == "li");
        std::wstring markerText;
        if (isListItem) {
            bool ordered = containerNode->Type() == NodeType::Element && containerNode->TagName() == "ol";
            if (ordered) { markerText = std::to_wstring(orderedListCounter) + L"."; orderedListCounter++; }
            else markerText = L"\u2022"; // 순서 없는 목록은 불릿(•)
        }

        auto childBox = MakeBlockBox(child, styles, containingWidth);
        childBox->x = containerBox->x + childBox->margin.left;
        childBox->y = containerBox->y + cursorY + childBox->margin.top;
        cursorY += childBox->margin.top;

        int childContentX = childBox->x + childBox->border.left + childBox->padding.left;
        int childContentY = childBox->y + childBox->border.top + childBox->padding.top;
        childBox->x = childContentX;
        childBox->y = childContentY;

        if (isListItem && !markerText.empty()) {
            // list-style-position:outside 흉내 - 마커는 li의 콘텐츠 흐름에 안 끼고
            // 왼쪽 여백(패딩) 안에 별도로 얹힌다. containerBox(ul/ol)의 자식으로 추가.
            TextMetrics mm = measure(markerText, childBox->fontSizePx, childBox->fontBold, childBox->fontItalic);
            auto markerBox = std::make_unique<LayoutBox>();
            markerBox->isTextRun = true;
            markerBox->text = markerText;
            markerBox->x = childContentX - mm.width - 6;
            markerBox->y = childContentY;
            markerBox->contentWidth = mm.width;
            markerBox->contentHeight = mm.lineHeight;
            markerBox->color = childBox->color;
            markerBox->fontSizePx = childBox->fontSizePx;
            containerBox->children.push_back(std::move(markerBox));
        }

        int childCursorY = 0;
        LayoutBlockChildren(child, childBox.get(), styles, childBox->contentWidth, measure, childCursorY);
        if (childBox->contentHeight < 0) childBox->contentHeight = childCursorY;

        cursorY += childBox->BorderBoxHeight() + childBox->margin.bottom;
        containerBox->children.push_back(std::move(childBox));
    }

    flushPending();
}

} // namespace

std::unique_ptr<LayoutBox> LayoutEngine::BuildLayout(const DomNode* documentRoot,
                                                       const StyleResolver::StyleMap& styles,
                                                       int viewportWidth,
                                                       const TextMeasureFn& measure) {
    auto viewport = std::make_unique<LayoutBox>();
    viewport->display = DisplayType::Block;
    viewport->x = 0;
    viewport->y = 0;
    viewport->contentWidth = viewportWidth;

    int cursorY = 0;
    LayoutBlockChildren(documentRoot, viewport.get(), styles, viewportWidth, measure, cursorY);
    viewport->contentHeight = cursorY;
    return viewport;
}

} // namespace Xtentix
