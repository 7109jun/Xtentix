#pragma once
#include "Dom.h"
#include "HtmlTokenizer.h"
#include <memory>
#include <vector>

namespace Xtentix {

// 토큰 스트림을 소비하며 스택 기반으로 DOM 트리를 구성.
// HTML5 스펙의 "insertion mode" 전체(초기/본문/테이블/... 20여개)는 구현하지 않고,
// 실전 페이지 대부분을 커버하는 두 가지 규칙만 적용:
//   1) void 요소(br, img 등)는 스택에 안 올라감
//   2) 특정 태그는 열려있는 동일/상위 카테고리 태그를 암묵적으로 닫음 (p, li, tr 등)
class HtmlParser {
public:
    // HTML 문자열 전체를 파싱해서 #document 루트 노드를 반환.
    static std::unique_ptr<DomNode> Parse(const std::string& html);

private:
    explicit HtmlParser(std::string html) : m_tokenizer(std::move(html)) {}
    std::unique_ptr<DomNode> Run();

    void HandleStartTag(const Token& t);
    void HandleEndTag(const Token& t);
    void HandleText(const Token& t);
    void HandleComment(const Token& t);
    void HandleDoctype(const Token& t);

    void ImplicitlyCloseFor(const std::string& incomingTag);
    void PopUntilAndIncluding(const std::string& tagName);
    DomNode* Top() const { return m_stack.back(); }

    HtmlTokenizer m_tokenizer;
    std::unique_ptr<DomNode> m_document;
    std::vector<DomNode*> m_stack; // 스택 최상단 = 현재 삽입 지점 (raw ptr, 소유권은 트리가 가짐)
};

} // namespace Xtentix
