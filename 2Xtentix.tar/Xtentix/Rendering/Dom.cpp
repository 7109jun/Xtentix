#include "Dom.h"
#include <algorithm>
#include <cstdio>

namespace Xtentix {

void DomNode::SetAttribute(const std::string& name, const std::string& value) {
    for (auto& attr : m_attributes) {
        if (attr.first == name) { attr.second = value; return; }
    }
    m_attributes.emplace_back(name, value);
}

std::string DomNode::GetAttribute(const std::string& name) const {
    for (auto& attr : m_attributes) {
        if (attr.first == name) return attr.second;
    }
    return "";
}

bool DomNode::HasAttribute(const std::string& name) const {
    return std::any_of(m_attributes.begin(), m_attributes.end(),
                        [&](auto& a) { return a.first == name; });
}

DomNode* DomNode::AppendChild(std::unique_ptr<DomNode> child) {
    child->m_parent = this;
    DomNode* raw = child.get();
    m_children.push_back(std::move(child));
    return raw;
}

void DomNode::DebugPrint(int depth) const {
    std::string indent(depth * 2, ' ');
    switch (m_type) {
        case NodeType::Document:
            printf("%s#document\n", indent.c_str());
            break;
        case NodeType::Element: {
            printf("%s<%s", indent.c_str(), m_tagName.c_str());
            for (auto& attr : m_attributes) {
                printf(" %s=\"%s\"", attr.first.c_str(), attr.second.c_str());
            }
            printf(">\n");
            break;
        }
        case NodeType::Text: {
            size_t start = m_data.find_first_not_of(" \t\r\n");
            if (start == std::string::npos) break; // 공백만 있는 텍스트는 생략
            printf("%s\"%s\"\n", indent.c_str(), m_data.c_str());
            break;
        }
        case NodeType::Comment:
            printf("%s<!-- %s -->\n", indent.c_str(), m_data.c_str());
            break;
        case NodeType::Doctype:
            printf("%s<!DOCTYPE %s>\n", indent.c_str(), m_data.c_str());
            break;
    }
    for (auto& child : m_children) child->DebugPrint(depth + 1);
}

} // namespace Xtentix
