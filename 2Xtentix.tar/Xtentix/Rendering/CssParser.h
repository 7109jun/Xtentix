#pragma once
#include "Css.h"
#include <string>
#include <vector>

namespace Xtentix {

// CSS1 수준의 실용적 부분집합을 파싱한다.
// 지원: 타입/클래스/아이디/전체 선택자, 콤마 그룹, 자손(' ')/자식('>') 콤비네이터,
//       선언 블록(속성:값; ... ), !important.
// 미지원(TODO): @media 등 at-rule 내부(스킵만 함, 평가 안 함), 가상 클래스/요소,
//       속성 선택자([attr]), 형제 콤비네이터('+','~').
class CssParser {
public:
    static std::vector<CssRule> Parse(const std::string& css);

    // style="color:red; font-size: 12px" 같은 인라인 선언 블록 파싱용으로도 재사용.
    static std::vector<CssDeclaration> ParseDeclarationBlock(const std::string& block);

private:
    static std::string StripComments(const std::string& css);
    static std::vector<ComplexSelector> ParseSelectorGroup(const std::string& text);
    static ComplexSelector ParseComplexSelector(const std::string& text);
    static CompoundSelector ParseCompoundSelector(const std::string& token);
    static size_t FindMatchingBrace(const std::string& css, size_t openBracePos);
};

} // namespace Xtentix
