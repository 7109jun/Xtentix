#pragma once
#include <windows.h>
#include <gdiplus.h>
#include "LayoutBox.h"
#include "LayoutEngine.h"

namespace Xtentix {

// 설정의 "화질" 옵션과 1:1 대응. Fast는 안티앨리어싱을 꺼서 매우 빠르지만 계단현상이
// 보이고, High는 지금까지의 기본 동작(안티앨리어싱+ClearType)으로 가장 느리지만 곱다.
enum class RenderQuality { Fast, Medium, High };

// Xtentix의 유일한 렌더링 진입점. LayoutEngine이 만든 박스 트리를 화면에 그린다.
// MainWindow든, 나중에 생길 썸네일/인쇄 미리보기든 전부 이 하나만 호출하면 됨 -
// 더블버퍼링, 뷰포트 컬링(화면 밖 박스는 아예 안 그림), 안티앨리어싱까지 여기서
// 전부 처리하므로 호출부는 "어디에, 얼마나 크게, 스크롤이 어디인지"만 알면 된다.
//   지원: 배경색, 테두리(단색 실선, 둥근 모서리), box-shadow(레이어드 근사 블러),
//         텍스트(굵게/기울임/밑줄, 색상, ClearType 안티앨리어싱), 뷰포트 컬링, 3단계 화질
//   미지원(TODO): 이미지 디코딩, 그라디언트, 모서리별 border-radius, inset 그림자
class GdiPainter {
public:
    // destHdc: 최종적으로 보여질 화면 HDC (예: WM_PAINT의 BeginPaint 결과)
    // viewportWidth/Height: 그릴 영역 크기 (예: 콘텐츠 영역의 클라이언트 사각형)
    // scrollX/scrollY: 문서 좌표계에서 뷰포트 좌상단이 위치한 지점
    static void Paint(HDC destHdc, const LayoutBox* root, int viewportWidth, int viewportHeight,
                       int scrollX = 0, int scrollY = 0, RenderQuality quality = RenderQuality::High);

    // 실제 GDI+ 폰트 메트릭을 쓰는 텍스트 측정 함수. LayoutEngine::TextMeasureFn과
    // 시그니처가 맞아서 그대로 주입해서 쓰면 됨. Paint()와 동일한 StringFormat을 써서
    // 측정값과 실제 그려지는 글자폭이 어긋나지 않게 한다.
    static TextMetrics Measure(HDC hdc, const std::wstring& text, int fontSizePx, bool bold, bool italic);

private:
    // viewTop/viewBottom: 문서 좌표계 기준 현재 보이는 세로 범위. 이 범위와 전혀
    // 겹치지 않는 박스는 자손까지 통째로 건너뛴다 (렉의 주 원인이었던 부분 - 텍스트
    // 많은 페이지에서 스크롤할 때마다 화면 밖 수천 개 단어까지 매번 다시 그리고 있었음).
    static void PaintBox(Gdiplus::Graphics& g, const LayoutBox* box, int scrollX, int scrollY,
                          int viewTop, int viewBottom, int shadowLayerCap);
};

} // namespace Xtentix
