#pragma once
#include <string>
#include <memory>
#include <vector>
#include "Dom.h"
#include "Css.h"
#include "StyleResolver.h"

namespace Xtentix {

// 탭 하나가 로드한 페이지의 결과물. HTML/CSS 문자열을 받아 DOM 트리와 계산된 스타일을 만든다.
//   TODO(Phase 4): Network::HttpClient 응답 body를 여기로 흘려보내기
//   TODO(Phase 4): 계산된 스타일 -> 레이아웃 트리(박스 모델, 배치)로 넘기는 단계
class Document {
public:
    explicit Document(std::string url) : m_url(std::move(url)) {}

    const std::string& Url() const { return m_url; }

    void LoadHtml(const std::string& html);

    // <style> 태그 내용 + 외부 CSS를 합쳐서 전달하면 됨. 여러 번 호출하면 누적(append)됨.
    void AddStylesheet(const std::string& css);

    // HTML/CSS를 모두 로드한 뒤 한 번 호출해서 요소별 최종 스타일을 계산.
    void ComputeStyles();

    DomNode* Root() const { return m_root.get(); }
    const StyleResolver::StyleMap& Styles() const { return m_styles; }

private:
    std::string m_url;
    std::unique_ptr<DomNode> m_root;
    std::vector<CssRule> m_stylesheetRules;
    StyleResolver::StyleMap m_styles;
};

} // namespace Xtentix
