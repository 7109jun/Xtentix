#pragma once
#include <string>

namespace Xtentix {

// 실제 브라우저의 "user agent stylesheet"에 해당. 저자(author) CSS가 하나도 없어도
// 태그가 최소한의 상식적인 형태로 보이도록 하는 기본값. 항상 author 규칙보다 먼저
// 적용되어 author가 자유롭게 덮어쓸 수 있게 한다 (StyleResolver::Resolve 호출 시
// [UA 규칙 + author 규칙] 순서로 넘기면 캐스케이드가 알아서 처리).
//
// TODO(Phase 5+): table 전용 레이아웃, list-style(불릿/숫자), 폼 컨트롤 기본 스타일.
inline const std::string& UserAgentStylesheet() {
    static const std::string kCss = R"CSS(
        div, p, h1, h2, h3, h4, h5, h6, ul, ol, li, section, article,
        header, footer, nav, main, aside, blockquote, pre, address,
        form, fieldset, figure, figcaption, table, tr, hr, html, body {
            display: block;
        }
        span, a, b, strong, i, em, u, small, sub, sup, code, label, img, br {
            display: inline;
        }
        head, title, meta, link, style, script, base {
            display: none;
        }
        body { color: black; font-size: 16px; }
        b, strong { font-weight: bold; }
        i, em { font-style: italic; }
        a { color: blue; text-decoration: underline; }
        h1 { font-size: 32px; font-weight: bold; }
        h2 { font-size: 24px; font-weight: bold; }
        h3 { font-size: 19px; font-weight: bold; }
        h4 { font-size: 16px; font-weight: bold; }
        h5 { font-size: 13px; font-weight: bold; }
        h6 { font-size: 11px; font-weight: bold; }
        small { font-size: 12px; }
        p, ul, ol, h1, h2, h3, h4, h5, h6 { margin: 8px; }
        ul, ol { padding-left: 24px; }
        hr { border: 1px solid gray; }
    )CSS";
    return kCss;
}

} // namespace Xtentix
