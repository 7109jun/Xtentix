#pragma once
#include <string>
#include <vector>
#include <utility>

namespace Xtentix {

enum class TokenType {
    StartTag,
    EndTag,
    Text,
    Comment,
    Doctype,
    EndOfFile
};

struct Token {
    TokenType type = TokenType::EndOfFile;
    std::string tagName;                                   // StartTag/EndTag
    std::vector<std::pair<std::string, std::string>> attributes; // StartTag
    bool selfClosing = false;                               // StartTag (예: <br/>)
    std::string text;                                       // Text/Comment/Doctype
};

// HTML5 스펙의 토크나이저 상태 머신 중 실전에서 마주치는 부분만 구현한 실용적 부분집합.
// (참조: whatwg.org/multipage/parsing.html#tokenization — 전체 상태(70여개) 대신
//  Data/TagOpen/TagName/BeforeAttr/AttrName/AttrValue/Comment/Doctype/RawText만 구현)
class HtmlTokenizer {
public:
    explicit HtmlTokenizer(std::string html) : m_html(std::move(html)) {}

    // EOF에 도달하면 TokenType::EndOfFile을 반환. 이후 계속 호출해도 EndOfFile만 반환.
    Token Next();

private:
    // script/style/textarea/title 내부는 태그로 해석하지 않고 매칭되는 종료 태그를
    // 텍스트로 만날 때까지 통째로 텍스트로 취급한다 (RAWTEXT/RCDATA 상태에 해당).
    void EnterRawTextMode(const std::string& tagName);

    Token ReadTagOrMarkupDeclaration();
    Token ReadStartOrEndTag(bool isEndTag);
    Token ReadComment();
    Token ReadDoctype();
    Token ReadRawText();
    Token ReadTextUntilLessThan();

    void SkipWhitespace();
    std::string ReadTagName();
    bool ConsumeIf(char c);
    bool MatchAhead(const std::string& s, bool caseInsensitive = true);

    std::string m_html;
    size_t m_pos = 0;

    bool m_inRawText = false;
    std::string m_rawTextEndTag; // 소문자 태그명
    bool m_rawTextDecodesEntities = false; // RCDATA(title/textarea)=true, RAWTEXT(script/style)=false
};

} // namespace Xtentix
