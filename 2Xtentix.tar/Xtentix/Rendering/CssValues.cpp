#include "CssValues.h"
#include <cctype>
#include <cstdlib>
#include <algorithm>
#include <unordered_map>
#include <sstream>
#include <vector>

namespace Xtentix {

namespace {

std::string Trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

std::string ToLower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return std::tolower(c); });
    return s;
}

int HexNibble(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

std::optional<RgbColor> ParseHexColor(const std::string& s) {
    // #rgb 또는 #rrggbb 만 지원 (알파 포함 #rgba/#rrggbbaa는 TODO)
    if (s.size() == 4) {
        int r = HexNibble(s[1]), g = HexNibble(s[2]), b = HexNibble(s[3]);
        if (r < 0 || g < 0 || b < 0) return std::nullopt;
        return RgbColor{ (unsigned char)(r * 17), (unsigned char)(g * 17), (unsigned char)(b * 17) };
    }
    if (s.size() == 7) {
        int r1 = HexNibble(s[1]), r2 = HexNibble(s[2]);
        int g1 = HexNibble(s[3]), g2 = HexNibble(s[4]);
        int b1 = HexNibble(s[5]), b2 = HexNibble(s[6]);
        if ((r1 | r2 | g1 | g2 | b1 | b2) < 0) return std::nullopt;
        return RgbColor{ (unsigned char)(r1 * 16 + r2), (unsigned char)(g1 * 16 + g2), (unsigned char)(b1 * 16 + b2) };
    }
    return std::nullopt;
}

std::optional<RgbColor> ParseRgbFunction(const std::string& s) {
    // "rgb(255, 0, 0)" 또는 "rgba(255, 0, 0, 0.5)" 지원.
    size_t open = s.find('(');
    size_t close = s.find(')');
    if (open == std::string::npos || close == std::string::npos || close < open) return std::nullopt;

    std::string inner = s.substr(open + 1, close - open - 1);
    std::istringstream iss(inner);
    std::string token;
    int values[3];
    for (int i = 0; i < 3; ++i) {
        if (!std::getline(iss, token, ',')) return std::nullopt;
        values[i] = std::atoi(Trim(token).c_str());
        values[i] = (std::max)(0, (std::min)(255, values[i]));
    }
    unsigned char alpha = 255;
    if (std::getline(iss, token, ',')) {
        double a = std::atof(Trim(token).c_str());
        alpha = (unsigned char)((std::max)(0.0, (std::min)(1.0, a)) * 255.0);
    }
    return RgbColor{ (unsigned char)values[0], (unsigned char)values[1], (unsigned char)values[2], alpha };
}

const std::unordered_map<std::string, RgbColor>& NamedColors() {
    static const std::unordered_map<std::string, RgbColor> kColors = {
        { "black",   {0, 0, 0} },       { "white",   {255, 255, 255} },
        { "red",     {255, 0, 0} },     { "green",   {0, 128, 0} },
        { "blue",    {0, 0, 255} },     { "yellow",  {255, 255, 0} },
        { "gray",    {128, 128, 128} }, { "grey",    {128, 128, 128} },
        { "silver",  {192, 192, 192} }, { "orange",  {255, 165, 0} },
        { "purple",  {128, 0, 128} },   { "navy",    {0, 0, 128} },
        { "teal",    {0, 128, 128} },   { "lime",    {0, 255, 0} },
        { "maroon",  {128, 0, 0} },     { "olive",   {128, 128, 0} },
        { "pink",    {255, 192, 203} }, { "brown",   {165, 42, 42} },
        { "transparent", {255, 255, 255} }, // TODO: 진짜 투명(알파) 지원
    };
    return kColors;
}

std::vector<std::string> TokenizeRespectingParens(const std::string& s) {
    // box-shadow 값처럼 "2px 2px 6px rgba(0, 0, 0, 0.3)"을 공백으로 나눌 때,
    // rgba(...) 안의 쉼표 뒤 공백까지 나뉘어버리면 안 되므로 괄호 깊이를 추적한다.
    std::vector<std::string> tokens;
    std::string cur;
    int depth = 0;
    for (char c : s) {
        if (c == '(') depth++;
        if (c == ')') depth--;
        if (std::isspace((unsigned char)c) && depth == 0) {
            if (!cur.empty()) { tokens.push_back(cur); cur.clear(); }
        } else {
            cur += c;
        }
    }
    if (!cur.empty()) tokens.push_back(cur);
    return tokens;
}

} // namespace

std::optional<int> CssValues::ParseLengthPx(const std::string& valueIn) {
    std::string value = Trim(valueIn);
    if (value.empty()) return std::nullopt;
    if (value == "auto") return std::nullopt; // 호출부에서 "auto"는 별도 처리
    if (!value.empty() && value.back() == '%') return std::nullopt; // %는 ParsePercentage로

    std::string lower = ToLower(value);
    size_t pxPos = lower.find("px");
    std::string numPart = (pxPos != std::string::npos) ? value.substr(0, pxPos) : value;

    char* endPtr = nullptr;
    double num = std::strtod(numPart.c_str(), &endPtr);
    if (endPtr == numPart.c_str()) return std::nullopt; // 숫자로 시작하지 않음 (em 등 미지원 단위)
    return (int)num;
}

std::optional<double> CssValues::ParsePercentage(const std::string& valueIn) {
    std::string value = Trim(valueIn);
    if (value.empty() || value.back() != '%') return std::nullopt;

    std::string numPart = value.substr(0, value.size() - 1);
    char* endPtr = nullptr;
    double num = std::strtod(numPart.c_str(), &endPtr);
    if (endPtr == numPart.c_str()) return std::nullopt;
    return num;
}

std::optional<RgbColor> CssValues::ParseColor(const std::string& valueIn) {
    std::string value = Trim(valueIn);
    if (value.empty()) return std::nullopt;

    if (value[0] == '#') return ParseHexColor(value);

    std::string lower = ToLower(value);
    if (lower.compare(0, 3, "rgb") == 0) return ParseRgbFunction(lower);

    auto& colors = NamedColors();
    auto it = colors.find(lower);
    if (it != colors.end()) return it->second;

    return std::nullopt;
}

std::optional<BoxShadowValue> CssValues::ParseBoxShadow(const std::string& valueIn) {
    std::string value = Trim(valueIn);
    if (value.empty() || ToLower(value) == "none") return std::nullopt;

    auto tokens = TokenizeRespectingParens(value);
    std::vector<int> lengths;
    std::string colorToken;
    for (auto& t : tokens) {
        if (ToLower(t) == "inset") continue; // TODO: inset(안쪽 그림자) 미지원, 무시하고 진행
        auto len = ParseLengthPx(t);
        if (len) lengths.push_back(*len);
        else colorToken = t; // 길이로 안 읽히는 토큰은 색상으로 취급
    }
    if (lengths.size() < 2) return std::nullopt; // 최소 offsetX, offsetY는 있어야 함

    BoxShadowValue shadow;
    shadow.offsetX = lengths[0];
    shadow.offsetY = lengths[1];
    shadow.blurRadius = lengths.size() >= 3 ? (std::max)(0, lengths[2]) : 0;
    shadow.color = ParseColor(colorToken).value_or(RgbColor{ 0, 0, 0, 255 });
    return shadow;
}

} // namespace Xtentix
