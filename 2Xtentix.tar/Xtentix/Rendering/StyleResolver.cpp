#include "StyleResolver.h"
#include "CssParser.h"
#include <algorithm>
#include <sstream>

namespace Xtentix {

namespace {
// 자식에게 그대로 흘러 내려가야 하는(=상속되는) 속성들.
// (실제 CSS 상속 속성은 더 많지만, 지금 레이아웃 엔진이 쓰는 것만 우선 지원)
const std::vector<std::string>& InheritableProperties() {
    static const std::vector<std::string> kProps = {
        "color", "font-size", "font-weight", "font-style", "text-align", "font-family", "line-height"
    };
    return kProps;
}
} // namespace

std::vector<std::string> StyleResolver::SplitClasses(const std::string& classAttr) {
    std::vector<std::string> out;
    std::istringstream iss(classAttr);
    std::string token;
    while (iss >> token) out.push_back(token);
    return out;
}

bool StyleResolver::MatchesCompound(const DomNode* el, const CompoundSelector& c) {
    if (!el || el->Type() != NodeType::Element) return false;
    if (!c.tagName.empty() && el->TagName() != c.tagName) return false;
    if (!c.id.empty() && el->GetAttribute("id") != c.id) return false;

    if (!c.classes.empty()) {
        std::vector<std::string> elClasses = SplitClasses(el->GetAttribute("class"));
        for (auto& required : c.classes) {
            if (std::find(elClasses.begin(), elClasses.end(), required) == elClasses.end()) return false;
        }
    }
    return true;
}

bool StyleResolver::Matches(const DomNode* el, const ComplexSelector& sel) {
    if (sel.compounds.empty()) return false;
    size_t n = sel.compounds.size();

    const DomNode* current = el;
    if (!MatchesCompound(current, sel.compounds[n - 1])) return false;

    // 오른쪽(매칭 대상)에서 왼쪽(조상)으로 거슬러 올라가며 콤비네이터를 검사.
    for (size_t i = n - 1; i-- > 0;) {
        Combinator comb = sel.combinators[i]; // compounds[i] <-comb- compounds[i+1]
        if (comb == Combinator::Child) {
            current = current->Parent();
            if (!current || !MatchesCompound(current, sel.compounds[i])) return false;
        } else {
            const DomNode* ancestor = current->Parent();
            bool found = false;
            while (ancestor) {
                if (MatchesCompound(ancestor, sel.compounds[i])) { found = true; break; }
                ancestor = ancestor->Parent();
            }
            if (!found) return false;
            current = ancestor;
        }
    }
    return true;
}

Specificity StyleResolver::ComputeSpecificity(const ComplexSelector& sel, bool inlineOrigin) {
    Specificity s{ inlineOrigin ? 1 : 0, 0, 0, 0 };
    for (auto& compound : sel.compounds) {
        if (!compound.id.empty()) s[1]++;
        s[2] += (int)compound.classes.size();
        if (!compound.tagName.empty()) s[3]++;
    }
    return s;
}

// 상속 없이 이 요소에 "직접" 적용되는 캐스케이드 결과만 계산 (선택자 매칭 + 특이도 + !important).
StyleResolver::ComputedStyle StyleResolver::ComputeSpecifiedStyle(const DomNode* el, const std::vector<CssRule>& rules) {
    struct Matched { Specificity spec; size_t order; const CssDeclaration* decl; };
    std::vector<Matched> normal, important;

    size_t order = 0;
    for (auto& rule : rules) {
        bool any = false;
        Specificity best{ -1, -1, -1, -1 };
        for (auto& sel : rule.selectorGroup) {
            if (Matches(el, sel)) {
                any = true;
                Specificity s = ComputeSpecificity(sel);
                if (best < s) best = s;
            }
        }
        if (any) {
            for (auto& decl : rule.declarations) {
                (decl.important ? important : normal).push_back({ best, order, &decl });
            }
        }
        order++;
    }

    // 인라인 style="" 속성: 항상 최고 특이도(inline=1)를 부여해 선택자 기반 규칙을 이긴다.
    std::vector<CssDeclaration> inlineDecls;
    std::string styleAttr = el->GetAttribute("style");
    if (!styleAttr.empty()) {
        inlineDecls = CssParser::ParseDeclarationBlock(styleAttr);
        Specificity inlineSpec{ 1, 0, 0, 0 };
        for (auto& decl : inlineDecls) {
            (decl.important ? important : normal).push_back({ inlineSpec, order, &decl });
        }
    }

    auto cmp = [](const Matched& a, const Matched& b) { return a.spec < b.spec; };
    std::stable_sort(normal.begin(), normal.end(), cmp);
    std::stable_sort(important.begin(), important.end(), cmp);

    ComputedStyle style;
    for (auto& m : normal) style[m.decl->property] = m.decl->value;
    for (auto& m : important) style[m.decl->property] = m.decl->value;
    return style;
}

void StyleResolver::Walk(const DomNode* node, const std::vector<CssRule>& rules,
                          const ComputedStyle& inheritedFromParent, StyleMap& out) {
    if (node->Type() != NodeType::Element) {
        // 요소가 아닌 노드(#document 등)는 스타일을 갖지 않지만, 자식에게는
        // 지금까지 내려온 상속값을 그대로 전달해야 한다.
        for (auto& child : node->Children()) Walk(child.get(), rules, inheritedFromParent, out);
        return;
    }

    ComputedStyle specified = ComputeSpecifiedStyle(node, rules);

    // effective = 부모에게서 상속된 값 위에, 이 요소에 직접 지정된 값을 덮어씀.
    ComputedStyle effective = inheritedFromParent;
    for (auto& kv : specified) effective[kv.first] = kv.second;
    out[node] = effective;

    // 자식에게는 상속 가능한 속성만 추려서 넘긴다.
    ComputedStyle toChildren;
    for (auto& prop : InheritableProperties()) {
        auto it = effective.find(prop);
        if (it != effective.end()) toChildren[prop] = it->second;
    }

    for (auto& child : node->Children()) Walk(child.get(), rules, toChildren, out);
}

StyleResolver::StyleMap StyleResolver::Resolve(const DomNode* root, const std::vector<CssRule>& rules) {
    StyleMap out;
    Walk(root, rules, ComputedStyle{}, out);
    return out;
}

} // namespace Xtentix
