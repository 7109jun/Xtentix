#include "HtmlTokenizer.h"
#include <cctype>
#include <algorithm>

namespace Xtentix {

namespace {

char ToLowerChar(char c) { return (char)std::tolower((unsigned char)c); }

bool IsTagNameChar(char c) {
    return std::isalnum((unsigned char)c) || c == '-' || c == ':';
}

// &amp; &lt; &gt; &quot; &#39; &nbsp; 등 실전에서 자주 나오는 엔티티만 처리.
// (전체 HTML5 엔티티 표(2000여개)는 규모 대비 이득이 적어 제외 — 필요해지면 테이블 추가)
std::string DecodeEntities(const std::string& in) {
    std::string out;
    out.reserve(in.size());
    for (size_t i = 0; i < in.size(); ++i) {
        if (in[i] != '&') { out += in[i]; continue; }

        size_t semi = in.find(';', i);
        if (semi == std::string::npos || semi - i > 10) { out += in[i]; continue; }

        std::string entity = in.substr(i + 1, semi - i - 1);
        std::string replacement;
        bool matched = true;

        if (!entity.empty() && entity[0] == '#') {
            // 숫자 참조: &#39; 또는 &#x27;
            long code = 0;
            if (entity.size() > 1 && (entity[1] == 'x' || entity[1] == 'X')) {
                code = strtol(entity.c_str() + 2, nullptr, 16);
            } else {
                code = strtol(entity.c_str() + 1, nullptr, 10);
            }
            if (code > 0 && code < 0x110000) {
                // UTF-8로 인코딩
                if (code < 0x80) replacement += (char)code;
                else if (code < 0x800) {
                    replacement += (char)(0xC0 | (code >> 6));
                    replacement += (char)(0x80 | (code & 0x3F));
                } else if (code < 0x10000) {
                    replacement += (char)(0xE0 | (code >> 12));
                    replacement += (char)(0x80 | ((code >> 6) & 0x3F));
                    replacement += (char)(0x80 | (code & 0x3F));
                } else {
                    replacement += (char)(0xF0 | (code >> 18));
                    replacement += (char)(0x80 | ((code >> 12) & 0x3F));
                    replacement += (char)(0x80 | ((code >> 6) & 0x3F));
                    replacement += (char)(0x80 | (code & 0x3F));
                }
            } else matched = false;
        } else if (entity == "amp") replacement = "&";
        else if (entity == "lt") replacement = "<";
        else if (entity == "gt") replacement = ">";
        else if (entity == "quot") replacement = "\"";
        else if (entity == "apos") replacement = "'";
        else if (entity == "nbsp") replacement = "\xC2\xA0"; // UTF-8 U+00A0
        else if (entity == "copy") replacement = "\xC2\xA9";
        else if (entity == "mdash") replacement = "\xE2\x80\x94";
        else matched = false;

        if (matched) { out += replacement; i = semi; }
        else out += in[i];
    }
    return out;
}

} // namespace

void HtmlTokenizer::SkipWhitespace() {
    while (m_pos < m_html.size() && std::isspace((unsigned char)m_html[m_pos])) m_pos++;
}

bool HtmlTokenizer::ConsumeIf(char c) {
    if (m_pos < m_html.size() && m_html[m_pos] == c) { m_pos++; return true; }
    return false;
}

bool HtmlTokenizer::MatchAhead(const std::string& s, bool caseInsensitive) {
    if (m_pos + s.size() > m_html.size()) return false;
    for (size_t i = 0; i < s.size(); ++i) {
        char a = m_html[m_pos + i];
        char b = s[i];
        if (caseInsensitive) { a = ToLowerChar(a); b = ToLowerChar(b); }
        if (a != b) return false;
    }
    return true;
}

std::string HtmlTokenizer::ReadTagName() {
    std::string name;
    while (m_pos < m_html.size() && IsTagNameChar(m_html[m_pos])) {
        name += ToLowerChar(m_html[m_pos]);
        m_pos++;
    }
    return name;
}

void HtmlTokenizer::EnterRawTextMode(const std::string& tagName) {
    // RAWTEXT: 내용을 완전히 불투명하게 취급 (엔티티도 해석 안 함) - script, style
    // RCDATA:  텍스트로 취급하되 엔티티는 해석 - textarea, title
    static const std::vector<std::string> kRawText = { "script", "style" };
    static const std::vector<std::string> kRcData = { "textarea", "title" };

    if (std::find(kRawText.begin(), kRawText.end(), tagName) != kRawText.end()) {
        m_inRawText = true;
        m_rawTextEndTag = tagName;
        m_rawTextDecodesEntities = false;
    } else if (std::find(kRcData.begin(), kRcData.end(), tagName) != kRcData.end()) {
        m_inRawText = true;
        m_rawTextEndTag = tagName;
        m_rawTextDecodesEntities = true;
    }
}

Token HtmlTokenizer::ReadTextUntilLessThan() {
    size_t start = m_pos;
    // 태그로 해석되지 않는 '<' (예: "3 < 5")는 리터럴 문자로 소비하고 계속 진행.
    if (m_pos < m_html.size() && m_html[m_pos] == '<') m_pos++;
    while (m_pos < m_html.size() && m_html[m_pos] != '<') m_pos++;
    Token t;
    t.type = TokenType::Text;
    t.text = DecodeEntities(m_html.substr(start, m_pos - start));
    return t;
}

Token HtmlTokenizer::ReadRawText() {
    // "</태그명" 뒤에 공백/'>'/'/' 가 오는 지점을 대소문자 무시하고 찾는다.
    std::string closeTag = "</" + m_rawTextEndTag;
    size_t searchPos = m_pos;
    size_t foundAt = std::string::npos;

    while (searchPos + closeTag.size() <= m_html.size()) {
        bool match = true;
        for (size_t i = 0; i < closeTag.size() && match; ++i) {
            if (ToLowerChar(m_html[searchPos + i]) != closeTag[i]) match = false;
        }
        if (match) {
            size_t after = searchPos + closeTag.size();
            char next = after < m_html.size() ? m_html[after] : '>';
            if (std::isspace((unsigned char)next) || next == '>' || next == '/') {
                foundAt = searchPos;
                break;
            }
        }
        searchPos++;
    }

    if (foundAt == std::string::npos) {
        Token t;
        t.type = TokenType::Text;
        t.text = m_html.substr(m_pos);
        m_pos = m_html.size();
        m_inRawText = false;
        return t;
    }

    if (foundAt == m_pos) {
        // 텍스트 없이 바로 종료 태그 — 빈 텍스트 토큰 없이 바로 종료 태그를 읽는다.
        m_inRawText = false;
        return ReadStartOrEndTag(true);
    }

    Token t;
    t.type = TokenType::Text;
    std::string raw = m_html.substr(m_pos, foundAt - m_pos);
    t.text = m_rawTextDecodesEntities ? DecodeEntities(raw) : raw;
    m_pos = foundAt;
    m_inRawText = false;
    return t;
}

Token HtmlTokenizer::ReadComment() {
    m_pos += 4; // "<!--" 소비
    size_t end = m_html.find("-->", m_pos);
    Token t;
    t.type = TokenType::Comment;
    if (end == std::string::npos) {
        t.text = m_html.substr(m_pos);
        m_pos = m_html.size();
    } else {
        t.text = m_html.substr(m_pos, end - m_pos);
        m_pos = end + 3;
    }
    return t;
}

Token HtmlTokenizer::ReadDoctype() {
    // "<!DOCTYPE" (대소문자 무관) 소비
    m_pos += 9;
    SkipWhitespace();
    size_t start = m_pos;
    while (m_pos < m_html.size() && m_html[m_pos] != '>') m_pos++;
    Token t;
    t.type = TokenType::Doctype;
    t.text = m_html.substr(start, m_pos - start);
    ConsumeIf('>');
    return t;
}

Token HtmlTokenizer::ReadStartOrEndTag(bool isEndTag) {
    m_pos++; // '<' 소비
    if (isEndTag) m_pos++; // '/' 소비

    Token t;
    t.type = isEndTag ? TokenType::EndTag : TokenType::StartTag;
    t.tagName = ReadTagName();

    if (isEndTag) {
        while (m_pos < m_html.size() && m_html[m_pos] != '>') m_pos++;
        ConsumeIf('>');
        return t;
    }

    for (;;) {
        SkipWhitespace();
        if (m_pos >= m_html.size()) break;

        if (m_html[m_pos] == '>') { m_pos++; break; }

        if (m_html[m_pos] == '/' && m_pos + 1 < m_html.size() && m_html[m_pos + 1] == '>') {
            t.selfClosing = true;
            m_pos += 2;
            break;
        }
        if (m_html[m_pos] == '/') { m_pos++; continue; }

        std::string attrName;
        while (m_pos < m_html.size() && !std::isspace((unsigned char)m_html[m_pos]) &&
               m_html[m_pos] != '=' && m_html[m_pos] != '>' && m_html[m_pos] != '/') {
            attrName += ToLowerChar(m_html[m_pos]);
            m_pos++;
        }
        if (attrName.empty()) { m_pos++; continue; } // 이상 문자 방어

        SkipWhitespace();
        std::string attrValue;
        if (m_pos < m_html.size() && m_html[m_pos] == '=') {
            m_pos++;
            SkipWhitespace();
            if (m_pos < m_html.size() && (m_html[m_pos] == '"' || m_html[m_pos] == '\'')) {
                char quote = m_html[m_pos++];
                size_t start = m_pos;
                while (m_pos < m_html.size() && m_html[m_pos] != quote) m_pos++;
                attrValue = DecodeEntities(m_html.substr(start, m_pos - start));
                ConsumeIf(quote);
            } else {
                size_t start = m_pos;
                while (m_pos < m_html.size() && !std::isspace((unsigned char)m_html[m_pos]) && m_html[m_pos] != '>') m_pos++;
                attrValue = DecodeEntities(m_html.substr(start, m_pos - start));
            }
        }

        bool exists = std::any_of(t.attributes.begin(), t.attributes.end(),
                                   [&](auto& a) { return a.first == attrName; });
        if (!exists) t.attributes.emplace_back(attrName, attrValue); // 스펙: 첫 값이 우선
    }

    if (!t.selfClosing) EnterRawTextMode(t.tagName);
    return t;
}

Token HtmlTokenizer::ReadTagOrMarkupDeclaration() {
    if (MatchAhead("<!--")) return ReadComment();
    if (MatchAhead("<!doctype")) return ReadDoctype();

    // 그 외 "<!...>" (bogus comment) 또는 "<?...>" (처리 명령) 는 '>' 까지 통째로 무시.
    size_t end = m_html.find('>', m_pos);
    Token t;
    t.type = TokenType::Comment;
    if (end == std::string::npos) { m_pos = m_html.size(); }
    else { t.text = m_html.substr(m_pos, end - m_pos + 1); m_pos = end + 1; }
    return t;
}

Token HtmlTokenizer::Next() {
    if (m_pos >= m_html.size()) { Token t; t.type = TokenType::EndOfFile; return t; }

    if (m_inRawText) return ReadRawText();

    if (m_html[m_pos] == '<' && m_pos + 1 < m_html.size()) {
        char next = m_html[m_pos + 1];
        if (next == '/') return ReadStartOrEndTag(true);
        if (next == '!' || next == '?') return ReadTagOrMarkupDeclaration();
        if (std::isalpha((unsigned char)next)) return ReadStartOrEndTag(false);
    }

    return ReadTextUntilLessThan();
}

} // namespace Xtentix
