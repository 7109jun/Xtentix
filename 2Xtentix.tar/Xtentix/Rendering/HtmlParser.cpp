#include "HtmlParser.h"
#include <unordered_set>

namespace Xtentix {

namespace {

bool IsVoidElement(const std::string& tag) {
    static const std::unordered_set<std::string> kVoid = {
        "area", "base", "br", "col", "embed", "hr", "img", "input",
        "link", "meta", "param", "source", "track", "wbr"
    };
    return kVoid.count(tag) > 0;
}

// incomingTag를 열려고 할 때, 현재 열려있는 openTag를 암묵적으로 닫아야 하는지.
// (HTML5 스펙의 "implied end tag" 규칙 중 실전에서 자주 쓰이는 것만 발췌)
bool ShouldImplicitlyClose(const std::string& openTag, const std::string& incomingTag) {
    static const std::unordered_set<std::string> kClosesP = {
        "address", "article", "aside", "blockquote", "details", "div", "dl",
        "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3",
        "h4", "h5", "h6", "header", "hr", "main", "menu", "nav", "ol", "p",
        "pre", "section", "table", "ul"
    };
    if (openTag == "p") return kClosesP.count(incomingTag) > 0;
    if (openTag == "li") return incomingTag == "li";
    if (openTag == "dd" || openTag == "dt") return incomingTag == "dd" || incomingTag == "dt";
    if (openTag == "option") return incomingTag == "option" || incomingTag == "optgroup";
    if (openTag == "tr") return incomingTag == "tr";
    if (openTag == "td" || openTag == "th") return incomingTag == "td" || incomingTag == "th" || incomingTag == "tr";
    return false;
}

} // namespace

std::unique_ptr<DomNode> HtmlParser::Parse(const std::string& html) {
    HtmlParser parser(html);
    return parser.Run();
}

std::unique_ptr<DomNode> HtmlParser::Run() {
    m_document = std::make_unique<DomNode>(NodeType::Document);
    m_stack.push_back(m_document.get());

    for (;;) {
        Token t = m_tokenizer.Next();
        if (t.type == TokenType::EndOfFile) break;

        switch (t.type) {
            case TokenType::StartTag: HandleStartTag(t); break;
            case TokenType::EndTag: HandleEndTag(t); break;
            case TokenType::Text: HandleText(t); break;
            case TokenType::Comment: HandleComment(t); break;
            case TokenType::Doctype: HandleDoctype(t); break;
            case TokenType::EndOfFile: break;
        }
    }

    return std::move(m_document);
}

void HtmlParser::ImplicitlyCloseFor(const std::string& incomingTag) {
    // 문서 루트(스택 바닥)는 항상 남겨둔다.
    while (m_stack.size() > 1 && ShouldImplicitlyClose(Top()->TagName(), incomingTag)) {
        m_stack.pop_back();
    }
}

void HtmlParser::PopUntilAndIncluding(const std::string& tagName) {
    for (size_t i = m_stack.size(); i-- > 1;) {
        if (m_stack[i]->Type() == NodeType::Element && m_stack[i]->TagName() == tagName) {
            m_stack.resize(i);
            return;
        }
    }
    // 매칭되는 시작 태그가 없는 낙오된 종료 태그 -> 무시
}

void HtmlParser::HandleStartTag(const Token& t) {
    ImplicitlyCloseFor(t.tagName);

    auto node = std::make_unique<DomNode>(NodeType::Element);
    node->SetTagName(t.tagName);
    for (auto& attr : t.attributes) node->SetAttribute(attr.first, attr.second);

    DomNode* raw = Top()->AppendChild(std::move(node));

    // void 요소와 self-closing 표기(XHTML 스타일 <div/> 포함)는 스택에 올리지 않는다.
    if (!IsVoidElement(t.tagName) && !t.selfClosing) {
        m_stack.push_back(raw);
    }
}

void HtmlParser::HandleEndTag(const Token& t) {
    PopUntilAndIncluding(t.tagName);
}

void HtmlParser::HandleText(const Token& t) {
    if (t.text.empty()) return;
    auto node = std::make_unique<DomNode>(NodeType::Text);
    node->SetData(t.text);
    Top()->AppendChild(std::move(node));
}

void HtmlParser::HandleComment(const Token& t) {
    auto node = std::make_unique<DomNode>(NodeType::Comment);
    node->SetData(t.text);
    Top()->AppendChild(std::move(node));
}

void HtmlParser::HandleDoctype(const Token& t) {
    auto node = std::make_unique<DomNode>(NodeType::Doctype);
    node->SetData(t.text);
    Top()->AppendChild(std::move(node));
}

} // namespace Xtentix
