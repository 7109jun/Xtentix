#include "Document.h"
#include "HtmlParser.h"
#include "CssParser.h"
#include "UserAgentStylesheet.h"

namespace Xtentix {

void Document::LoadHtml(const std::string& html) {
    m_root = HtmlParser::Parse(html);
    m_styles.clear();
}

void Document::AddStylesheet(const std::string& css) {
    auto rules = CssParser::Parse(css);
    m_stylesheetRules.insert(m_stylesheetRules.end(), rules.begin(), rules.end());
}

void Document::ComputeStyles() {
    if (!m_root) return;
    // UA 기본 스타일시트를 항상 가장 먼저(=가장 낮은 우선순위로) 적용하고,
    // 그 위에 author 규칙(<style>, style="")을 쌓는다.
    static const std::vector<CssRule> kUaRules = CssParser::Parse(UserAgentStylesheet());

    std::vector<CssRule> combined;
    combined.reserve(kUaRules.size() + m_stylesheetRules.size());
    combined.insert(combined.end(), kUaRules.begin(), kUaRules.end());
    combined.insert(combined.end(), m_stylesheetRules.begin(), m_stylesheetRules.end());

    m_styles = StyleResolver::Resolve(m_root.get(), combined);
}

} // namespace Xtentix
