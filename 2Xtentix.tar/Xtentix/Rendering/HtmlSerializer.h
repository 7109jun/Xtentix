#pragma once
#include "Dom.h"
#include <string>

namespace Xtentix {

// DevTools의 "Elements" 패널에 보여줄 정갈한 HTML 텍스트를 만든다.
// 파싱 결과를 그대로 되찍는 게 아니라 사람이 읽기 좋게 들여쓰기/줄바꿈을 새로 넣는다.
//   규칙: void 요소는 한 줄, 텍스트 자식 하나뿐인 요소는 한 줄로 압축,
//         script/style 내용은 원본 그대로(재포맷 안 함).
class HtmlSerializer {
public:
    static std::string PrettyPrint(const DomNode* root, int indentSize = 2);
};

} // namespace Xtentix
