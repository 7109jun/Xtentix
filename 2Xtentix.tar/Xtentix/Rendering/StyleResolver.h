#pragma once
#include "Css.h"
#include "Dom.h"
#include <unordered_map>
#include <string>
#include <vector>

namespace Xtentix {

// DOM 트리 + CSS 규칙 목록을 받아 요소별 최종(계산된) 스타일 맵을 만든다.
// DomNode는 스타일 개념을 전혀 모르게 유지하기 위해, 결과는 DomNode 포인터를 키로 하는
// 별도의 맵으로 반환한다 (DOM과 스타일 계산의 관심사 분리).
class StyleResolver {
public:
    using ComputedStyle = std::unordered_map<std::string, std::string>;
    using StyleMap = std::unordered_map<const DomNode*, ComputedStyle>;

    static StyleMap Resolve(const DomNode* root, const std::vector<CssRule>& rules);

    // 테스트/디버깅 및 선택자 매칭 재사용을 위해 공개.
    static bool Matches(const DomNode* el, const ComplexSelector& sel);

private:
    static void Walk(const DomNode* node, const std::vector<CssRule>& rules,
                      const ComputedStyle& inheritedFromParent, StyleMap& out);
    static ComputedStyle ComputeSpecifiedStyle(const DomNode* el, const std::vector<CssRule>& rules);
    static bool MatchesCompound(const DomNode* el, const CompoundSelector& c);
    static Specificity ComputeSpecificity(const ComplexSelector& sel, bool inlineOrigin = false);
    static std::vector<std::string> SplitClasses(const std::string& classAttr);
};

} // namespace Xtentix
