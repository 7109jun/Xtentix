#include "HtmlSerializer.h"
#include <unordered_set>

namespace Xtentix {

namespace {

bool IsVoidElement(const std::string& tag) {
    static const std::unordered_set<std::string> kVoid = {
        "area", "base", "br", "col", "embed", "hr", "img", "input",
        "link", "meta", "param", "source", "track", "wbr"
    };
    return kVoid.count(tag) > 0;
}

std::string Trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

std::string EscapeText(const std::string& s) {
    std::string out;
    out.reserve(s.size());
    for (char c : s) {
        if (c == '&') out += "&amp;";
        else if (c == '<') out += "&lt;";
        else if (c == '>') out += "&gt;";
        else out += c;
    }
    return out;
}

void WriteOpenTag(const DomNode* el, std::string& out) {
    out += "<" + el->TagName();
    for (auto& attr : el->Attributes()) {
        out += " " + attr.first + "=\"" + attr.second + "\""; // 속성값 내 " 이스케이프는 생략(단순화)
    }
    out += ">";
}

void Serialize(const DomNode* node, std::string& out, int depth, int indentSize) {
    std::string pad(depth * indentSize, ' ');

    switch (node->Type()) {
        case NodeType::Document:
            for (auto& c : node->Children()) Serialize(c.get(), out, depth, indentSize);
            return;
        case NodeType::Doctype:
            out += pad + "<!DOCTYPE " + node->Data() + ">\n";
            return;
        case NodeType::Comment:
            out += pad + "<!-- " + node->Data() + " -->\n";
            return;
        case NodeType::Text: {
            std::string t = Trim(node->Data());
            if (!t.empty()) out += pad + EscapeText(t) + "\n";
            return;
        }
        case NodeType::Element:
            break; // 아래에서 처리
    }

    if (IsVoidElement(node->TagName())) {
        out += pad;
        WriteOpenTag(node, out);
        out += "\n";
        return;
    }

    if (node->TagName() == "script" || node->TagName() == "style") {
        out += pad;
        WriteOpenTag(node, out);
        out += "\n";
        for (auto& c : node->Children()) {
            if (c->Type() == NodeType::Text) out += c->Data(); // 원본 그대로, 재포맷 안 함
        }
        out += "\n" + pad + "</" + node->TagName() + ">\n";
        return;
    }

    // 자식이 텍스트 노드 하나뿐이면 "<p>내용</p>" 처럼 한 줄로 압축.
    if (node->Children().size() == 1 && node->Children()[0]->Type() == NodeType::Text) {
        std::string t = Trim(node->Children()[0]->Data());
        out += pad;
        WriteOpenTag(node, out);
        out += EscapeText(t) + "</" + node->TagName() + ">\n";
        return;
    }

    out += pad;
    WriteOpenTag(node, out);
    out += "\n";
    for (auto& c : node->Children()) Serialize(c.get(), out, depth + 1, indentSize);
    out += pad + "</" + node->TagName() + ">\n";
}

} // namespace

std::string HtmlSerializer::PrettyPrint(const DomNode* root, int indentSize) {
    std::string out;
    Serialize(root, out, 0, indentSize);
    return out;
}

} // namespace Xtentix
