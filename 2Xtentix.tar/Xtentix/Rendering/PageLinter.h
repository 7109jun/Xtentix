#pragma once
#include "Dom.h"
#include <string>
#include <vector>

namespace Xtentix {

// DevTools의 "Issues" 패널이 쓰는 실용적 수준의 정적 검사.
//   검사 항목: <title> 누락/빈값, alt 없는 <img>, 중복 id, href 없는/빈 <a>,
//              사용 중단된 태그(font/center/marquee/blink), 인라인 이벤트 핸들러 속성
//   미지원(TODO): 접근성 대비 검사, 시맨틱 구조 검사, 실제 링크 유효성 검사(네트워크 필요)
class PageLinter {
public:
    static std::vector<std::string> FindIssues(const DomNode* root);
};

} // namespace Xtentix
