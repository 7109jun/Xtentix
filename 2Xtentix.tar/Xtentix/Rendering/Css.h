#pragma once
#include <string>
#include <vector>
#include <array>

namespace Xtentix {

struct CssDeclaration {
    std::string property;
    std::string value;
    bool important = false;
};

// 하나의 콤파운드 선택자: "div.foo#bar" 처럼 콤비네이터 없이 붙어있는 조건들.
// tagName이 비어있거나 "*"면 태그 조건 없음(전체 선택).
struct CompoundSelector {
    std::string tagName;
    std::string id;
    std::vector<std::string> classes;
};

enum class Combinator { Descendant, Child }; // 공백, '>'

// "ul.nav > li.active .icon" 같은 콤비네이터 포함 전체 선택자.
// compounds[0]이 가장 왼쪽(조상), compounds.back()이 실제 매칭 대상 요소.
// combinators[i]는 compounds[i]와 compounds[i+1] 사이의 관계.
struct ComplexSelector {
    std::vector<CompoundSelector> compounds;
    std::vector<Combinator> combinators;
};

struct CssRule {
    std::vector<ComplexSelector> selectorGroup; // 쉼표로 구분된 선택자들, 선언은 공유
    std::vector<CssDeclaration> declarations;
};

// (inline, id개수, class/속성개수, 태그개수) - 사전식 비교로 CSS 특이도 규칙을 표현.
// inline은 style="" 속성 유래 선언에만 1, 그 외는 항상 0.
using Specificity = std::array<int, 4>;

} // namespace Xtentix
