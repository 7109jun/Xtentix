#include "GdiPainter.h"
#include <unordered_map>
#include <memory>
#include <cstdint>
#include <cmath>

namespace Xtentix {

namespace {

// 폰트 패밀리는 스레드마다 하나만 만들어 재사용 (Measure()는 워커 스레드에서,
// PaintBox()는 UI 스레드에서 호출되므로 thread_local로 나눠서 락 없이 안전하게).
struct FontFamilyHolder {
    Gdiplus::FontFamily family;
    FontFamilyHolder() : family(L"Segoe UI") {}
};
thread_local FontFamilyHolder g_fontFamilyHolder;

// 텍스트런 하나마다 폰트를 새로 만들고 버리면 스크롤/리페인트마다 수백 번씩
// Gdiplus::Font를 생성하게 된다 - 스레드별 캐시로 재사용.
struct FontCache {
    std::unordered_map<uint32_t, std::unique_ptr<Gdiplus::Font>> cache;
};
thread_local FontCache g_fontCache;

uint32_t FontKey(int fontSizePx, bool bold, bool italic, bool underline) {
    return ((uint32_t)(fontSizePx & 0xFFFF) << 3) | (bold ? 4u : 0u) | (italic ? 2u : 0u) | (underline ? 1u : 0u);
}

Gdiplus::Font* GetFont(int fontSizePx, bool bold, bool italic, bool underline = false) {
    uint32_t key = FontKey(fontSizePx, bold, italic, underline);
    auto it = g_fontCache.cache.find(key);
    if (it != g_fontCache.cache.end()) return it->second.get();

    int styleFlags = Gdiplus::FontStyleRegular;
    if (bold) styleFlags |= Gdiplus::FontStyleBold;
    if (italic) styleFlags |= Gdiplus::FontStyleItalic;
    if (underline) styleFlags |= Gdiplus::FontStyleUnderline;

    auto font = std::make_unique<Gdiplus::Font>(&g_fontFamilyHolder.family, (Gdiplus::REAL)fontSizePx,
                                                 (Gdiplus::FontStyle)styleFlags, Gdiplus::UnitPixel);
    Gdiplus::Font* raw = font.get();
    g_fontCache.cache[key] = std::move(font);
    return raw;
}

// Measure()와 PaintBox() 둘 다 이 포맷을 써야 측정한 폭과 실제로 그려지는 폭이
// 어긋나지 않는다 (기본 StringFormat은 글자 앞뒤에 여분 여백을 넣어서 다름).
const Gdiplus::StringFormat& TypographicFormat() {
    static const Gdiplus::StringFormat* kFormat = Gdiplus::StringFormat::GenericTypographic()->Clone();
    return *kFormat;
}

Gdiplus::Color ToGdiColor(const RgbColor& c) { return Gdiplus::Color(c.a, c.r, c.g, c.b); }

void BuildRoundedRectPath(Gdiplus::GraphicsPath& path, Gdiplus::REAL x, Gdiplus::REAL y,
                           Gdiplus::REAL w, Gdiplus::REAL h, Gdiplus::REAL radius) {
    path.Reset();
    if (w <= 0 || h <= 0) return;

    Gdiplus::REAL d = radius * 2;
    if (d > w) d = w;
    if (d > h) d = h;

    if (d <= 0.5f) { path.AddRectangle(Gdiplus::RectF(x, y, w, h)); return; }

    path.AddArc(x, y, d, d, 180, 90);
    path.AddArc(x + w - d, y, d, d, 270, 90);
    path.AddArc(x + w - d, y + h - d, d, d, 0, 90);
    path.AddArc(x, y + h - d, d, d, 90, 90);
    path.CloseFigure();
}

// 이 박스의 마진 박스(바깥 경계) 수직 범위. 컬링 판정에 사용.
void OuterVerticalExtent(const LayoutBox* box, int& top, int& bottom) {
    if (box->isTextRun) {
        top = box->y;
        bottom = box->y + box->contentHeight;
        return;
    }
    top = box->OuterTop();
    bottom = box->y + box->contentHeight + box->padding.bottom + box->border.bottom + box->margin.bottom;
}

} // namespace

TextMetrics GdiPainter::Measure(HDC hdc, const std::wstring& text, int fontSizePx, bool bold, bool italic) {
    Gdiplus::Graphics g(hdc);
    g.SetTextRenderingHint(Gdiplus::TextRenderingHintClearTypeGridFit);

    Gdiplus::Font* font = GetFont(fontSizePx, bold, italic);

    TextMetrics m;
    m.lineHeight = (int)std::ceil(font->GetHeight(&g));

    if (!text.empty()) {
        Gdiplus::RectF bounds;
        g.MeasureString(text.c_str(), (INT)text.size(), font, Gdiplus::PointF(0, 0), &TypographicFormat(), &bounds);
        m.width = (int)std::ceil(bounds.Width);
    }
    return m;
}

void GdiPainter::PaintBox(Gdiplus::Graphics& g, const LayoutBox* box, int scrollX, int scrollY,
                           int viewTop, int viewBottom, int shadowLayerCap) {
    int outerTop, outerBottom;
    OuterVerticalExtent(box, outerTop, outerBottom);
    // 화면 밖(위/아래)이면 이 박스와 자손 전체를 통째로 건너뛴다 - 텍스트 많은
    // 페이지에서 스크롤할 때마다 화면 밖 수천 단어까지 매번 그리던 게 렉의 주 원인이었음.
    if (outerBottom < viewTop || outerTop > viewBottom) return;

    if (box->isTextRun) {
        int x = box->x - scrollX;
        int y = box->y - scrollY;

        if (box->isImage) {
            // TODO(Phase 6+): 실제 이미지 디코딩. 지금은 크기가 맞는 둥근 회색 박스 + alt 텍스트.
            Gdiplus::GraphicsPath path;
            BuildRoundedRectPath(path, (Gdiplus::REAL)x, (Gdiplus::REAL)y,
                                  (Gdiplus::REAL)box->contentWidth, (Gdiplus::REAL)box->contentHeight, 4.0f);
            Gdiplus::SolidBrush bg(Gdiplus::Color(255, 235, 235, 235));
            g.FillPath(&bg, &path);
            Gdiplus::Pen pen(Gdiplus::Color(255, 180, 180, 180), 1.0f);
            g.DrawPath(&pen, &path);

            if (!box->text.empty()) {
                Gdiplus::Font* font = GetFont(12, false, false);
                Gdiplus::SolidBrush textBrush(Gdiplus::Color(255, 120, 120, 120));
                Gdiplus::RectF layoutRect((Gdiplus::REAL)x, (Gdiplus::REAL)y,
                                           (Gdiplus::REAL)box->contentWidth, (Gdiplus::REAL)box->contentHeight);
                Gdiplus::StringFormat centered;
                centered.SetAlignment(Gdiplus::StringAlignmentCenter);
                centered.SetLineAlignment(Gdiplus::StringAlignmentCenter);
                g.DrawString(box->text.c_str(), (INT)box->text.size(), font, layoutRect, &centered, &textBrush);
            }
            return;
        }

        Gdiplus::Font* font = GetFont(box->fontSizePx, box->fontBold, box->fontItalic, box->textDecorationUnderline);
        Gdiplus::SolidBrush brush(ToGdiColor(box->color));
        g.DrawString(box->text.c_str(), (INT)box->text.size(), font,
                      Gdiplus::PointF((Gdiplus::REAL)x, (Gdiplus::REAL)y), &TypographicFormat(), &brush);
        return; // 텍스트런은 자식이 없으므로 여기서 끝
    }

    int outerLeft = box->OuterLeft() - scrollX;
    int outerTopScreen = box->OuterTop() - scrollY;
    int borderBoxW = box->BorderBoxWidth();
    int borderBoxH = box->BorderBoxHeight();
    int boxX = outerLeft + box->margin.left;
    int boxY = outerTopScreen + box->margin.top;

    // 소프트 섀도우: 진짜 가우시안 블러 대신, 반투명 둥근사각형을 바깥으로 갈수록
    // 옅어지게 여러 겹 겹쳐서 흉내낸다 (가볍고 충분히 그럴듯한 근사).
    if (box->boxShadow && borderBoxW > 0 && borderBoxH > 0) {
        const BoxShadowValue& sh = *box->boxShadow;
        int shadowBaseX = boxX + sh.offsetX;
        int shadowBaseY = boxY + sh.offsetY;
        int layers = (std::min)(shadowLayerCap, (std::max)(1, sh.blurRadius / 2));

        for (int i = layers; i >= 1; --i) {
            float t = (float)i / (float)layers;
            int expand = (int)(sh.blurRadius * t);
            BYTE alpha = (BYTE)((sh.color.a / (float)layers) * 0.9f);
            if (alpha == 0) continue;

            Gdiplus::GraphicsPath shadowPath;
            BuildRoundedRectPath(shadowPath,
                (Gdiplus::REAL)(shadowBaseX - expand), (Gdiplus::REAL)(shadowBaseY - expand),
                (Gdiplus::REAL)(borderBoxW + expand * 2), (Gdiplus::REAL)(borderBoxH + expand * 2),
                (Gdiplus::REAL)(box->borderRadiusPx + expand));
            Gdiplus::SolidBrush shadowBrush(Gdiplus::Color(alpha, sh.color.r, sh.color.g, sh.color.b));
            g.FillPath(&shadowBrush, &shadowPath);
        }
    }

    if ((box->backgroundColor || (box->borderWidthPx > 0 && box->borderColor)) && borderBoxW > 0 && borderBoxH > 0) {
        Gdiplus::GraphicsPath boxPath;
        BuildRoundedRectPath(boxPath, (Gdiplus::REAL)boxX, (Gdiplus::REAL)boxY,
                              (Gdiplus::REAL)borderBoxW, (Gdiplus::REAL)borderBoxH, (Gdiplus::REAL)box->borderRadiusPx);

        if (box->backgroundColor) {
            Gdiplus::SolidBrush brush(ToGdiColor(*box->backgroundColor));
            g.FillPath(&brush, &boxPath);
        }
        if (box->borderWidthPx > 0 && box->borderColor) {
            Gdiplus::Pen pen(ToGdiColor(*box->borderColor), (Gdiplus::REAL)box->borderWidthPx);
            g.DrawPath(&pen, &boxPath);
        }
    }

    for (auto& child : box->children) PaintBox(g, child.get(), scrollX, scrollY, viewTop, viewBottom, shadowLayerCap);
}

void GdiPainter::Paint(HDC destHdc, const LayoutBox* root, int viewportWidth, int viewportHeight,
                        int scrollX, int scrollY, RenderQuality quality) {
    if (!root || viewportWidth <= 0 || viewportHeight <= 0) return;

    // 더블버퍼링: 화면에 직접 그리면 도형이 많아질수록(그림자, 둥근모서리 등) 깜빡임이
    // 보일 수 있어서 메모리 비트맵에 전부 그린 뒤 한 번에 옮긴다.
    HDC memDC = CreateCompatibleDC(destHdc);
    HBITMAP memBmp = CreateCompatibleBitmap(destHdc, viewportWidth, viewportHeight);
    HBITMAP oldBmp = (HBITMAP)SelectObject(memDC, memBmp);

    Gdiplus::SmoothingMode smoothing;
    Gdiplus::TextRenderingHint textHint;
    int shadowLayerCap;
    switch (quality) {
        case RenderQuality::Fast:
            smoothing = Gdiplus::SmoothingModeHighSpeed;
            textHint = Gdiplus::TextRenderingHintSingleBitPerPixelGridFit; // 안티앨리어싱 없음, 가장 빠름
            shadowLayerCap = 1;
            break;
        case RenderQuality::Medium:
            smoothing = Gdiplus::SmoothingModeAntiAlias;
            textHint = Gdiplus::TextRenderingHintAntiAlias; // ClearType보다 가벼운 안티앨리어싱
            shadowLayerCap = 4;
            break;
        case RenderQuality::High:
        default:
            smoothing = Gdiplus::SmoothingModeAntiAlias;
            textHint = Gdiplus::TextRenderingHintClearTypeGridFit;
            shadowLayerCap = 1000;
            break;
    }

    Gdiplus::Graphics g(memDC);
    g.SetSmoothingMode(smoothing);
    g.SetTextRenderingHint(textHint);
    g.SetPixelOffsetMode(Gdiplus::PixelOffsetModeHalf); // 선명한 픽셀 정렬
    g.Clear(Gdiplus::Color(255, 255, 255, 255));

    PaintBox(g, root, scrollX, scrollY, scrollY, scrollY + viewportHeight, shadowLayerCap);

    BitBlt(destHdc, 0, 0, viewportWidth, viewportHeight, memDC, 0, 0, SRCCOPY);

    SelectObject(memDC, oldBmp);
    DeleteObject(memBmp);
    DeleteDC(memDC);
}

} // namespace Xtentix
