#include "CssParser.h"
#include <cctype>
#include <algorithm>

namespace Xtentix {

namespace {

std::string Trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

std::vector<std::string> SplitTopLevel(const std::string& s, char delim) {
    // 지금 지원하는 선택자/선언 문법에는 괄호 중첩이 없으므로 단순 분리로 충분.
    std::vector<std::string> parts;
    size_t start = 0;
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == delim) {
            parts.push_back(s.substr(start, i - start));
            start = i + 1;
        }
    }
    parts.push_back(s.substr(start));
    return parts;
}

bool EndsWithImportant(std::string& value) {
    std::string lower = value;
    std::transform(lower.begin(), lower.end(), lower.begin(), [](unsigned char c) { return std::tolower(c); });
    size_t pos = lower.rfind("!important");
    if (pos == std::string::npos) return false;
    // "!important"가 값의 실질적인 끝부분(뒤에 공백만 있음)인지 확인
    std::string tail = Trim(lower.substr(pos + 10));
    if (!tail.empty()) return false;
    value = Trim(value.substr(0, pos));
    return true;
}

} // namespace

std::string CssParser::StripComments(const std::string& css) {
    std::string out;
    out.reserve(css.size());
    for (size_t i = 0; i < css.size();) {
        if (css[i] == '/' && i + 1 < css.size() && css[i + 1] == '*') {
            size_t end = css.find("*/", i + 2);
            i = (end == std::string::npos) ? css.size() : end + 2;
        } else {
            out += css[i];
            i++;
        }
    }
    return out;
}

CompoundSelector CssParser::ParseCompoundSelector(const std::string& token) {
    CompoundSelector c;
    size_t i = 0;
    std::string tag;
    while (i < token.size() && token[i] != '.' && token[i] != '#') {
        tag += token[i];
        i++;
    }
    if (tag != "*") c.tagName = tag; // "*"나 빈 문자열은 태그 조건 없음으로 취급

    while (i < token.size()) {
        char marker = token[i];
        i++;
        std::string name;
        while (i < token.size() && token[i] != '.' && token[i] != '#') {
            name += token[i];
            i++;
        }
        if (marker == '#') c.id = name;
        else if (marker == '.' && !name.empty()) c.classes.push_back(name);
    }
    return c;
}

ComplexSelector CssParser::ParseComplexSelector(const std::string& text) {
    // '>' 앞뒤에 공백을 강제해서 토큰 분리를 단순한 공백 split으로 처리할 수 있게 만든다.
    std::string normalized;
    normalized.reserve(text.size() + 8);
    for (char c : text) {
        if (c == '>') normalized += " > ";
        else normalized += c;
    }

    std::vector<std::string> tokens;
    {
        std::string cur;
        for (char c : normalized) {
            if (std::isspace((unsigned char)c)) {
                if (!cur.empty()) { tokens.push_back(cur); cur.clear(); }
            } else cur += c;
        }
        if (!cur.empty()) tokens.push_back(cur);
    }

    ComplexSelector sel;
    bool nextIsChild = false;
    for (auto& tok : tokens) {
        if (tok == ">") { nextIsChild = true; continue; }
        sel.compounds.push_back(ParseCompoundSelector(tok));
        if (sel.compounds.size() > 1) {
            sel.combinators.push_back(nextIsChild ? Combinator::Child : Combinator::Descendant);
        }
        nextIsChild = false;
    }
    return sel;
}

std::vector<ComplexSelector> CssParser::ParseSelectorGroup(const std::string& text) {
    std::vector<ComplexSelector> group;
    for (auto& part : SplitTopLevel(text, ',')) {
        std::string trimmed = Trim(part);
        if (trimmed.empty()) continue;
        group.push_back(ParseComplexSelector(trimmed));
    }
    return group;
}

std::vector<CssDeclaration> CssParser::ParseDeclarationBlock(const std::string& block) {
    std::vector<CssDeclaration> decls;
    for (auto& part : SplitTopLevel(block, ';')) {
        std::string trimmed = Trim(part);
        if (trimmed.empty()) continue;

        size_t colon = trimmed.find(':');
        if (colon == std::string::npos) continue;

        CssDeclaration decl;
        decl.property = Trim(trimmed.substr(0, colon));
        std::transform(decl.property.begin(), decl.property.end(), decl.property.begin(),
                        [](unsigned char c) { return std::tolower(c); });
        decl.value = Trim(trimmed.substr(colon + 1));
        decl.important = EndsWithImportant(decl.value);
        if (!decl.property.empty()) decls.push_back(std::move(decl));
    }
    return decls;
}

size_t CssParser::FindMatchingBrace(const std::string& css, size_t openBracePos) {
    int depth = 0;
    for (size_t i = openBracePos; i < css.size(); ++i) {
        if (css[i] == '{') depth++;
        else if (css[i] == '}') {
            depth--;
            if (depth == 0) return i;
        }
    }
    return std::string::npos;
}

std::vector<CssRule> CssParser::Parse(const std::string& cssIn) {
    std::string css = StripComments(cssIn);
    std::vector<CssRule> rules;

    size_t pos = 0;
    while (pos < css.size()) {
        size_t openBrace = css.find('{', pos);
        if (openBrace == std::string::npos) break;

        std::string selectorText = Trim(css.substr(pos, openBrace - pos));

        if (!selectorText.empty() && selectorText[0] == '@') {
            // TODO(Phase 5+): @media 등 at-rule 내부 평가. 지금은 통째로 건너뛴다.
            size_t close = FindMatchingBrace(css, openBrace);
            pos = (close == std::string::npos) ? css.size() : close + 1;
            continue;
        }

        size_t closeBrace = FindMatchingBrace(css, openBrace);
        if (closeBrace == std::string::npos) break;

        if (!selectorText.empty()) {
            CssRule rule;
            rule.selectorGroup = ParseSelectorGroup(selectorText);
            rule.declarations = ParseDeclarationBlock(css.substr(openBrace + 1, closeBrace - openBrace - 1));
            if (!rule.selectorGroup.empty() && !rule.declarations.empty()) {
                rules.push_back(std::move(rule));
            }
        }
        pos = closeBrace + 1;
    }
    return rules;
}

} // namespace Xtentix
