#pragma once
#include <string>
#include <vector>
#include <memory>

namespace Xtentix {

enum class NodeType {
    Document,
    Element,
    Text,
    Comment,
    Doctype
};

// DOM 트리의 노드 하나. Element/Text/Comment/Document/Doctype을 한 클래스로 표현하고
// type으로 구분한다 (v8/Blink처럼 클래스를 쪼개는 대신, 지금 규모에서는 단일 클래스가
// 더 단순함 — Phase가 커지면 Element를 서브클래스로 분리 고려).
class DomNode {
public:
    explicit DomNode(NodeType type) : m_type(type) {}

    NodeType Type() const { return m_type; }

    // Element 전용
    const std::string& TagName() const { return m_tagName; }
    void SetTagName(std::string name) { m_tagName = std::move(name); }

    const std::vector<std::pair<std::string, std::string>>& Attributes() const { return m_attributes; }
    void SetAttribute(const std::string& name, const std::string& value);
    std::string GetAttribute(const std::string& name) const;
    bool HasAttribute(const std::string& name) const;

    // Text/Comment 전용
    const std::string& Data() const { return m_data; }
    void SetData(std::string data) { m_data = std::move(data); }
    void AppendData(const std::string& more) { m_data += more; }

    // 트리 구조
    DomNode* Parent() const { return m_parent; }
    const std::vector<std::unique_ptr<DomNode>>& Children() const { return m_children; }
    DomNode* AppendChild(std::unique_ptr<DomNode> child);

    // 디버그/테스트용 트리 출력 (Phase 4에서 "페이지 소스 보기"에 재사용 가능)
    void DebugPrint(int depth = 0) const;

private:
    NodeType m_type;
    std::string m_tagName;   // Element
    std::string m_data;      // Text / Comment / Doctype
    std::vector<std::pair<std::string, std::string>> m_attributes; // Element, 입력 순서 유지
    DomNode* m_parent = nullptr;
    std::vector<std::unique_ptr<DomNode>> m_children;
};

} // namespace Xtentix
