#pragma once
#include <string>
#include <optional>

namespace Xtentix {

// Win32에 묶이지 않은 순수 RGBA 표현. GdiPainter에서만 Gdiplus::Color로 변환한다.
// (LayoutEngine/CssValues를 Windows 헤더에서 분리해두면 리눅스에서도 네이티브로
//  단위 테스트할 수 있어서 — 지금까지 HtmlParser/CssParser도 이 방식으로 검증함)
struct RgbColor {
    unsigned char r = 0, g = 0, b = 0, a = 255;
};

struct BoxShadowValue {
    int offsetX = 0, offsetY = 0, blurRadius = 0;
    RgbColor color{ 0, 0, 0, 255 };
};

// LayoutEngine/GdiPainter가 공유하는 CSS 값 파싱.
//   지원: "Npx" 길이, "N%" 퍼센트, "#rgb"/"#rrggbb"/"rgb()"/"rgba()"/기본 색상 이름,
//         "offsetX offsetY blurRadius color" 형태의 box-shadow(단일 그림자만)
//   미지원(TODO): em/rem/calc(), 다중 그림자, inset, spread-radius, 모서리별 border-radius
class CssValues {
public:
    static std::optional<int> ParseLengthPx(const std::string& value);
    static std::optional<double> ParsePercentage(const std::string& value); // "50%" -> 50.0
    static std::optional<RgbColor> ParseColor(const std::string& value);
    static std::optional<BoxShadowValue> ParseBoxShadow(const std::string& value);
};

} // namespace Xtentix

