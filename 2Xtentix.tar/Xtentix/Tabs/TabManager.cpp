#include "TabManager.h"
#include <algorithm>

namespace Xtentix {

Tab* TabManager::CreateTab(const std::string& url, const std::string& title, bool incognito) {
    auto tab = std::make_unique<Tab>(m_nextId++, url, title);
    tab->SetIncognito(incognito);
    Tab* raw = tab.get();
    m_tabs.push_back(std::move(tab));
    m_activeIndex = m_tabs.size() - 1;
    NotifyChanged();
    return raw;
}

bool TabManager::CloseTab(TabId id) {
    auto it = std::find_if(m_tabs.begin(), m_tabs.end(),
        [id](const std::unique_ptr<Tab>& t) { return t->Id() == id; });
    if (it == m_tabs.end()) return false;

    size_t index = (size_t)std::distance(m_tabs.begin(), it);
    m_tabs.erase(it);

    if (m_tabs.empty()) {
        m_activeIndex = static_cast<size_t>(-1);
    } else if (m_activeIndex >= m_tabs.size()) {
        m_activeIndex = m_tabs.size() - 1;
    } else if (index <= m_activeIndex && m_activeIndex > 0) {
        m_activeIndex--;
    }
    NotifyChanged();
    return true;
}

Tab* TabManager::ActiveTab() const {
    if (m_activeIndex == static_cast<size_t>(-1) || m_activeIndex >= m_tabs.size()) return nullptr;
    return m_tabs[m_activeIndex].get();
}

Tab* TabManager::FindById(TabId id) const {
    for (auto& t : m_tabs) if (t->Id() == id) return t.get();
    return nullptr;
}

bool TabManager::SetActiveTab(TabId id) {
    for (size_t i = 0; i < m_tabs.size(); ++i) {
        if (m_tabs[i]->Id() == id) {
            m_activeIndex = i;
            NotifyChanged();
            return true;
        }
    }
    return false;
}

void TabManager::NotifyChanged() {
    if (m_onChanged) m_onChanged();
}

} // namespace Xtentix
