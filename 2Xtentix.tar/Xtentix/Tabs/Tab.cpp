#include "Tab.h"

namespace Xtentix {

Tab::Tab(TabId id, std::string url, std::string title)
    : m_id(id), m_url(std::move(url)), m_title(std::move(title)) {}

} // namespace Xtentix
