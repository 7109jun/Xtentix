#include "Application.h"
#include <gdiplus.h>

namespace Xtentix {

int Application::Run(HINSTANCE instance, int cmdShow) {
    // GDI+는 새 탭 페이지의 로고 렌더링(Gdiplus::Bitmap/Graphics)에 쓰이므로
    // 어떤 윈도우보다도 먼저 초기화되어야 한다.
    Gdiplus::GdiplusStartupInput gdiplusStartupInput;
    ULONG_PTR gdiplusToken;
    Gdiplus::GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, nullptr);

    int exitCode = -1;
    if (m_mainWindow.Create(instance, cmdShow)) {
        // F12 = 개발자 도구 토글, Ctrl+Shift+N = 새 시크릿 탭.
        // 포커스가 주소창 EDIT 컨트롤에 있어도 이 가속기가 먼저 가로채서 WM_COMMAND로 보낸다.
        ACCEL accels[] = {
            { FVIRTKEY, VK_F12, (WORD)MainWindow::kCmdToggleDevTools },
            { FVIRTKEY | FCONTROL | FSHIFT, 'N', (WORD)MainWindow::kCmdNewIncognitoTab },
        };
        HACCEL hAccel = CreateAcceleratorTableW(accels, 2);

        MSG msg;
        while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
            if (!TranslateAccelerator(m_mainWindow.Handle(), hAccel, &msg)) {
                TranslateMessage(&msg);
                DispatchMessageW(&msg);
            }
        }
        exitCode = (int)msg.wParam;

        DestroyAcceleratorTable(hAccel);
    }

    Gdiplus::GdiplusShutdown(gdiplusToken);
    return exitCode;
}

} // namespace Xtentix
