#include "SettingsManager.h"
#include "../Utils/Json.h"
#include <fstream>
#include <filesystem>
#include <cstdlib>

namespace Xtentix {

std::string SettingsManager::DefaultFilePath() {
    const char* appdata = std::getenv("APPDATA");
    std::filesystem::path base = appdata ? std::filesystem::path(appdata) : std::filesystem::current_path();
    std::filesystem::path dir = base / "Xtentix";

    std::error_code ec;
    std::filesystem::create_directories(dir, ec);

    return (dir / "settings.json").string();
}

std::string SettingsManager::Get(const std::string& key, const std::string& defaultValue) const {
    auto it = m_values.find(key);
    return it != m_values.end() ? it->second : defaultValue;
}

void SettingsManager::Set(const std::string& key, const std::string& value) {
    m_values[key] = value;
    Save();
}

void SettingsManager::Load() {
    m_values.clear();

    std::ifstream file(DefaultFilePath(), std::ios::binary);
    if (!file) return; // 첫 실행이면 파일이 없는 게 정상

    std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    JsonValue root = JsonValue::Parse(content);
    if (!root.IsObject()) return;

    for (auto& kv : root.AsObject()) {
        if (kv.second.IsString()) m_values[kv.first] = kv.second.AsString();
    }
}

void SettingsManager::Save() const {
    JsonObject obj;
    for (auto& kv : m_values) obj.emplace_back(kv.first, JsonValue(kv.second));

    std::ofstream file(DefaultFilePath(), std::ios::binary | std::ios::trunc);
    if (!file) return;
    std::string json = JsonValue(std::move(obj)).Stringify(2);
    file.write(json.data(), (std::streamsize)json.size());
}

} // namespace Xtentix
