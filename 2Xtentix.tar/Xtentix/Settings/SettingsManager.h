#pragma once
#include <string>
#include <unordered_map>

namespace Xtentix {

// %APPDATA%/Xtentix/settings.json 에 자동 저장/로드. "사용자가 관리하지 않아도
// 쾌적한 브라우저" 철학에 따라 기본값이 항상 합리적이도록 설계 - 수동 튜닝은
// 최소한만 노출한다 (지금은 news_feed_url 정도).
class SettingsManager {
public:
    std::string Get(const std::string& key, const std::string& defaultValue = "") const;
    void Set(const std::string& key, const std::string& value);
    const std::unordered_map<std::string, std::string>& All() const { return m_values; }

    void Load();
    static std::string DefaultFilePath();

private:
    void Save() const;

    std::unordered_map<std::string, std::string> m_values;
};

} // namespace Xtentix
