#pragma once
#include "../Core/WindowBase.h"
#include "../Network/CookieJar.h"
#include "../Rendering/Dom.h"
#include "CookiePanel.h"
#include <functional>
#include <string>

namespace Xtentix {

// F12로 열리는 개발자 도구. 세 개 패널을 위쪽 버튼으로 전환한다:
//   Elements - 예쁘게 정렬된 HTML 소스, 편집 후 "적용"하면 그 탭이 즉시 재렌더링됨
//              (단, 적용한 시점부터 그 탭은 샌드박스 모드로 전환 - 네트워크 차단)
//   Cookies  - 현재 사이트의 쿠키 보기/추가/삭제 (CookiePanel 재사용)
//   Issues   - 간단한 정적 분석 결과 목록
class DevToolsWindow : public WindowBase {
public:
    using ApplyHtmlCallback = std::function<void(const std::string& html)>;

    bool Create(HINSTANCE instance);
    void SetOnApplyHtml(ApplyHtmlCallback cb) { m_onApplyHtml = std::move(cb); }

    // MainWindow가 활성 탭이 바뀌거나 페이지 로드가 끝날 때마다 호출해서 내용을 갱신.
    void RefreshForTab(const std::string& host, const DomNode* root, CookieJar* jar, bool sandboxed);

    void ToggleVisible();
    bool IsVisible() const;

protected:
    bool HandleMessage(UINT msg, WPARAM wParam, LPARAM lParam, LRESULT& outResult) override;

private:
    void SwitchPanel(int index);
    void LayoutChildren();
    void OnApplyClicked();

    static constexpr UINT kBtnElements = 4001;
    static constexpr UINT kBtnCookies = 4002;
    static constexpr UINT kBtnIssues = 4003;
    static constexpr UINT kBtnApply = 4004;

    HINSTANCE m_instance = nullptr;
    HWND m_btnElements = nullptr, m_btnCookies = nullptr, m_btnIssues = nullptr;
    HWND m_htmlEdit = nullptr, m_applyButton = nullptr;
    HWND m_issuesEdit = nullptr;
    HWND m_sandboxLabel = nullptr;
    CookiePanel m_cookiePanel;

    int m_activePanel = 0; // 0=Elements, 1=Cookies, 2=Issues
    CookieJar* m_jar = nullptr;
    ApplyHtmlCallback m_onApplyHtml;
};

} // namespace Xtentix
