#pragma once
#include "../Core/WindowBase.h"
#include "../Tabs/TabManager.h"
#include <functional>
#include <vector>

namespace Xtentix {

// 상단 탭 목록을 그리는 커스텀 컨트롤. 실제 탭 상태는 TabManager가 소유하고,
// 이 클래스는 그리기 + 클릭 히트테스트만 담당한다 (View 역할).
class TabStrip : public WindowBase {
public:
    static constexpr int kHeight = 36;
    static constexpr int kTabWidth = 200;
    static constexpr int kTabMinWidth = 80;
    static constexpr int kCloseBoxSize = 16;
    static constexpr int kNewTabButtonWidth = 32;

    using SelectCallback = std::function<void(TabId)>;
    using CloseCallback = std::function<void(TabId)>;
    using NewTabCallback = std::function<void()>;

    HWND Create(HWND parent, HINSTANCE instance, TabManager* tabManager);

    void OnSelect(SelectCallback cb) { m_onSelect = std::move(cb); }
    void OnClose(CloseCallback cb) { m_onClose = std::move(cb); }
    void OnNewTab(NewTabCallback cb) { m_onNewTab = std::move(cb); }

protected:
    bool HandleMessage(UINT msg, WPARAM wParam, LPARAM lParam, LRESULT& outResult) override;

private:
    struct TabRect { TabId id; RECT rect; RECT closeRect; };

    void Paint();
    void HandleClick(int x, int y);

    TabManager* m_tabManager = nullptr;
    std::vector<TabRect> m_tabRects;
    RECT m_newTabRect{};
    SelectCallback m_onSelect;
    CloseCallback m_onClose;
    NewTabCallback m_onNewTab;
};

} // namespace Xtentix
