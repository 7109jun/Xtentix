#include "NewTabPage.h"
#include "../Utils/StringUtils.h"
#include "../Utils/ResourceImage.h"
#include "../Resources/resource.h"
#include <windowsx.h>
#include <algorithm>

namespace Xtentix {

HWND NewTabPage::Create(HWND parent, HINSTANCE instance, BookmarkManager* bookmarks, SettingsManager* settings) {
    m_instance = instance;
    m_bookmarks = bookmarks;
    m_settings = settings;

    CreateWindowInternal(L"XtentixNewTabPage", L"", WS_CHILD, 0, 0, 0, 0, 0, parent, nullptr, instance);

    m_logo = ResourceImage::LoadPngFromResource(instance, IDR_LOGO_PNG);

    FetchNews();
    return m_hwnd;
}

void NewTabPage::FetchNews() {
    m_newsLoading = true;
    m_newsFailed = false;

    std::string feedUrl = m_settings->Get("news_feed_url", "https://feeds.bbci.co.uk/news/rss.xml");
    HWND self = m_hwnd;

    m_httpClient.GetAsync(feedUrl, [self](const HttpResponse& response) {
        // 워커 스레드: 상태를 직접 건드리지 않고 힙에 복사해서 UI 스레드로 넘긴다.
        auto* copy = new HttpResponse(response);
        PostMessage(self, kNewsReadyMsg, 0, reinterpret_cast<LPARAM>(copy));
    });
}

void NewTabPage::OnNewsFetched(HttpResponse response) {
    m_newsLoading = false;
    if (response.success) {
        m_newsItems = RssParser::Parse(response.body, 8);
        m_newsFailed = m_newsItems.empty();
    } else {
        m_newsFailed = true;
    }
    InvalidateRect(m_hwnd, nullptr, TRUE);
}

bool NewTabPage::HandleMessage(UINT msg, WPARAM /*wParam*/, LPARAM lParam, LRESULT& outResult) {
    switch (msg) {
        case WM_PAINT:
            Paint();
            outResult = 0;
            return true;
        case WM_LBUTTONDOWN:
            HandleClick(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
            outResult = 0;
            return true;
        case WM_ERASEBKGND:
            outResult = 1;
            return true;
        case WM_SETCURSOR: {
            POINT pt; GetCursorPos(&pt); ScreenToClient(m_hwnd, &pt);
            bool overLink = std::any_of(m_clickRects.begin(), m_clickRects.end(),
                [&](auto& cr) { return PtInRect(&cr.rect, pt) != 0; });
            SetCursor(LoadCursor(nullptr, overLink ? IDC_HAND : IDC_ARROW));
            outResult = TRUE;
            return true;
        }
    }
    if (msg == kNewsReadyMsg) {
        auto* response = reinterpret_cast<HttpResponse*>(lParam);
        OnNewsFetched(*response);
        delete response;
        outResult = 0;
        return true;
    }
    return false;
}

void NewTabPage::HandleClick(int x, int y) {
    POINT pt{ x, y };
    for (auto& cr : m_clickRects) {
        if (PtInRect(&cr.rect, pt)) {
            if (m_onNavigate) m_onNavigate(cr.url);
            return;
        }
    }
}

namespace {
HFONT MakeFont(int size, bool bold = false) {
    return CreateFontW(-size, 0, 0, 0, bold ? FW_BOLD : FW_NORMAL, FALSE, FALSE, FALSE,
                        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                        CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
}
} // namespace

void NewTabPage::Paint() {
    PAINTSTRUCT ps;
    HDC hdc = BeginPaint(m_hwnd, &ps);
    RECT client; GetClientRect(m_hwnd, &client);
    int width = client.right;

    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBmp = CreateCompatibleBitmap(hdc, client.right, client.bottom);
    HBITMAP oldBmp = (HBITMAP)SelectObject(memDC, memBmp);

    HBRUSH bg = CreateSolidBrush(RGB(255, 255, 255));
    FillRect(memDC, &client, bg);
    DeleteObject(bg);
    SetBkMode(memDC, TRANSPARENT);

    m_clickRects.clear();
    int y = 24;
    int centerX = width / 2;

    // 로고
    if (m_logo && m_logo->GetLastStatus() == Gdiplus::Ok) {
        Gdiplus::Graphics g(memDC);
        g.SetInterpolationMode(Gdiplus::InterpolationModeNearestNeighbor); // 픽셀아트 로고라 흐려지지 않게
        int logoSize = 64;
        g.DrawImage(m_logo.get(), centerX - logoSize / 2, y, logoSize, logoSize);
        y += logoSize + 8;
    } else {
        y += 40;
    }

    HFONT titleFont = MakeFont(20, true);
    HFONT sectionFont = MakeFont(13, true);
    HFONT bodyFont = MakeFont(13, false);
    HFONT smallFont = MakeFont(12, false);

    HFONT oldFont = (HFONT)SelectObject(memDC, titleFont);
    RECT titleRect{ 0, y, width, y + 30 };
    SetTextColor(memDC, RGB(40, 44, 52));
    DrawTextW(memDC, L"Xtentix Browser", -1, &titleRect, DT_CENTER | DT_SINGLELINE);
    y += 44;

    int contentLeft = (std::max)(24, centerX - 320);
    int contentRight = (std::min)(width - 24, centerX + 320);
    int contentWidth = contentRight - contentLeft;

    // ── 바로가기 ──────────────────────────────────────────
    SelectObject(memDC, sectionFont);
    SetTextColor(memDC, RGB(90, 90, 90));
    RECT shortcutTitle{ contentLeft, y, contentRight, y + 20 };
    DrawTextW(memDC, L"\uBC14\uB85C\uAC00\uAE30", -1, &shortcutTitle, DT_LEFT | DT_SINGLELINE);
    y += 26;

    const auto& allBookmarks = m_bookmarks->Entries();
    if (allBookmarks.empty()) {
        SelectObject(memDC, smallFont);
        SetTextColor(memDC, RGB(150, 150, 150));
        RECT emptyRect{ contentLeft, y, contentRight, y + 20 };
        DrawTextW(memDC, L"\uC8FC\uC18C\uCC3D \uC637\uC5D0 \uBCC4\uD45C\uB97C \uB204\uB974\uBA74 \uC5EC\uAE30\uC5D0 \uCD94\uAC00\uB429\uB2C8\uB2E4",
                  -1, &emptyRect, DT_LEFT | DT_SINGLELINE);
        y += 30;
    } else {
        int tilesPerRow = (std::max)(1, contentWidth / kShortcutTileSize);
        size_t count = (std::min)(allBookmarks.size(), (size_t)kShortcutMax);
        int rows = (int)((count + tilesPerRow - 1) / tilesPerRow);

        for (size_t i = 0; i < count; ++i) {
            int col = (int)i % tilesPerRow;
            int row = (int)i / tilesPerRow;
            int tileX = contentLeft + col * kShortcutTileSize;
            int tileY = y + row * kShortcutTileSize;

            RECT iconRect{ tileX + 8, tileY, tileX + kShortcutTileSize - 8, tileY + 48 };
            HBRUSH tileBrush = CreateSolidBrush(RGB(230, 234, 240));
            FillRect(memDC, &iconRect, tileBrush);
            DeleteObject(tileBrush);

            std::wstring initial = StringUtils::Utf8ToWide(allBookmarks[i].title.substr(0, 1));
            SelectObject(memDC, sectionFont);
            SetTextColor(memDC, RGB(60, 100, 200));
            DrawTextW(memDC, initial.c_str(), -1, &iconRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

            RECT labelRect{ tileX, tileY + 50, tileX + kShortcutTileSize, tileY + 68 };
            SelectObject(memDC, smallFont);
            SetTextColor(memDC, RGB(60, 60, 60));
            std::wstring label = StringUtils::Utf8ToWide(allBookmarks[i].title);
            DrawTextW(memDC, label.c_str(), -1, &labelRect, DT_CENTER | DT_SINGLELINE | DT_END_ELLIPSIS);

            RECT hitRect{ tileX, tileY, tileX + kShortcutTileSize, tileY + 68 };
            m_clickRects.push_back({ hitRect, allBookmarks[i].url });
        }
        y += rows * kShortcutTileSize + 12;
    }

    y += 12;

    // ── 북마크 ────────────────────────────────────────────
    SelectObject(memDC, sectionFont);
    SetTextColor(memDC, RGB(90, 90, 90));
    RECT bmTitleRect{ contentLeft, y, contentRight, y + 20 };
    DrawTextW(memDC, L"\uBD81\uB9C8\uD06C", -1, &bmTitleRect, DT_LEFT | DT_SINGLELINE);
    y += 26;

    if (allBookmarks.empty()) {
        SelectObject(memDC, smallFont);
        SetTextColor(memDC, RGB(150, 150, 150));
        RECT emptyRect{ contentLeft, y, contentRight, y + 20 };
        DrawTextW(memDC, L"\uC800\uC7A5\uB41C \uBD81\uB9C8\uD06C\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4", -1, &emptyRect, DT_LEFT | DT_SINGLELINE);
        y += 26;
    } else {
        SelectObject(memDC, bodyFont);
        for (auto& bm : allBookmarks) {
            RECT rowRect{ contentLeft, y, contentRight, y + 22 };
            SetTextColor(memDC, RGB(30, 90, 200));
            std::wstring line = StringUtils::Utf8ToWide(bm.title);
            DrawTextW(memDC, line.c_str(), -1, &rowRect, DT_LEFT | DT_SINGLELINE | DT_END_ELLIPSIS);
            m_clickRects.push_back({ rowRect, bm.url });
            y += 22;
        }
    }

    y += 20;

    // ── 뉴스 ──────────────────────────────────────────────
    SelectObject(memDC, sectionFont);
    SetTextColor(memDC, RGB(90, 90, 90));
    RECT newsTitleRect{ contentLeft, y, contentRight, y + 20 };
    DrawTextW(memDC, L"\uB274\uC2A4", -1, &newsTitleRect, DT_LEFT | DT_SINGLELINE);
    y += 26;

    SelectObject(memDC, bodyFont);
    if (m_newsLoading) {
        SetTextColor(memDC, RGB(150, 150, 150));
        RECT r{ contentLeft, y, contentRight, y + 22 };
        DrawTextW(memDC, L"\uB274\uC2A4\uB97C \uBD88\uB7EC\uC624\uB294 \uC911...", -1, &r, DT_LEFT | DT_SINGLELINE);
        y += 22;
    } else if (m_newsFailed) {
        SetTextColor(memDC, RGB(180, 80, 80));
        RECT r{ contentLeft, y, contentRight, y + 22 };
        DrawTextW(memDC, L"\uB274\uC2A4\uB97C \uBD88\uB7EC\uC624\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4 (\uC124\uC815\uC5D0\uC11C \uD53C\uB4DC URL\uC744 \uD655\uC778\uD558\uC138\uC694)",
                  -1, &r, DT_LEFT | DT_SINGLELINE);
        y += 22;
    } else {
        for (auto& item : m_newsItems) {
            RECT rowRect{ contentLeft, y, contentRight, y + 22 };
            SetTextColor(memDC, RGB(30, 30, 30));
            std::wstring line = StringUtils::Utf8ToWide(item.title);
            DrawTextW(memDC, line.c_str(), -1, &rowRect, DT_LEFT | DT_SINGLELINE | DT_END_ELLIPSIS);
            m_clickRects.push_back({ rowRect, item.link });
            y += 22;
        }
    }

    SelectObject(memDC, oldFont);
    DeleteObject(titleFont);
    DeleteObject(sectionFont);
    DeleteObject(bodyFont);
    DeleteObject(smallFont);

    BitBlt(hdc, 0, 0, client.right, client.bottom, memDC, 0, 0, SRCCOPY);
    SelectObject(memDC, oldBmp);
    DeleteObject(memBmp);
    DeleteDC(memDC);

    EndPaint(m_hwnd, &ps);
}

} // namespace Xtentix
