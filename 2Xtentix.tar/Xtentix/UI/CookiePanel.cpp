#include "CookiePanel.h"
#include "../Utils/StringUtils.h"
#include <commctrl.h>
#include <windowsx.h>
#include <algorithm>

namespace Xtentix {

namespace {
std::wstring W(const std::string& s) { return StringUtils::Utf8ToWide(s); }
std::string GetEditText(HWND hwnd) {
    wchar_t buf[512];
    GetWindowTextW(hwnd, buf, 512);
    return StringUtils::WideToUtf8(buf);
}
} // namespace

HWND CookiePanel::Create(HWND parent, HINSTANCE instance) {
    INITCOMMONCONTROLSEX icc{ sizeof(icc), ICC_LISTVIEW_CLASSES };
    InitCommonControlsEx(&icc);

    CreateWindowInternal(L"XtentixCookiePanel", L"", WS_CHILD, 0, 0, 0, 0, 0, parent, nullptr, instance);

    m_list = CreateWindowExW(WS_EX_CLIENTEDGE, WC_LISTVIEWW, L"",
        WS_CHILD | WS_VISIBLE | LVS_REPORT | LVS_SINGLESEL,
        0, 0, 0, 0, m_hwnd, (HMENU)(UINT_PTR)kListId, instance, nullptr);
    ListView_SetExtendedListViewStyle(m_list, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);

    LVCOLUMNW col{};
    col.mask = LVCF_TEXT | LVCF_WIDTH;
    std::wstring hostHeader = L"Host", nameHeader = L"Name", valueHeader = L"Value";
    col.pszText = hostHeader.data(); col.cx = 150; ListView_InsertColumn(m_list, 0, &col);
    col.pszText = nameHeader.data(); col.cx = 100; ListView_InsertColumn(m_list, 1, &col);
    col.pszText = valueHeader.data(); col.cx = 160; ListView_InsertColumn(m_list, 2, &col);

    m_hostEdit = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
        0, 0, 0, 0, m_hwnd, (HMENU)(UINT_PTR)kHostEditId, instance, nullptr);
    m_nameEdit = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
        0, 0, 0, 0, m_hwnd, (HMENU)(UINT_PTR)kNameEditId, instance, nullptr);
    m_valueEdit = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
        0, 0, 0, 0, m_hwnd, (HMENU)(UINT_PTR)kValueEditId, instance, nullptr);

    m_addButton = CreateWindowExW(0, L"BUTTON", L"\uCD94\uAC00/\uC800\uC7A5", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        0, 0, 0, 0, m_hwnd, (HMENU)(UINT_PTR)kAddButtonId, instance, nullptr);
    m_deleteButton = CreateWindowExW(0, L"BUTTON", L"\uC120\uD0DD \uC0AD\uC81C", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        0, 0, 0, 0, m_hwnd, (HMENU)(UINT_PTR)kDeleteButtonId, instance, nullptr);

    return m_hwnd;
}

void CookiePanel::SetLayoutRect(int x, int y, int width, int height) {
    m_rect = { x, y, x + width, y + height };
    SetWindowPos(m_hwnd, nullptr, x, y, width, height, SWP_NOZORDER);
    LayoutChildren();
}

void CookiePanel::LayoutChildren() {
    int width = m_rect.right - m_rect.left;
    int height = m_rect.bottom - m_rect.top;
    int listHeight = (std::max)(60, height - 70);

    SetWindowPos(m_list, nullptr, 0, 0, width, listHeight, SWP_NOZORDER);

    int editY = listHeight + 6;
    int editW = (std::max)(60, (width - 16) / 3);
    SetWindowPos(m_hostEdit, nullptr, 0, editY, editW, 24, SWP_NOZORDER);
    SetWindowPos(m_nameEdit, nullptr, editW + 8, editY, editW, 24, SWP_NOZORDER);
    SetWindowPos(m_valueEdit, nullptr, (editW + 8) * 2, editY, editW, 24, SWP_NOZORDER);

    int btnY = editY + 32;
    SetWindowPos(m_addButton, nullptr, 0, btnY, 100, 26, SWP_NOZORDER);
    SetWindowPos(m_deleteButton, nullptr, 108, btnY, 100, 26, SWP_NOZORDER);

    bool filterActive = !m_hostFilter.empty();
    EnableWindow(m_hostEdit, filterActive ? FALSE : TRUE);
}

void CookiePanel::Refresh(CookieJar* jar, const std::string& hostFilter) {
    m_jar = jar;
    m_hostFilter = hostFilter;
    if (m_hostEdit) SetWindowTextW(m_hostEdit, W(hostFilter).c_str());
    EnableWindow(m_hostEdit, hostFilter.empty() ? TRUE : FALSE);
    ReloadList();
}

void CookiePanel::ReloadList() {
    if (!m_list) return;
    ListView_DeleteAllItems(m_list);
    if (!m_jar) return;

    std::vector<std::string> hosts = m_hostFilter.empty() ? m_jar->AllHosts() : std::vector<std::string>{ m_hostFilter };

    int row = 0;
    for (auto& host : hosts) {
        for (auto& cookie : m_jar->GetCookies(host)) {
            std::wstring hostW = W(host), nameW = W(cookie.name), valueW = W(cookie.value);

            LVITEMW item{};
            item.mask = LVIF_TEXT;
            item.iItem = row;
            item.iSubItem = 0;
            item.pszText = hostW.data();
            ListView_InsertItem(m_list, &item);
            ListView_SetItemText(m_list, row, 1, nameW.data());
            ListView_SetItemText(m_list, row, 2, valueW.data());
            row++;
        }
    }
}

void CookiePanel::OnAddClicked() {
    if (!m_jar) return;
    std::string host = m_hostFilter.empty() ? GetEditText(m_hostEdit) : m_hostFilter;
    std::string name = GetEditText(m_nameEdit);
    std::string value = GetEditText(m_valueEdit);
    if (host.empty() || name.empty()) return;

    m_jar->AddCookie(host, name, value);
    SetWindowTextW(m_nameEdit, L"");
    SetWindowTextW(m_valueEdit, L"");
    ReloadList();
}

void CookiePanel::OnDeleteClicked() {
    if (!m_jar || !m_list) return;
    int selected = ListView_GetNextItem(m_list, -1, LVNI_SELECTED);
    if (selected < 0) return;

    wchar_t hostBuf[256]{}, nameBuf[256]{};
    ListView_GetItemText(m_list, selected, 0, hostBuf, 256);
    ListView_GetItemText(m_list, selected, 1, nameBuf, 256);

    m_jar->RemoveCookie(StringUtils::WideToUtf8(hostBuf), StringUtils::WideToUtf8(nameBuf));
    ReloadList();
}

bool CookiePanel::HandleMessage(UINT msg, WPARAM wParam, LPARAM /*lParam*/, LRESULT& outResult) {
    if (msg == WM_COMMAND) {
        UINT id = LOWORD(wParam);
        if (id == kAddButtonId) { OnAddClicked(); outResult = 0; return true; }
        if (id == kDeleteButtonId) { OnDeleteClicked(); outResult = 0; return true; }
    }
    return false;
}

} // namespace Xtentix
