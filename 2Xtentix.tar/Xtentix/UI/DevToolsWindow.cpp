#include "DevToolsWindow.h"
#include "../Utils/StringUtils.h"
#include "../Rendering/HtmlSerializer.h"
#include "../Rendering/PageLinter.h"
#include <algorithm>

namespace Xtentix {

bool DevToolsWindow::Create(HINSTANCE instance) {
    m_instance = instance;

    CreateWindowInternal(L"XtentixDevTools", L"Xtentix \uAC1C\uBC1C\uC790 \uB3C4\uAD6C",
                          WS_OVERLAPPEDWINDOW, 0,
                          CW_USEDEFAULT, CW_USEDEFAULT, 700, 600,
                          nullptr, nullptr, instance);
    if (!m_hwnd) return false;

    m_btnElements = CreateWindowExW(0, L"BUTTON", L"Elements", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        0, 0, 0, 0, m_hwnd, (HMENU)(UINT_PTR)kBtnElements, instance, nullptr);
    m_btnCookies = CreateWindowExW(0, L"BUTTON", L"Cookies", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        0, 0, 0, 0, m_hwnd, (HMENU)(UINT_PTR)kBtnCookies, instance, nullptr);
    m_btnIssues = CreateWindowExW(0, L"BUTTON", L"Issues", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        0, 0, 0, 0, m_hwnd, (HMENU)(UINT_PTR)kBtnIssues, instance, nullptr);

    m_sandboxLabel = CreateWindowExW(0, L"STATIC",
        L"\u26A0 \uC0CC\uB4DC\uBC15\uC2A4 \uBAA8\uB4DC - \uC774 \uD0ED\uC740 \uB124\uD2B8\uC6CC\uD06C \uC694\uCCAD\uC774 \uCC28\uB2E8\uB418\uC5C8\uC2B5\uB2C8\uB2E4",
        WS_CHILD | SS_LEFT, 0, 0, 0, 0, m_hwnd, nullptr, instance, nullptr);

    m_htmlEdit = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"",
        WS_CHILD | ES_MULTILINE | ES_AUTOVSCROLL | ES_AUTOHSCROLL | WS_VSCROLL | WS_HSCROLL,
        0, 0, 0, 0, m_hwnd, nullptr, instance, nullptr);
    HFONT monoFont = CreateFontW(-14, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, FIXED_PITCH, L"Consolas");
    SendMessageW(m_htmlEdit, WM_SETFONT, (WPARAM)monoFont, TRUE);

    m_applyButton = CreateWindowExW(0, L"BUTTON",
        L"\uC801\uC6A9 (\uCF54\uB4DC \uC2E4\uD589 - \uC774 \uD0ED\uC740 \uC0CC\uB4DC\uBC15\uC2A4\uB428)",
        WS_CHILD | BS_PUSHBUTTON, 0, 0, 0, 0, m_hwnd, (HMENU)(UINT_PTR)kBtnApply, instance, nullptr);

    m_issuesEdit = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"",
        WS_CHILD | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL,
        0, 0, 0, 0, m_hwnd, nullptr, instance, nullptr);

    m_cookiePanel.Create(m_hwnd, instance);

    SwitchPanel(0);
    LayoutChildren();
    return true;
}

void DevToolsWindow::SwitchPanel(int index) {
    m_activePanel = index;
    ShowWindow(m_htmlEdit, index == 0 ? SW_SHOW : SW_HIDE);
    ShowWindow(m_applyButton, index == 0 ? SW_SHOW : SW_HIDE);
    ShowWindow(m_cookiePanel.Handle(), index == 1 ? SW_SHOW : SW_HIDE);
    ShowWindow(m_issuesEdit, index == 2 ? SW_SHOW : SW_HIDE);
    EnableWindow(m_btnElements, index != 0);
    EnableWindow(m_btnCookies, index != 1);
    EnableWindow(m_btnIssues, index != 2);
}

void DevToolsWindow::LayoutChildren() {
    RECT rc;
    GetClientRect(m_hwnd, &rc);
    int width = rc.right - rc.left;

    SetWindowPos(m_btnElements, nullptr, 4, 4, 90, 26, SWP_NOZORDER);
    SetWindowPos(m_btnCookies, nullptr, 98, 4, 90, 26, SWP_NOZORDER);
    SetWindowPos(m_btnIssues, nullptr, 192, 4, 90, 26, SWP_NOZORDER);
    SetWindowPos(m_sandboxLabel, nullptr, 290, 8, width - 296, 20, SWP_NOZORDER);

    int contentY = 36;
    int contentHeight = (rc.bottom - rc.top) - contentY;

    SetWindowPos(m_htmlEdit, nullptr, 4, contentY, width - 8, contentHeight - 34, SWP_NOZORDER);
    SetWindowPos(m_applyButton, nullptr, 4, contentY + contentHeight - 30, width - 8, 26, SWP_NOZORDER);

    m_cookiePanel.SetLayoutRect(4, contentY, width - 8, contentHeight);

    SetWindowPos(m_issuesEdit, nullptr, 4, contentY, width - 8, contentHeight, SWP_NOZORDER);
}

void DevToolsWindow::RefreshForTab(const std::string& host, const DomNode* root, CookieJar* jar, bool sandboxed) {
    m_jar = jar;

    std::wstring htmlText = root ? StringUtils::Utf8ToWide(HtmlSerializer::PrettyPrint(root)) : L"";
    SetWindowTextW(m_htmlEdit, htmlText.c_str());

    std::vector<std::string> issues = root ? PageLinter::FindIssues(root) : std::vector<std::string>{ "\uD398\uC774\uC9C0\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4" };
    std::string issuesText;
    for (auto& issue : issues) issuesText += "- " + issue + "\r\n";
    SetWindowTextW(m_issuesEdit, StringUtils::Utf8ToWide(issuesText).c_str());

    m_cookiePanel.Refresh(jar, host);

    ShowWindow(m_sandboxLabel, sandboxed ? SW_SHOW : SW_HIDE);
}

void DevToolsWindow::OnApplyClicked() {
    int len = GetWindowTextLengthW(m_htmlEdit);
    std::wstring buf(len + 1, L'\0');
    GetWindowTextW(m_htmlEdit, buf.data(), len + 1);
    buf.resize(len);

    if (m_onApplyHtml) m_onApplyHtml(StringUtils::WideToUtf8(buf));
    ShowWindow(m_sandboxLabel, SW_SHOW);
}

void DevToolsWindow::ToggleVisible() {
    ShowWindow(m_hwnd, IsVisible() ? SW_HIDE : SW_SHOW);
    if (IsVisible()) SetForegroundWindow(m_hwnd);
}

bool DevToolsWindow::IsVisible() const {
    return m_hwnd && IsWindowVisible(m_hwnd);
}

bool DevToolsWindow::HandleMessage(UINT msg, WPARAM wParam, LPARAM /*lParam*/, LRESULT& outResult) {
    switch (msg) {
        case WM_SIZE:
            LayoutChildren();
            outResult = 0;
            return true;
        case WM_COMMAND: {
            UINT id = LOWORD(wParam);
            if (id == kBtnElements) { SwitchPanel(0); outResult = 0; return true; }
            if (id == kBtnCookies) { SwitchPanel(1); outResult = 0; return true; }
            if (id == kBtnIssues) { SwitchPanel(2); outResult = 0; return true; }
            if (id == kBtnApply) { OnApplyClicked(); outResult = 0; return true; }
            return false;
        }
        case WM_CLOSE:
            ShowWindow(m_hwnd, SW_HIDE); // 닫아도 파괴하지 않고 숨기기만 (편집 내용 유지, F12로 재사용)
            outResult = 0;
            return true;
    }
    return false;
}

} // namespace Xtentix
