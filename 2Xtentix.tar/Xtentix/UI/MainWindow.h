#pragma once
#include "../Core/WindowBase.h"
#include "../Tabs/TabManager.h"
#include "../Bookmark/BookmarkManager.h"
#include "../Settings/SettingsManager.h"
#include "../Network/CookieJar.h"
#include "../Rendering/Document.h"
#include "../Rendering/LayoutBox.h"
#include "../Rendering/GdiPainter.h"
#include "../Extensions/ExtensionManager.h"
#include "TabStrip.h"
#include "AddressBar.h"
#include "NewTabPage.h"
#include "DevToolsWindow.h"
#include "SettingsWindow.h"
#include <unordered_map>
#include <unordered_set>
#include <memory>

namespace Xtentix {

// 애플리케이션의 최상위 윈도우. 탭 스트립 / 주소창(+별표+설정 버튼) / 콘텐츠 영역을
// 세로로 배치하고, F12 개발자 도구 / 설정 창을 별도 창으로 띄운다.
//   +--------------------------------+
//   | TabStrip                       |
//   +--------------------------------+
//   | [*] AddressBar          [gear] |
//   +--------------------------------+
//   | Content: about:blank -> NewTabPage, 그 외 -> HttpClient -> HtmlParser ->
//   | CssParser -> StyleResolver -> LayoutEngine -> GdiPainter 로 실제 렌더링    |
//   +--------------------------------+
// F12로 DevToolsWindow 토글. DevTools에서 코드를 "적용"하면 그 탭은 샌드박스
// 모드로 전환되어(m_sandboxedTabs) 이후 모든 네비게이션이 차단된다.
class MainWindow : public WindowBase {
public:
    // Application.cpp의 가속기 테이블이 참조하는 명령 ID (F12, Ctrl+Shift+N).
    static constexpr UINT kCmdToggleDevTools = 9001;
    static constexpr UINT kCmdNewIncognitoTab = 9002;

    bool Create(HINSTANCE instance, int cmdShow);
    HWND Handle() const { return m_hwnd; }

    // ContentAreaProc(자유 함수 WNDPROC)이 WM_PAINT/WM_VSCROLL/WM_MOUSEWHEEL에서 호출.
    void PaintContentArea(HDC hdc, RECT clientRect);
    void HandleContentVScroll(WPARAM wParam);
    void HandleContentMouseWheel(short wheelDelta);
    void HandleContentClick(int x, int y);
    void UpdateContentCursor(int x, int y);

protected:
    bool HandleMessage(UINT msg, WPARAM wParam, LPARAM lParam, LRESULT& outResult) override;

private:
    struct PageLoadResult {
        TabId tabId;
        std::string requestedUrl;
        bool success = false;
        std::string title;
        std::unique_ptr<Document> document;
        std::unique_ptr<LayoutBox> layout;
    };

    void Layout();
    void NavigateActiveTab(const std::string& url);
    void RefreshTitle();
    void RefreshBookmarkButton();
    void ToggleBookmarkForActiveTab();
    void UpdateContentVisibility();
    void RelayoutActiveTabIfNeeded();
    void OnPageLoadResult(PageLoadResult* result);
    void UpdateScrollbar();
    void SetContentScroll(int pos);

    CookieJar* CookieJarForTab(Tab* tab);
    void ToggleDevTools();
    void RefreshDevToolsIfVisible();
    void ApplyEditedHtmlToActiveTab(const std::string& html);
    void CreateIncognitoTab();

    static constexpr UINT kAddressBarId = 1001;
    static constexpr UINT kBookmarkButtonId = 1002;
    static constexpr UINT kSettingsButtonId = 1003;
    static constexpr int kBookmarkButtonWidth = 32;
    static constexpr int kSettingsButtonWidth = 32;
    static constexpr UINT kPageReadyMsg = WM_APP + 2;

    HINSTANCE m_instance = nullptr;
    TabManager m_tabManager;
    BookmarkManager m_bookmarkManager;
    SettingsManager m_settingsManager;
    CookieJar m_cookieJar{ true };            // 일반 탭용 - 디스크에 영속화됨
    CookieJar m_incognitoCookieJar{ false };  // 시크릿 탭용 - 메모리에만, 절대 저장 안 됨

    TabStrip m_tabStrip;
    AddressBar m_addressBar;
    HWND m_bookmarkButton = nullptr;
    HWND m_settingsButton = nullptr;
    NewTabPage m_newTabPage;
    HWND m_contentArea = nullptr;

    DevToolsWindow m_devTools;
    SettingsWindow m_settingsWindow;
    RenderQuality m_renderQuality = RenderQuality::High;
    ExtensionManager m_extensionManager;

    // DevTools에서 코드를 편집/적용한 탭들 - 그 시점부터 네트워크 요청이 전부 차단됨.
    std::unordered_set<TabId> m_sandboxedTabs;

    // 탭별로 로드된 문서/레이아웃 결과. 탭을 닫으면 같이 정리한다.
    std::unordered_map<TabId, std::unique_ptr<Document>> m_documents;
    std::unordered_map<TabId, std::unique_ptr<LayoutBox>> m_layouts;
    std::unordered_map<TabId, int> m_scrollOffsets; // 탭 전환해도 스크롤 위치 유지
};

} // namespace Xtentix
