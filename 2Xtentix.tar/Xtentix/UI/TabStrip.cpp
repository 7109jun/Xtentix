#include "TabStrip.h"
#include "../Utils/StringUtils.h"
#include <algorithm>
#include <string>

namespace Xtentix {

HWND TabStrip::Create(HWND parent, HINSTANCE instance, TabManager* tabManager) {
    m_tabManager = tabManager;
    CreateWindowInternal(L"XtentixTabStrip", L"", WS_CHILD | WS_VISIBLE,
                          0, 0, 0, 0, kHeight, parent, nullptr, instance);
    return m_hwnd;
}

bool TabStrip::HandleMessage(UINT msg, WPARAM /*wParam*/, LPARAM lParam, LRESULT& outResult) {
    switch (msg) {
        case WM_PAINT:
            Paint();
            outResult = 0;
            return true;
        case WM_LBUTTONDOWN:
            HandleClick(LOWORD(lParam), HIWORD(lParam));
            outResult = 0;
            return true;
        case WM_ERASEBKGND:
            outResult = 1; // Paint()에서 전체를 다시 그리므로 깜빡임 방지 차 무시
            return true;
    }
    return false;
}

void TabStrip::Paint() {
    PAINTSTRUCT ps;
    HDC hdc = BeginPaint(m_hwnd, &ps);

    RECT client;
    GetClientRect(m_hwnd, &client);

    // 더블 버퍼링: 탭이 많아져도 깜빡임 없이 그리기 위함
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBmp = CreateCompatibleBitmap(hdc, client.right, client.bottom);
    HBITMAP oldBmp = (HBITMAP)SelectObject(memDC, memBmp);

    HBRUSH bg = CreateSolidBrush(RGB(223, 227, 233));
    FillRect(memDC, &client, bg);
    DeleteObject(bg);

    SetBkMode(memDC, TRANSPARENT);
    HFONT font = CreateFontW(-13, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                              DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                              CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
    HFONT oldFont = (HFONT)SelectObject(memDC, font);

    m_tabRects.clear();
    int x = 4;
    const auto& tabs = m_tabManager->Tabs();
    Tab* active = m_tabManager->ActiveTab();
    int tabWidth = tabs.empty() ? kTabWidth
                   : (std::min)(kTabWidth, (std::max)(kTabMinWidth,
                        (int)((client.right - kNewTabButtonWidth - 8) / (int)tabs.size())));

    for (auto& tabPtr : tabs) {
        RECT r{ x, 4, x + tabWidth, kHeight };
        bool isActive = (active == tabPtr.get());

        HBRUSH tabBrush = CreateSolidBrush(isActive ? RGB(255, 255, 255) : RGB(205, 211, 219));
        FillRect(memDC, &r, tabBrush);
        DeleteObject(tabBrush);
        FrameRect(memDC, &r, (HBRUSH)GetStockObject(GRAY_BRUSH));

        RECT textRect{ r.left + 8, r.top, r.right - kCloseBoxSize - 6, r.bottom };
        std::wstring title = StringUtils::Utf8ToWide(tabPtr->Title());
        SetTextColor(memDC, RGB(30, 30, 30));
        DrawTextW(memDC, title.c_str(), (int)title.size(), &textRect,
                  DT_SINGLELINE | DT_VCENTER | DT_END_ELLIPSIS);

        RECT closeRect{ r.right - kCloseBoxSize - 4, (r.top + r.bottom) / 2 - kCloseBoxSize / 2,
                        r.right - 4, (r.top + r.bottom) / 2 + kCloseBoxSize / 2 };
        DrawTextW(memDC, L"\u00D7", 1, &closeRect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);

        m_tabRects.push_back({ tabPtr->Id(), r, closeRect });
        x += tabWidth + 2;
    }

    // 새 탭 버튼
    RECT newTabRect{ x, 4, x + kNewTabButtonWidth, kHeight };
    FrameRect(memDC, &newTabRect, (HBRUSH)GetStockObject(GRAY_BRUSH));
    DrawTextW(memDC, L"+", 1, &newTabRect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
    m_newTabRect = newTabRect;

    SelectObject(memDC, oldFont);
    DeleteObject(font);

    BitBlt(hdc, 0, 0, client.right, client.bottom, memDC, 0, 0, SRCCOPY);

    SelectObject(memDC, oldBmp);
    DeleteObject(memBmp);
    DeleteDC(memDC);

    EndPaint(m_hwnd, &ps);
}

void TabStrip::HandleClick(int x, int y) {
    POINT pt{ x, y };
    for (auto& tr : m_tabRects) {
        if (PtInRect(&tr.closeRect, pt)) {
            if (m_onClose) m_onClose(tr.id);
            return;
        }
        if (PtInRect(&tr.rect, pt)) {
            if (m_onSelect) m_onSelect(tr.id);
            return;
        }
    }
    if (PtInRect(&m_newTabRect, pt)) {
        if (m_onNewTab) m_onNewTab();
    }
}

} // namespace Xtentix
