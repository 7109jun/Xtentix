#include "AddressBar.h"
#include "../Utils/StringUtils.h"

namespace Xtentix {

HWND AddressBar::Create(HWND parent, HINSTANCE instance, UINT controlId) {
    m_hwnd = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"",
                              WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
                              0, 0, 0, 0, parent, (HMENU)(UINT_PTR)controlId, instance, nullptr);

    // Subclass: 기본 EDIT 프로시저를 감싸서 WM_KEYDOWN(Enter)을 가로챈다.
    m_originalProc = (WNDPROC)SetWindowLongPtrW(m_hwnd, GWLP_WNDPROC, (LONG_PTR)&AddressBar::StaticProc);
    SetWindowLongPtrW(m_hwnd, GWLP_USERDATA, (LONG_PTR)this);
    return m_hwnd;
}

void AddressBar::SetUrl(const std::string& url) {
    SetWindowTextW(m_hwnd, StringUtils::Utf8ToWide(url).c_str());
}

std::string AddressBar::GetUrl() const {
    wchar_t buf[2048];
    GetWindowTextW(m_hwnd, buf, 2048);
    return StringUtils::WideToUtf8(buf);
}

LRESULT CALLBACK AddressBar::StaticProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    auto self = reinterpret_cast<AddressBar*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    if (self && msg == WM_KEYDOWN && wParam == VK_RETURN) {
        if (self->m_onNavigate) self->m_onNavigate(self->GetUrl());
        return 0;
    }
    if (self) return CallWindowProcW(self->m_originalProc, hwnd, msg, wParam, lParam);
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

} // namespace Xtentix
