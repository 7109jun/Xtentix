#include "SettingsWindow.h"
#include "../Utils/StringUtils.h"
#include "../Utils/ProfileIO.h"
#include <algorithm>

namespace Xtentix {

namespace {
std::string QualityToString(RenderQuality q) {
    switch (q) {
        case RenderQuality::Fast: return "fast";
        case RenderQuality::Medium: return "medium";
        case RenderQuality::High: default: return "high";
    }
}
RenderQuality QualityFromString(const std::string& s) {
    if (s == "fast") return RenderQuality::Fast;
    if (s == "medium") return RenderQuality::Medium;
    return RenderQuality::High;
}
} // namespace

bool SettingsWindow::Create(HINSTANCE instance, SettingsManager* settings, CookieJar* cookieJar, BookmarkManager* bookmarks) {
    m_instance = instance;
    m_settings = settings;
    m_cookieJar = cookieJar;
    m_bookmarks = bookmarks;

    CreateWindowInternal(L"XtentixSettings", L"Xtentix \uC124\uC815", WS_OVERLAPPEDWINDOW, 0,
                          CW_USEDEFAULT, CW_USEDEFAULT, 480, 620, nullptr, nullptr, instance);
    if (!m_hwnd) return false;

    m_qualityLabel = CreateWindowExW(0, L"STATIC",
        L"\uD654\uC9C8 (\uC18D\uB3C4 \u2194 \uD488\uC9C8)", WS_CHILD | WS_VISIBLE | SS_LEFT,
        0, 0, 0, 0, m_hwnd, nullptr, instance, nullptr);

    DWORD radioStyle = WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON;
    m_radioFast = CreateWindowExW(0, L"BUTTON",
        L"\uBE60\uB984 (\uC548\uD2F0\uC54C\uB9AC\uC5B4\uC2F1 \uC5C6\uC74C, \uD654\uC9C8 \uB0AE\uC74C)",
        radioStyle | WS_GROUP, 0, 0, 0, 0, m_hwnd, (HMENU)(UINT_PTR)kRadioFast, instance, nullptr);
    m_radioMedium = CreateWindowExW(0, L"BUTTON",
        L"\uC911\uAC04 (\uB3C4\uD615\uB9CC \uC548\uD2F0\uC54C\uB9AC\uC5B4\uC2F1)",
        radioStyle, 0, 0, 0, 0, m_hwnd, (HMENU)(UINT_PTR)kRadioMedium, instance, nullptr);
    m_radioHigh = CreateWindowExW(0, L"BUTTON",
        L"\uACE0\uD654\uC9C8 (\uB290\uB9BC, ClearType \uD14D\uC2A4\uD2B8+\uB3C4\uD615 \uC548\uD2F0\uC54C\uB9AC\uC5B4\uC2F1)",
        radioStyle, 0, 0, 0, 0, m_hwnd, (HMENU)(UINT_PTR)kRadioHigh, instance, nullptr);

    m_cookieLabel = CreateWindowExW(0, L"STATIC", L"\uCFE0\uD0A4 \uAD00\uB9AC (\uC804\uCCB4 \uC0AC\uC774\uD2B8)",
        WS_CHILD | WS_VISIBLE | SS_LEFT, 0, 0, 0, 0, m_hwnd, nullptr, instance, nullptr);
    m_cookiePanel.Create(m_hwnd, instance);

    m_profileLabel = CreateWindowExW(0, L"STATIC",
        L"\uC800\uC7A5\uBCF8 (\uBD81\uB9C8\uD06C+\uCFE0\uD0A4+\uC124\uC815\uC744 \uD30C\uC77C \uD558\uB098\uB85C - \uB2E4\uB978 \uCEF4\uD4E8\uD130\uB85C \uC625\uAE30\uAE30 \uAC00\uB2A5)",
        WS_CHILD | WS_VISIBLE | SS_LEFT, 0, 0, 0, 0, m_hwnd, nullptr, instance, nullptr);
    m_btnExport = CreateWindowExW(0, L"BUTTON", L"\uB0B4\uBCF4\uB0B4\uAE30 (\uC800\uC7A5)",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, m_hwnd, (HMENU)(UINT_PTR)kBtnExport, instance, nullptr);
    m_btnImport = CreateWindowExW(0, L"BUTTON", L"\uAC00\uC838\uC624\uAE30 (\uBD88\uB7EC\uC624\uAE30)",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, m_hwnd, (HMENU)(UINT_PTR)kBtnImport, instance, nullptr);

    LoadInitialQuality();
    LayoutChildren();
    return true;
}

void SettingsWindow::LoadInitialQuality() {
    RenderQuality q = QualityFromString(m_settings->Get("render_quality", "high"));
    SendMessageW(m_radioFast, BM_SETCHECK, q == RenderQuality::Fast ? BST_CHECKED : BST_UNCHECKED, 0);
    SendMessageW(m_radioMedium, BM_SETCHECK, q == RenderQuality::Medium ? BST_CHECKED : BST_UNCHECKED, 0);
    SendMessageW(m_radioHigh, BM_SETCHECK, q == RenderQuality::High ? BST_CHECKED : BST_UNCHECKED, 0);
}

void SettingsWindow::ApplyQualityFromRadio() {
    RenderQuality q = RenderQuality::High;
    if (SendMessageW(m_radioFast, BM_GETCHECK, 0, 0) == BST_CHECKED) q = RenderQuality::Fast;
    else if (SendMessageW(m_radioMedium, BM_GETCHECK, 0, 0) == BST_CHECKED) q = RenderQuality::Medium;

    m_settings->Set("render_quality", QualityToString(q));
    if (m_onQualityChanged) m_onQualityChanged(q);
}

void SettingsWindow::RefreshCookies() {
    m_cookiePanel.Refresh(m_cookieJar, "");
}

void SettingsWindow::LayoutChildren() {
    RECT rc;
    GetClientRect(m_hwnd, &rc);
    int width = rc.right - rc.left;
    int y = 12;

    SetWindowPos(m_qualityLabel, nullptr, 12, y, width - 24, 20, SWP_NOZORDER); y += 26;
    SetWindowPos(m_radioFast, nullptr, 24, y, width - 40, 22, SWP_NOZORDER); y += 26;
    SetWindowPos(m_radioMedium, nullptr, 24, y, width - 40, 22, SWP_NOZORDER); y += 26;
    SetWindowPos(m_radioHigh, nullptr, 24, y, width - 40, 22, SWP_NOZORDER); y += 34;

    SetWindowPos(m_cookieLabel, nullptr, 12, y, width - 24, 20, SWP_NOZORDER); y += 24;
    int cookiePanelHeight = 300;
    m_cookiePanel.SetLayoutRect(12, y, width - 24, cookiePanelHeight);
    y += cookiePanelHeight + 16;

    SetWindowPos(m_profileLabel, nullptr, 12, y, width - 24, 36, SWP_NOZORDER); y += 42;
    SetWindowPos(m_btnExport, nullptr, 12, y, 150, 28, SWP_NOZORDER);
    SetWindowPos(m_btnImport, nullptr, 170, y, 150, 28, SWP_NOZORDER);
}

void SettingsWindow::ToggleVisible() {
    ShowWindow(m_hwnd, IsVisible() ? SW_HIDE : SW_SHOW);
    if (IsVisible()) { RefreshCookies(); SetForegroundWindow(m_hwnd); }
}

bool SettingsWindow::IsVisible() const {
    return m_hwnd && IsWindowVisible(m_hwnd);
}

bool SettingsWindow::HandleMessage(UINT msg, WPARAM wParam, LPARAM /*lParam*/, LRESULT& outResult) {
    switch (msg) {
        case WM_SIZE:
            LayoutChildren();
            outResult = 0;
            return true;
        case WM_COMMAND: {
            UINT id = LOWORD(wParam);
            if (id == kRadioFast || id == kRadioMedium || id == kRadioHigh) {
                ApplyQualityFromRadio();
                outResult = 0;
                return true;
            }
            if (id == kBtnExport) {
                ProfileIO::ExportProfile(m_hwnd, *m_bookmarks, *m_cookieJar, *m_settings);
                outResult = 0;
                return true;
            }
            if (id == kBtnImport) {
                if (ProfileIO::ImportProfile(m_hwnd, *m_bookmarks, *m_cookieJar, *m_settings)) {
                    LoadInitialQuality();
                    RefreshCookies();
                    if (m_onQualityChanged) m_onQualityChanged(QualityFromString(m_settings->Get("render_quality", "high")));
                }
                outResult = 0;
                return true;
            }
            return false;
        }
        case WM_CLOSE:
            ShowWindow(m_hwnd, SW_HIDE); // 닫아도 파괴 안 함 (F12 개발자 도구와 동일한 패턴)
            outResult = 0;
            return true;
    }
    return false;
}

} // namespace Xtentix
