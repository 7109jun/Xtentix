#pragma once
#include <windows.h>
#include <string>
#include <functional>

namespace Xtentix {

// 네이티브 EDIT 컨트롤을 감싸는 얇은 래퍼. Enter 입력 시 OnNavigate 콜백 발행.
class AddressBar {
public:
    static constexpr int kHeight = 30;

    using NavigateCallback = std::function<void(const std::string& url)>;

    HWND Create(HWND parent, HINSTANCE instance, UINT controlId);

    void SetUrl(const std::string& url);
    std::string GetUrl() const;

    HWND Handle() const { return m_hwnd; }

    void OnNavigate(NavigateCallback cb) { m_onNavigate = std::move(cb); }

private:
    static LRESULT CALLBACK StaticProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

    HWND m_hwnd = nullptr;
    WNDPROC m_originalProc = nullptr;
    NavigateCallback m_onNavigate;
};

} // namespace Xtentix
