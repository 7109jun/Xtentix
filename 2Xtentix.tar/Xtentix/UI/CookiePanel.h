#pragma once
#include "../Core/WindowBase.h"
#include "../Network/CookieJar.h"
#include <string>

namespace Xtentix {

// 쿠키 목록(호스트/이름/값) + 추가/삭제 UI. DevTools의 "Cookies" 탭과 Settings의
// "쿠키 관리" 섹션이 이 컨트롤 하나를 그대로 붙여서 재사용한다 (중복 구현 방지).
class CookiePanel : public WindowBase {
public:
    HWND Create(HWND parent, HINSTANCE instance);

    // hostFilter가 비어있으면 전체 호스트, 아니면 그 호스트만 보여준다.
    void Refresh(CookieJar* jar, const std::string& hostFilter = "");
    void SetLayoutRect(int x, int y, int width, int height);

protected:
    bool HandleMessage(UINT msg, WPARAM wParam, LPARAM lParam, LRESULT& outResult) override;

private:
    void ReloadList();
    void OnAddClicked();
    void OnDeleteClicked();
    void LayoutChildren();

    static constexpr UINT kListId = 3001;
    static constexpr UINT kHostEditId = 3002;
    static constexpr UINT kNameEditId = 3003;
    static constexpr UINT kValueEditId = 3004;
    static constexpr UINT kAddButtonId = 3005;
    static constexpr UINT kDeleteButtonId = 3006;

    HWND m_list = nullptr;
    HWND m_hostEdit = nullptr, m_nameEdit = nullptr, m_valueEdit = nullptr;
    HWND m_addButton = nullptr, m_deleteButton = nullptr;

    CookieJar* m_jar = nullptr;
    std::string m_hostFilter;
    RECT m_rect{ 0, 0, 400, 300 };
};

} // namespace Xtentix
