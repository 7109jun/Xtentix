#pragma once
#include "../Core/WindowBase.h"
#include "../Settings/SettingsManager.h"
#include "../Network/CookieJar.h"
#include "../Bookmark/BookmarkManager.h"
#include "../Rendering/GdiPainter.h"
#include "CookiePanel.h"
#include <functional>

namespace Xtentix {

// 설정 창: 화질(속도 vs 품질 3단계) + 쿠키 관리(CookiePanel 재사용) + 프로필
// 내보내기/가져오기("저장본"). 기어 아이콘 버튼으로 연다.
class SettingsWindow : public WindowBase {
public:
    using QualityChangedCallback = std::function<void(RenderQuality)>;

    bool Create(HINSTANCE instance, SettingsManager* settings, CookieJar* cookieJar, BookmarkManager* bookmarks);
    void OnQualityChanged(QualityChangedCallback cb) { m_onQualityChanged = std::move(cb); }

    void ToggleVisible();
    bool IsVisible() const;
    void RefreshCookies(); // 쿠키가 다른 경로(브라우징 중)로 바뀌었을 수 있으니 열 때마다 갱신

protected:
    bool HandleMessage(UINT msg, WPARAM wParam, LPARAM lParam, LRESULT& outResult) override;

private:
    void LayoutChildren();
    void ApplyQualityFromRadio();
    void LoadInitialQuality();

    static constexpr UINT kRadioFast = 5001;
    static constexpr UINT kRadioMedium = 5002;
    static constexpr UINT kRadioHigh = 5003;
    static constexpr UINT kBtnExport = 5004;
    static constexpr UINT kBtnImport = 5005;

    HINSTANCE m_instance = nullptr;
    HWND m_qualityLabel = nullptr;
    HWND m_radioFast = nullptr, m_radioMedium = nullptr, m_radioHigh = nullptr;
    HWND m_cookieLabel = nullptr;
    CookiePanel m_cookiePanel;
    HWND m_profileLabel = nullptr;
    HWND m_btnExport = nullptr, m_btnImport = nullptr;

    SettingsManager* m_settings = nullptr;
    CookieJar* m_cookieJar = nullptr;
    BookmarkManager* m_bookmarks = nullptr;
    QualityChangedCallback m_onQualityChanged;
};

} // namespace Xtentix
