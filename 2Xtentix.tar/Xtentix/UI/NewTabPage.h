#pragma once
#include "../Core/WindowBase.h"
#include "../Bookmark/BookmarkManager.h"
#include "../Network/HttpClient.h"
#include "../Network/RssParser.h"
#include "../Settings/SettingsManager.h"
#include <gdiplus.h>
#include <functional>
#include <vector>
#include <memory>

namespace Xtentix {

// 새 탭을 열었을 때 보여주는 시작 화면.
//   [로고]
//   바로가기 (북마크 중 앞쪽 N개를 타일로)
//   북마크 (전체 목록)
//   뉴스 (RSS 피드에서 가져온 헤드라인)
// 셋 다 클릭하면 OnNavigate 콜백으로 URL을 전달 - 실제 이동 처리는 MainWindow가 담당.
class NewTabPage : public WindowBase {
public:
    using NavigateCallback = std::function<void(const std::string& url)>;

    HWND Create(HWND parent, HINSTANCE instance, BookmarkManager* bookmarks, SettingsManager* settings);

    void OnNavigate(NavigateCallback cb) { m_onNavigate = std::move(cb); }

    // 북마크가 바뀌었을 때(별표 클릭 등) MainWindow가 호출해서 다시 그리게 함.
    void RefreshBookmarks() { InvalidateRect(m_hwnd, nullptr, TRUE); }

protected:
    bool HandleMessage(UINT msg, WPARAM wParam, LPARAM lParam, LRESULT& outResult) override;

private:
    struct ClickRect { RECT rect; std::string url; };

    void Paint();
    void HandleClick(int x, int y);
    void FetchNews();
    void OnNewsFetched(HttpResponse response); // 워커 스레드에서 호출됨

    static constexpr UINT kNewsReadyMsg = WM_APP + 1;
    static constexpr int kShortcutTileSize = 76;
    static constexpr int kShortcutMax = 8;

    HINSTANCE m_instance = nullptr;
    BookmarkManager* m_bookmarks = nullptr;
    SettingsManager* m_settings = nullptr;
    HttpClient m_httpClient;
    NavigateCallback m_onNavigate;

    std::unique_ptr<Gdiplus::Bitmap> m_logo;
    std::vector<NewsItem> m_newsItems;
    bool m_newsLoading = false;
    bool m_newsFailed = false;

    std::vector<ClickRect> m_clickRects;
};

} // namespace Xtentix
