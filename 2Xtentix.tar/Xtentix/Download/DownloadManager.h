#pragma once
#include <string>
#include <vector>

namespace Xtentix {

struct DownloadItem {
    std::string url;
    std::string destPath;
    uint64_t receivedBytes = 0;
    uint64_t totalBytes = 0;
    bool completed = false;
};

// TODO(Phase 4): Network::HttpClient의 스트리밍 응답을 파일로 저장.
class DownloadManager {
public:
    void StartDownload(const std::string& url, const std::string& destPath);
    const std::vector<DownloadItem>& Items() const { return m_items; }

private:
    std::vector<DownloadItem> m_items;
};

} // namespace Xtentix
