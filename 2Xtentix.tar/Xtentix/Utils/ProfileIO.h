#pragma once
#include <windows.h>
#include "../Bookmark/BookmarkManager.h"
#include "../Network/CookieJar.h"
#include "../Settings/SettingsManager.h"

namespace Xtentix {

// "저장본" 기능: 북마크 + 쿠키 + 설정을 JSON 파일 하나로 묶어서 내보내고, 다른
// 컴퓨터에서 그 파일 하나만 가져오면 그대로 복원되게 한다. 파일 선택은 표준
// Windows 열기/저장 대화상자(comdlg32, OS 기본 제공)를 쓴다.
class ProfileIO {
public:
    static bool ExportProfile(HWND ownerWindow, const BookmarkManager& bookmarks,
                               const CookieJar& cookies, const SettingsManager& settings);
    static bool ImportProfile(HWND ownerWindow, BookmarkManager& bookmarks,
                               CookieJar& cookies, SettingsManager& settings);
};

} // namespace Xtentix
