#include "Json.h"
#include <sstream>
#include <cctype>
#include <cstdlib>

namespace Xtentix {

namespace {

void EncodeUtf8(unsigned int cp, std::string& out) {
    if (cp < 0x80) out += (char)cp;
    else if (cp < 0x800) {
        out += (char)(0xC0 | (cp >> 6));
        out += (char)(0x80 | (cp & 0x3F));
    } else if (cp < 0x10000) {
        out += (char)(0xE0 | (cp >> 12));
        out += (char)(0x80 | ((cp >> 6) & 0x3F));
        out += (char)(0x80 | (cp & 0x3F));
    } else {
        out += (char)(0xF0 | (cp >> 18));
        out += (char)(0x80 | ((cp >> 12) & 0x3F));
        out += (char)(0x80 | ((cp >> 6) & 0x3F));
        out += (char)(0x80 | (cp & 0x3F));
    }
}

// 재귀 하강 파서. 실패하면 ok=false만 세우고 예외는 던지지 않는다
// ("코드 누락/TODO 없이" 원칙과는 별개로, 파서 실패는 흔한 런타임 상황이라 방어적으로 처리).
class Parser {
public:
    explicit Parser(const std::string& s) : m_s(s) {}

    JsonValue ParseValue() {
        SkipWhitespace();
        if (m_i >= m_s.size()) { m_ok = false; return JsonValue(); }

        char c = m_s[m_i];
        if (c == '"') return ParseString();
        if (c == '{') return ParseObject();
        if (c == '[') return ParseArray();
        if (c == 't' || c == 'f') return ParseBool();
        if (c == 'n') return ParseNull();
        if (c == '-' || std::isdigit((unsigned char)c)) return ParseNumber();

        m_ok = false;
        return JsonValue();
    }

    bool Ok() const { return m_ok; }

private:
    void SkipWhitespace() {
        while (m_i < m_s.size() && std::isspace((unsigned char)m_s[m_i])) m_i++;
    }

    bool Consume(char expected) {
        if (m_i < m_s.size() && m_s[m_i] == expected) { m_i++; return true; }
        m_ok = false;
        return false;
    }

    JsonValue ParseNull() {
        if (m_s.compare(m_i, 4, "null") == 0) { m_i += 4; return JsonValue(nullptr); }
        m_ok = false;
        return JsonValue();
    }

    JsonValue ParseBool() {
        if (m_s.compare(m_i, 4, "true") == 0) { m_i += 4; return JsonValue(true); }
        if (m_s.compare(m_i, 5, "false") == 0) { m_i += 5; return JsonValue(false); }
        m_ok = false;
        return JsonValue();
    }

    JsonValue ParseNumber() {
        size_t start = m_i;
        if (m_i < m_s.size() && m_s[m_i] == '-') m_i++;
        while (m_i < m_s.size() && std::isdigit((unsigned char)m_s[m_i])) m_i++;
        if (m_i < m_s.size() && m_s[m_i] == '.') {
            m_i++;
            while (m_i < m_s.size() && std::isdigit((unsigned char)m_s[m_i])) m_i++;
        }
        if (m_i < m_s.size() && (m_s[m_i] == 'e' || m_s[m_i] == 'E')) {
            m_i++;
            if (m_i < m_s.size() && (m_s[m_i] == '+' || m_s[m_i] == '-')) m_i++;
            while (m_i < m_s.size() && std::isdigit((unsigned char)m_s[m_i])) m_i++;
        }
        if (m_i == start) { m_ok = false; return JsonValue(); }
        return JsonValue(std::strtod(m_s.substr(start, m_i - start).c_str(), nullptr));
    }

    std::string ParseRawString() {
        if (!Consume('"')) return "";
        std::string out;
        while (m_i < m_s.size() && m_s[m_i] != '"') {
            char c = m_s[m_i];
            if (c == '\\' && m_i + 1 < m_s.size()) {
                char esc = m_s[m_i + 1];
                switch (esc) {
                    case '"': out += '"'; m_i += 2; break;
                    case '\\': out += '\\'; m_i += 2; break;
                    case '/': out += '/'; m_i += 2; break;
                    case 'b': out += '\b'; m_i += 2; break;
                    case 'f': out += '\f'; m_i += 2; break;
                    case 'n': out += '\n'; m_i += 2; break;
                    case 'r': out += '\r'; m_i += 2; break;
                    case 't': out += '\t'; m_i += 2; break;
                    case 'u': {
                        if (m_i + 6 > m_s.size()) { m_ok = false; return out; }
                        unsigned int cp = (unsigned int)std::strtoul(m_s.substr(m_i + 2, 4).c_str(), nullptr, 16);
                        EncodeUtf8(cp, out); // TODO: 서로게이트 쌍(이모지 등) 조합은 미지원
                        m_i += 6;
                        break;
                    }
                    default: out += esc; m_i += 2; break;
                }
            } else {
                out += c;
                m_i++;
            }
        }
        if (!Consume('"')) { m_ok = false; }
        return out;
    }

    JsonValue ParseString() { return JsonValue(ParseRawString()); }

    JsonValue ParseArray() {
        Consume('[');
        JsonArray arr;
        SkipWhitespace();
        if (m_i < m_s.size() && m_s[m_i] == ']') { m_i++; return JsonValue(std::move(arr)); }

        for (;;) {
            arr.push_back(ParseValue());
            if (!m_ok) break;
            SkipWhitespace();
            if (m_i < m_s.size() && m_s[m_i] == ',') { m_i++; continue; }
            break;
        }
        SkipWhitespace();
        Consume(']');
        return JsonValue(std::move(arr));
    }

    JsonValue ParseObject() {
        Consume('{');
        JsonObject obj;
        SkipWhitespace();
        if (m_i < m_s.size() && m_s[m_i] == '}') { m_i++; return JsonValue(std::move(obj)); }

        for (;;) {
            SkipWhitespace();
            std::string key = ParseRawString();
            if (!m_ok) break;
            SkipWhitespace();
            Consume(':');
            JsonValue value = ParseValue();
            obj.emplace_back(std::move(key), std::move(value));
            if (!m_ok) break;
            SkipWhitespace();
            if (m_i < m_s.size() && m_s[m_i] == ',') { m_i++; continue; }
            break;
        }
        SkipWhitespace();
        Consume('}');
        return JsonValue(std::move(obj));
    }

    const std::string& m_s;
    size_t m_i = 0;
    bool m_ok = true;
};

std::string EscapeString(const std::string& s) {
    std::string out;
    out.reserve(s.size() + 2);
    out += '"';
    for (unsigned char c : s) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20) {
                    char buf[8];
                    snprintf(buf, sizeof(buf), "\\u%04x", c);
                    out += buf;
                } else {
                    out += (char)c; // UTF-8 멀티바이트는 그대로 통과 (JSON 스펙상 허용)
                }
        }
    }
    out += '"';
    return out;
}

} // namespace

const std::string& JsonValue::AsString() const {
    static const std::string kEmpty;
    auto* p = std::get_if<std::string>(&m_data);
    return p ? *p : kEmpty;
}

double JsonValue::AsNumber() const {
    auto* p = std::get_if<double>(&m_data);
    return p ? *p : 0.0;
}

bool JsonValue::AsBool() const {
    auto* p = std::get_if<bool>(&m_data);
    return p ? *p : false;
}

const JsonArray& JsonValue::AsArray() const {
    static const JsonArray kEmpty;
    auto* p = std::get_if<JsonArray>(&m_data);
    return p ? *p : kEmpty;
}

const JsonObject& JsonValue::AsObject() const {
    static const JsonObject kEmpty;
    auto* p = std::get_if<JsonObject>(&m_data);
    return p ? *p : kEmpty;
}

const JsonValue* JsonValue::Find(const std::string& key) const {
    auto* obj = std::get_if<JsonObject>(&m_data);
    if (!obj) return nullptr;
    for (auto& kv : *obj) if (kv.first == key) return &kv.second;
    return nullptr;
}

JsonValue JsonValue::Parse(const std::string& text) {
    Parser p(text);
    JsonValue v = p.ParseValue();
    return p.Ok() ? v : JsonValue();
}

std::string JsonValue::Stringify(int indent) const {
    return StringifyIndented(indent, 0);
}

std::string JsonValue::StringifyIndented(int indent, int depth) const {
    if (IsNull()) return "null";
    if (auto* b = std::get_if<bool>(&m_data)) return *b ? "true" : "false";
    if (auto* n = std::get_if<double>(&m_data)) {
        std::ostringstream oss;
        if (*n == (long long)*n) oss << (long long)*n; // 정수면 소수점 없이
        else oss << *n;
        return oss.str();
    }
    if (auto* s = std::get_if<std::string>(&m_data)) return EscapeString(*s);

    std::string nl = indent >= 0 ? "\n" : "";
    std::string pad = indent >= 0 ? std::string((size_t)indent * (depth + 1), ' ') : "";
    std::string padClose = indent >= 0 ? std::string((size_t)indent * depth, ' ') : "";
    std::string sep = indent >= 0 ? "," + nl : ",";

    if (auto* arr = std::get_if<JsonArray>(&m_data)) {
        if (arr->empty()) return "[]";
        std::string out = "[" + nl;
        for (size_t i = 0; i < arr->size(); ++i) {
            out += pad + (*arr)[i].StringifyIndented(indent, depth + 1);
            if (i + 1 < arr->size()) out += sep; else out += nl;
        }
        out += padClose + "]";
        return out;
    }
    if (auto* obj = std::get_if<JsonObject>(&m_data)) {
        if (obj->empty()) return "{}";
        std::string out = "{" + nl;
        for (size_t i = 0; i < obj->size(); ++i) {
            out += pad + EscapeString((*obj)[i].first) + (indent >= 0 ? ": " : ":")
                 + (*obj)[i].second.StringifyIndented(indent, depth + 1);
            if (i + 1 < obj->size()) out += sep; else out += nl;
        }
        out += padClose + "}";
        return out;
    }
    return "null";
}

} // namespace Xtentix
