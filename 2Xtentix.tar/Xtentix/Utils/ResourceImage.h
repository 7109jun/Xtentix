#pragma once
#include <windows.h>
#include <memory>
#include <gdiplus.h>

namespace Xtentix {

// exe 안에 RCDATA로 내장된 PNG 리소스를 GDI+ Bitmap으로 로드.
// 파일 시스템에 별도 리소스 파일을 두지 않고 단일 exe로 배포하기 위함.
class ResourceImage {
public:
    static std::unique_ptr<Gdiplus::Bitmap> LoadPngFromResource(HINSTANCE instance, int resourceId);
};

} // namespace Xtentix
