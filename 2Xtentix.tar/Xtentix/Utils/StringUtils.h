#pragma once
#include <string>
#include <windows.h>

namespace Xtentix {

// UTF-8 <-> UTF-16(wide) 변환. Win32 API는 wide 문자열을 기본으로 사용하므로
// 내부 파서/렌더러(UTF-8)와 UI 레이어(wide) 사이의 경계에서 항상 이 함수를 거친다.
class StringUtils {
public:
    static std::wstring Utf8ToWide(const std::string& utf8) {
        if (utf8.empty()) return L"";
        int size = MultiByteToWideChar(CP_UTF8, 0, utf8.data(), (int)utf8.size(), nullptr, 0);
        std::wstring result(size, L'\0');
        MultiByteToWideChar(CP_UTF8, 0, utf8.data(), (int)utf8.size(), result.data(), size);
        return result;
    }

    static std::string WideToUtf8(const std::wstring& wide) {
        if (wide.empty()) return "";
        int size = WideCharToMultiByte(CP_UTF8, 0, wide.data(), (int)wide.size(), nullptr, 0, nullptr, nullptr);
        std::string result(size, '\0');
        WideCharToMultiByte(CP_UTF8, 0, wide.data(), (int)wide.size(), result.data(), size, nullptr, nullptr);
        return result;
    }

    static std::string ToLower(std::string s) {
        for (auto& c : s) c = (char)tolower((unsigned char)c);
        return s;
    }

    static bool StartsWith(const std::string& s, const std::string& prefix) {
        return s.size() >= prefix.size() && s.compare(0, prefix.size(), prefix) == 0;
    }
};

} // namespace Xtentix
