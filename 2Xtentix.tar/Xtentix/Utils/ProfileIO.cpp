#include "ProfileIO.h"
#include "Json.h"
#include "StringUtils.h"
#include <commdlg.h>
#include <fstream>

namespace Xtentix {

namespace {

JsonValue BuildProfileJson(const BookmarkManager& bookmarks, const CookieJar& cookies, const SettingsManager& settings) {
    JsonArray bookmarkArr;
    for (auto& b : bookmarks.Entries()) {
        JsonObject obj;
        obj.emplace_back("title", JsonValue(b.title));
        obj.emplace_back("url", JsonValue(b.url));
        bookmarkArr.push_back(JsonValue(std::move(obj)));
    }

    JsonObject cookieObj;
    for (auto& host : cookies.AllHosts()) {
        JsonArray hostArr;
        for (auto& c : cookies.GetCookies(host)) {
            JsonObject obj;
            obj.emplace_back("name", JsonValue(c.name));
            obj.emplace_back("value", JsonValue(c.value));
            hostArr.push_back(JsonValue(std::move(obj)));
        }
        cookieObj.emplace_back(host, JsonValue(std::move(hostArr)));
    }

    JsonObject settingsObj;
    for (auto& kv : settings.All()) settingsObj.emplace_back(kv.first, JsonValue(kv.second));

    JsonObject root;
    root.emplace_back("xtentix_profile_version", JsonValue(1));
    root.emplace_back("bookmarks", JsonValue(std::move(bookmarkArr)));
    root.emplace_back("cookies", JsonValue(std::move(cookieObj)));
    root.emplace_back("settings", JsonValue(std::move(settingsObj)));
    return JsonValue(std::move(root));
}

} // namespace

bool ProfileIO::ExportProfile(HWND ownerWindow, const BookmarkManager& bookmarks,
                               const CookieJar& cookies, const SettingsManager& settings) {
    wchar_t pathBuf[MAX_PATH] = L"XtentixProfile.json";

    OPENFILENAMEW ofn{};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = ownerWindow;
    ofn.lpstrFilter = L"Xtentix \uD504\uB85C\uD544 (*.json)\0*.json\0\uBAA8\uB4E0 \uD30C\uC77C\0*.*\0";
    ofn.lpstrFile = pathBuf;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrDefExt = L"json";
    ofn.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;

    if (!GetSaveFileNameW(&ofn)) return false; // 사용자가 취소함

    std::string json = BuildProfileJson(bookmarks, cookies, settings).Stringify(2);
    std::ofstream file(pathBuf, std::ios::binary | std::ios::trunc);
    if (!file) return false;
    file.write(json.data(), (std::streamsize)json.size());
    return true;
}

bool ProfileIO::ImportProfile(HWND ownerWindow, BookmarkManager& bookmarks,
                               CookieJar& cookies, SettingsManager& settings) {
    wchar_t pathBuf[MAX_PATH] = L"";

    OPENFILENAMEW ofn{};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = ownerWindow;
    ofn.lpstrFilter = L"Xtentix \uD504\uB85C\uD544 (*.json)\0*.json\0\uBAA8\uB4E0 \uD30C\uC77C\0*.*\0";
    ofn.lpstrFile = pathBuf;
    ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;

    if (!GetOpenFileNameW(&ofn)) return false; // 사용자가 취소함

    std::ifstream file(pathBuf, std::ios::binary);
    if (!file) return false;
    std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());

    JsonValue root = JsonValue::Parse(content);
    if (!root.IsObject()) return false;

    if (const JsonValue* bm = root.Find("bookmarks")) {
        if (bm->IsArray()) {
            for (auto& item : bm->AsArray()) {
                const JsonValue* title = item.Find("title");
                const JsonValue* url = item.Find("url");
                if (url && !url->AsString().empty()) {
                    bookmarks.Add(title ? title->AsString() : "", url->AsString());
                }
            }
        }
    }

    if (const JsonValue* ck = root.Find("cookies")) {
        if (ck->IsObject()) {
            for (auto& hostEntry : ck->AsObject()) {
                if (!hostEntry.second.IsArray()) continue;
                for (auto& item : hostEntry.second.AsArray()) {
                    const JsonValue* name = item.Find("name");
                    const JsonValue* value = item.Find("value");
                    if (name && value) cookies.AddCookie(hostEntry.first, name->AsString(), value->AsString());
                }
            }
        }
    }

    if (const JsonValue* st = root.Find("settings")) {
        if (st->IsObject()) {
            for (auto& kv : st->AsObject()) {
                if (kv.second.IsString()) settings.Set(kv.first, kv.second.AsString());
            }
        }
    }

    return true;
}

} // namespace Xtentix
