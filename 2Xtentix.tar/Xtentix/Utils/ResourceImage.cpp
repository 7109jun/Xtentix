#include "ResourceImage.h"
#include <shlwapi.h>

namespace Xtentix {

std::unique_ptr<Gdiplus::Bitmap> ResourceImage::LoadPngFromResource(HINSTANCE instance, int resourceId) {
    HRSRC res = FindResourceW(instance, MAKEINTRESOURCEW(resourceId), RT_RCDATA);
    if (!res) return nullptr;

    HGLOBAL loaded = LoadResource(instance, res);
    if (!loaded) return nullptr;

    void* data = LockResource(loaded);
    DWORD size = SizeofResource(instance, res);
    if (!data || size == 0) return nullptr;

    // SHCreateMemStream이 데이터를 복사하므로 원본 리소스 핸들은 이후 신경 쓸 필요 없음
    // (리소스 섹션은 UnlockResource/FreeResource 없이도 프로세스 종료까지 유효하지만,
    //  스트림에 복사해두는 편이 수명 관리가 더 명확함).
    IStream* stream = SHCreateMemStream(reinterpret_cast<const BYTE*>(data), size);
    if (!stream) return nullptr;

    auto bitmap = std::make_unique<Gdiplus::Bitmap>(stream);
    stream->Release();

    if (bitmap->GetLastStatus() != Gdiplus::Ok) return nullptr;
    return bitmap;
}

} // namespace Xtentix
