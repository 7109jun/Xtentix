#pragma once
#include <string>
#include <vector>
#include <utility>
#include <variant>

namespace Xtentix {

class JsonValue;
using JsonArray = std::vector<JsonValue>;
using JsonObject = std::vector<std::pair<std::string, JsonValue>>; // 입력 순서 유지 (JALX와 동일한 원칙)

// 의존성 없는 자체 구현 JSON 값 타입. 북마크/설정 영속화 정도의 규모에 맞춘
// 실용적 구현이라 표준 JSON 스펙 전체(예: \uXXXX 서로게이트 쌍 조합, NaN/Infinity
// 등 비표준 확장)는 다루지 않는다 — TODO(필요해지면 확장).
class JsonValue {
public:
    JsonValue() = default;
    JsonValue(std::nullptr_t) {}
    JsonValue(bool b) : m_data(b) {}
    JsonValue(double n) : m_data(n) {}
    JsonValue(int n) : m_data((double)n) {}
    JsonValue(std::string s) : m_data(std::move(s)) {}
    JsonValue(const char* s) : m_data(std::string(s)) {}
    JsonValue(JsonArray a) : m_data(std::move(a)) {}
    JsonValue(JsonObject o) : m_data(std::move(o)) {}

    bool IsNull() const { return std::holds_alternative<std::monostate>(m_data); }
    bool IsString() const { return std::holds_alternative<std::string>(m_data); }
    bool IsArray() const { return std::holds_alternative<JsonArray>(m_data); }
    bool IsObject() const { return std::holds_alternative<JsonObject>(m_data); }
    bool IsBool() const { return std::holds_alternative<bool>(m_data); }
    bool IsNumber() const { return std::holds_alternative<double>(m_data); }

    const std::string& AsString() const;
    double AsNumber() const;
    bool AsBool() const;
    const JsonArray& AsArray() const;
    const JsonObject& AsObject() const;

    // 오브젝트 전용 편의 함수: 키로 값 찾기 (없으면 nullptr, IsObject()가 아니어도 안전)
    const JsonValue* Find(const std::string& key) const;

    // 파싱 실패 시 예외 대신 Null JsonValue를 반환 (호출부가 IsNull()로 방어적으로 처리).
    static JsonValue Parse(const std::string& text);
    std::string Stringify(int indent = -1) const; // indent<0 = 한 줄 압축, 그 외 = 보기 좋게

private:
    std::string StringifyIndented(int indent, int depth) const;

    std::variant<std::monostate, bool, double, std::string, JsonArray, JsonObject> m_data;
};

} // namespace Xtentix
