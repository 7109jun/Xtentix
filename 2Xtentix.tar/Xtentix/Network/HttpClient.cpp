#include "HttpClient.h"
#include <windows.h>
#include <winhttp.h>
#include <thread>

namespace Xtentix {

namespace {

std::wstring Utf8ToWide(const std::string& s) {
    if (s.empty()) return L"";
    int len = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    std::wstring w(len, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), w.data(), len);
    return w;
}

std::string WideToUtf8(const std::wstring& w) {
    if (w.empty()) return "";
    int len = WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), nullptr, 0, nullptr, nullptr);
    std::string s(len, '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), s.data(), len, nullptr, nullptr);
    return s;
}

// 리다이렉트를 최대 5회까지 따라가며 실제 요청을 수행. WinHTTP는 스킴만 다르면
// (http<->https) 자동 리다이렉트를 안 따라가므로 직접 처리.
HttpResponse PerformRequest(const std::string& urlUtf8, int redirectsLeft, CookieJar* cookieJar) {
    HttpResponse result;
    URL_COMPONENTS uc{};
    uc.dwStructSize = sizeof(uc);
    wchar_t hostBuf[256]{}, pathBuf[2048]{};
    uc.lpszHostName = hostBuf; uc.dwHostNameLength = 256;
    uc.lpszUrlPath = pathBuf; uc.dwUrlPathLength = 2048;

    std::wstring url = Utf8ToWide(urlUtf8);
    if (!WinHttpCrackUrl(url.c_str(), 0, 0, &uc)) return result;

    bool https = (uc.nScheme == INTERNET_SCHEME_HTTPS);
    std::string host = WideToUtf8(uc.lpszHostName);

    HINTERNET hSession = WinHttpOpen(L"Xtentix/1.0",
        WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hSession) return result;

    HINTERNET hConnect = WinHttpConnect(hSession, uc.lpszHostName, uc.nPort, 0);
    if (!hConnect) { WinHttpCloseHandle(hSession); return result; }

    DWORD flags = https ? WINHTTP_FLAG_SECURE : 0;
    HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"GET", uc.lpszUrlPath,
        nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, flags);
    if (!hRequest) { WinHttpCloseHandle(hConnect); WinHttpCloseHandle(hSession); return result; }

    if (cookieJar) {
        std::string cookieHeader = cookieJar->BuildCookieHeader(host);
        if (!cookieHeader.empty()) {
            std::wstring headerLine = L"Cookie: " + Utf8ToWide(cookieHeader);
            WinHttpAddRequestHeaders(hRequest, headerLine.c_str(), (DWORD)-1L, WINHTTP_ADDREQ_FLAG_ADD);
        }
    }

    BOOL sent = WinHttpSendRequest(hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
        WINHTTP_NO_REQUEST_DATA, 0, 0, 0);
    BOOL received = sent && WinHttpReceiveResponse(hRequest, nullptr);

    if (received) {
        DWORD statusCode = 0, size = sizeof(statusCode);
        WinHttpQueryHeaders(hRequest, WINHTTP_QUERY_FLAG_NUMBER | WINHTTP_QUERY_STATUS_CODE,
            WINHTTP_HEADER_NAME_BY_INDEX, &statusCode, &size, WINHTTP_NO_HEADER_INDEX);

        // 리다이렉트 따라가기 전에도 이 응답이 준 쿠키는 반영해야 함(로그인 흐름 등).
        if (cookieJar) {
            std::vector<std::string> setCookies;
            DWORD idx = 0;
            for (;;) {
                wchar_t buf[2048]{};
                DWORD bufSize = sizeof(buf);
                if (!WinHttpQueryHeaders(hRequest, WINHTTP_QUERY_SET_COOKIE, WINHTTP_HEADER_NAME_BY_INDEX,
                                          buf, &bufSize, &idx)) break;
                setCookies.push_back(WideToUtf8(buf));
            }
            if (!setCookies.empty()) cookieJar->ApplySetCookieHeaders(host, setCookies);
        }

        if ((statusCode == 301 || statusCode == 302 || statusCode == 303 || statusCode == 307) && redirectsLeft > 0) {
            wchar_t locBuf[2048]{};
            DWORD locSize = sizeof(locBuf);
            if (WinHttpQueryHeaders(hRequest, WINHTTP_QUERY_LOCATION, WINHTTP_HEADER_NAME_BY_INDEX,
                                     locBuf, &locSize, WINHTTP_NO_HEADER_INDEX)) {
                WinHttpCloseHandle(hRequest); WinHttpCloseHandle(hConnect); WinHttpCloseHandle(hSession);
                return PerformRequest(WideToUtf8(locBuf), redirectsLeft - 1, cookieJar);
            }
        }

        result.statusCode = (int)statusCode;

        wchar_t ctypeBuf[256]{};
        DWORD ctypeSize = sizeof(ctypeBuf);
        if (WinHttpQueryHeaders(hRequest, WINHTTP_QUERY_CONTENT_TYPE, WINHTTP_HEADER_NAME_BY_INDEX,
                                 ctypeBuf, &ctypeSize, WINHTTP_NO_HEADER_INDEX)) {
            result.contentType = WideToUtf8(ctypeBuf);
        }

        std::string body;
        DWORD available = 0;
        while (WinHttpQueryDataAvailable(hRequest, &available) && available > 0) {
            std::string chunk(available, '\0');
            DWORD read = 0;
            if (!WinHttpReadData(hRequest, chunk.data(), available, &read)) break;
            chunk.resize(read);
            body += chunk;
        }
        result.body = std::move(body);
        result.success = (statusCode >= 200 && statusCode < 300);
    }

    WinHttpCloseHandle(hRequest);
    WinHttpCloseHandle(hConnect);
    WinHttpCloseHandle(hSession);
    return result;
}

} // namespace

void HttpClient::GetAsync(const std::string& url, ResponseCallback callback) {
    // 워커 스레드에서 동기 요청 수행 후 콜백 호출.
    // 콜백은 UI 스레드가 아니므로, 호출부(예: NewTabPage)가 PostMessage로 마셜링해야 함.
    CookieJar* jar = m_cookieJar;
    std::thread([url, callback, jar]() {
        HttpResponse response = PerformRequest(url, /*redirectsLeft=*/5, jar);
        callback(response);
    }).detach();
}

} // namespace Xtentix
