#include "CookieJar.h"
#include "../Utils/Json.h"
#include <fstream>
#include <filesystem>
#include <cstdlib>
#include <algorithm>

namespace Xtentix {

namespace {
std::string Trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}
} // namespace

std::string CookieJar::ExtractHost(const std::string& url) {
    size_t schemeEnd = url.find("://");
    if (schemeEnd == std::string::npos) return url;
    size_t hostStart = schemeEnd + 3;
    size_t pathStart = url.find('/', hostStart);
    return (pathStart == std::string::npos) ? url.substr(hostStart) : url.substr(hostStart, pathStart - hostStart);
}

std::string CookieJar::DefaultFilePath() {
    const char* appdata = std::getenv("APPDATA");
    std::filesystem::path base = appdata ? std::filesystem::path(appdata) : std::filesystem::current_path();
    std::filesystem::path dir = base / "Xtentix";
    std::error_code ec;
    std::filesystem::create_directories(dir, ec);
    return (dir / "cookies.json").string();
}

void CookieJar::Load() {
    if (!m_persistent) return; // 시크릿 모드: 디스크에서 아무것도 안 읽음
    m_cookies.clear();

    std::ifstream file(DefaultFilePath(), std::ios::binary);
    if (!file) return;

    std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    JsonValue root = JsonValue::Parse(content);
    if (!root.IsObject()) return;

    for (auto& hostEntry : root.AsObject()) {
        if (!hostEntry.second.IsArray()) continue;
        std::vector<Cookie> cookies;
        for (auto& item : hostEntry.second.AsArray()) {
            const JsonValue* name = item.Find("name");
            const JsonValue* value = item.Find("value");
            if (name && value) cookies.push_back({ name->AsString(), value->AsString() });
        }
        m_cookies[hostEntry.first] = std::move(cookies);
    }
}

void CookieJar::Save() const {
    if (!m_persistent) return; // 시크릿 모드: 디스크에 아무것도 안 씀

    JsonObject root;
    for (auto& kv : m_cookies) {
        JsonArray arr;
        for (auto& c : kv.second) {
            JsonObject obj;
            obj.emplace_back("name", JsonValue(c.name));
            obj.emplace_back("value", JsonValue(c.value));
            arr.push_back(JsonValue(std::move(obj)));
        }
        root.emplace_back(kv.first, JsonValue(std::move(arr)));
    }

    std::ofstream file(DefaultFilePath(), std::ios::binary | std::ios::trunc);
    if (!file) return;
    std::string json = JsonValue(std::move(root)).Stringify(2);
    file.write(json.data(), (std::streamsize)json.size());
}

std::string CookieJar::BuildCookieHeader(const std::string& host) const {
    auto it = m_cookies.find(host);
    if (it == m_cookies.end() || it->second.empty()) return "";

    std::string out;
    for (auto& c : it->second) {
        if (!out.empty()) out += "; ";
        out += c.name + "=" + c.value;
    }
    return out;
}

void CookieJar::ApplySetCookieHeaders(const std::string& host, const std::vector<std::string>& setCookieHeaders) {
    if (setCookieHeaders.empty()) return;
    for (auto& header : setCookieHeaders) {
        size_t semi = header.find(';');
        std::string pair = (semi == std::string::npos) ? header : header.substr(0, semi);
        size_t eq = pair.find('=');
        if (eq == std::string::npos) continue;

        std::string name = Trim(pair.substr(0, eq));
        std::string value = Trim(pair.substr(eq + 1));
        if (name.empty()) continue;
        AddCookie(host, name, value);
    }
}

void CookieJar::AddCookie(const std::string& host, const std::string& name, const std::string& value) {
    auto& cookies = m_cookies[host];
    for (auto& c : cookies) {
        if (c.name == name) { c.value = value; Save(); return; }
    }
    cookies.push_back({ name, value });
    Save();
}

void CookieJar::RemoveCookie(const std::string& host, const std::string& name) {
    auto it = m_cookies.find(host);
    if (it == m_cookies.end()) return;
    it->second.erase(std::remove_if(it->second.begin(), it->second.end(),
        [&](const Cookie& c) { return c.name == name; }), it->second.end());
    Save();
}

std::vector<Cookie> CookieJar::GetCookies(const std::string& host) const {
    auto it = m_cookies.find(host);
    return it != m_cookies.end() ? it->second : std::vector<Cookie>{};
}

std::vector<std::string> CookieJar::AllHosts() const {
    std::vector<std::string> hosts;
    for (auto& kv : m_cookies) if (!kv.second.empty()) hosts.push_back(kv.first);
    return hosts;
}

} // namespace Xtentix
