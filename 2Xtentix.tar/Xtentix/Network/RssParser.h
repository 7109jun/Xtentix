#pragma once
#include <string>
#include <vector>

namespace Xtentix {

struct NewsItem {
    std::string title;
    std::string link;
};

// RSS 2.0(<item>) / Atom(<entry>) 피드에서 제목+링크만 뽑아내는 실용적 파서.
// 전체 XML 파서가 아니라 <item>...</item> 블록을 찾아 그 안의 <title>, <link>만
// 문자열 검색으로 추출한다 (뉴스 헤드라인 표시 목적에는 이걸로 충분).
class RssParser {
public:
    static std::vector<NewsItem> Parse(const std::string& xml, size_t maxItems = 10);
};

} // namespace Xtentix
