#include "RssParser.h"
#include <algorithm>
#include <cctype>

namespace Xtentix {

namespace {

std::string Trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

// <![CDATA[ ... ]]> 래핑을 벗기고, &amp; 등 기본 엔티티만 디코딩.
std::string CleanText(std::string s) {
    s = Trim(s);
    const std::string cdataStart = "<![CDATA[";
    if (s.compare(0, cdataStart.size(), cdataStart) == 0) {
        size_t end = s.find("]]>");
        s = (end == std::string::npos) ? s.substr(cdataStart.size())
                                        : s.substr(cdataStart.size(), end - cdataStart.size());
        s = Trim(s);
    }
    auto replaceAll = [](std::string& str, const std::string& from, const std::string& to) {
        size_t pos = 0;
        while ((pos = str.find(from, pos)) != std::string::npos) {
            str.replace(pos, from.size(), to);
            pos += to.size();
        }
    };
    replaceAll(s, "&amp;", "&");
    replaceAll(s, "&lt;", "<");
    replaceAll(s, "&gt;", ">");
    replaceAll(s, "&quot;", "\"");
    replaceAll(s, "&apos;", "'");
    return s;
}

// haystack에서 needle을 대소문자 무시하고 찾음 (XML 태그명은 보통 소문자지만 방어적으로).
size_t FindCI(const std::string& haystack, const std::string& needle, size_t from) {
    if (needle.empty()) return std::string::npos;
    auto it = std::search(haystack.begin() + (long)from, haystack.end(), needle.begin(), needle.end(),
        [](char a, char b) { return std::tolower((unsigned char)a) == std::tolower((unsigned char)b); });
    return (it == haystack.end()) ? std::string::npos : (size_t)(it - haystack.begin());
}

std::string ExtractBetween(const std::string& block, const std::string& openTag, const std::string& closeTag) {
    size_t open = FindCI(block, openTag, 0);
    if (open == std::string::npos) return "";
    size_t contentStart = block.find('>', open);
    if (contentStart == std::string::npos) return "";
    contentStart++;
    size_t close = FindCI(block, closeTag, contentStart);
    if (close == std::string::npos) return "";
    return block.substr(contentStart, close - contentStart);
}

// Atom의 <link href="..."/> 형태 지원 (RSS는 <link>텍스트</link>)
std::string ExtractLink(const std::string& block) {
    std::string text = ExtractBetween(block, "<link", "</link>");
    if (!text.empty()) return CleanText(text);

    size_t linkPos = FindCI(block, "<link", 0);
    if (linkPos == std::string::npos) return "";
    size_t tagEnd = block.find('>', linkPos);
    if (tagEnd == std::string::npos) return "";
    std::string tag = block.substr(linkPos, tagEnd - linkPos);

    size_t hrefPos = FindCI(tag, "href", 0);
    if (hrefPos == std::string::npos) return "";
    size_t eq = tag.find('=', hrefPos);
    if (eq == std::string::npos) return "";
    size_t valStart = tag.find_first_of("\"'", eq);
    if (valStart == std::string::npos) return "";
    char quote = tag[valStart];
    size_t valEnd = tag.find(quote, valStart + 1);
    if (valEnd == std::string::npos) return "";
    return tag.substr(valStart + 1, valEnd - valStart - 1);
}

std::vector<std::string> ExtractBlocks(const std::string& xml, const std::string& tag) {
    std::vector<std::string> blocks;
    std::string openTag = "<" + tag;
    std::string closeTag = "</" + tag + ">";
    size_t pos = 0;
    for (;;) {
        size_t open = FindCI(xml, openTag, pos);
        if (open == std::string::npos) break;
        size_t close = FindCI(xml, closeTag, open);
        if (close == std::string::npos) break;
        blocks.push_back(xml.substr(open, close + closeTag.size() - open));
        pos = close + closeTag.size();
    }
    return blocks;
}

} // namespace

std::vector<NewsItem> RssParser::Parse(const std::string& xml, size_t maxItems) {
    std::vector<NewsItem> items;

    std::vector<std::string> blocks = ExtractBlocks(xml, "item");   // RSS 2.0
    if (blocks.empty()) blocks = ExtractBlocks(xml, "entry");        // Atom

    for (auto& block : blocks) {
        if (items.size() >= maxItems) break;
        NewsItem item;
        item.title = CleanText(ExtractBetween(block, "<title", "</title>"));
        item.link = ExtractLink(block);
        if (!item.title.empty() && !item.link.empty()) items.push_back(std::move(item));
    }
    return items;
}

} // namespace Xtentix
