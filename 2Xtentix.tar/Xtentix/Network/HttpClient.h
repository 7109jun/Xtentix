#pragma once
#include <string>
#include <functional>
#include "CookieJar.h"

namespace Xtentix {

struct HttpResponse {
    int statusCode = 0;
    std::string body;
    std::string contentType;
    bool success = false;
};

// WinHTTP(OS 기본 제공, 외부 라이브러리 아님) 기반 구현.
// HTTPS는 WinHTTP가 Schannel을 통해 처리하므로 별도 TLS 구현 불필요.
class HttpClient {
public:
    using ResponseCallback = std::function<void(const HttpResponse&)>;

    // cookieJar가 있으면 요청에 Cookie 헤더를 자동으로 붙이고, 응답의 Set-Cookie를
    // 자동으로 저장한다. nullptr이면(예: 새 탭 페이지의 뉴스 피드) 쿠키를 아예 안 씀.
    explicit HttpClient(CookieJar* cookieJar = nullptr) : m_cookieJar(cookieJar) {}

    // 비동기 GET. 완료 시 콜백은 UI 스레드가 아닌 워커 스레드에서 호출될 수 있으므로
    // 호출부(MainWindow)에서 PostMessage로 마셜링해야 한다.
    void GetAsync(const std::string& url, ResponseCallback callback);

private:
    CookieJar* m_cookieJar;
};

} // namespace Xtentix
