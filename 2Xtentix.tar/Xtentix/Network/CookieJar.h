#pragma once
#include <string>
#include <vector>
#include <unordered_map>

namespace Xtentix {

struct Cookie {
    std::string name;
    std::string value;
};

// 호스트(도메인)별 쿠키를 메모리에 들고, HttpClient가 요청/응답을 주고받을 때
// 자동으로 붙이고 저장한다. %APPDATA%/Xtentix/cookies.json에 영속화(Bookmark/
// SettingsManager와 동일한 패턴). DevTools/Settings의 "쿠키 보기" 패널이 그대로 씀.
//   TODO(Phase 7+): 만료(Expires/Max-Age), Path, HttpOnly/Secure 플래그는 지금은
//   무시하고 name=value만 저장 - 로그인 세션 유지 정도는 충분하지만 완전한 스펙 준수는 아님.
class CookieJar {
public:
    // persistent=false면 시크릿 모드용 - Load()/Save()가 전부 조용히 무시됨(디스크 미접촉).
    explicit CookieJar(bool persistent = true) : m_persistent(persistent) {}

    void Load();
    static std::string DefaultFilePath();

    // 요청에 실어 보낼 "name=value; name2=value2" 형태의 헤더 값 (없으면 빈 문자열).
    std::string BuildCookieHeader(const std::string& host) const;

    // 응답의 Set-Cookie 헤더들(여러 개일 수 있음)을 반영.
    void ApplySetCookieHeaders(const std::string& host, const std::vector<std::string>& setCookieHeaders);

    void AddCookie(const std::string& host, const std::string& name, const std::string& value);
    void RemoveCookie(const std::string& host, const std::string& name);
    std::vector<Cookie> GetCookies(const std::string& host) const;
    std::vector<std::string> AllHosts() const;

    // URL 문자열에서 host만 뽑아내는 공용 헬퍼 (MainWindow 링크 이동에서도 필요해서 공개).
    static std::string ExtractHost(const std::string& url);

private:
    void Save() const;

    bool m_persistent;
    std::unordered_map<std::string, std::vector<Cookie>> m_cookies; // host -> cookies
};

} // namespace Xtentix
